from pathlib import Path
from xml.etree import ElementTree as ET
import re,json,hashlib
W=Path(__file__).resolve().parents[1];N=W/'jno_native'
SVG='http://www.w3.org/2000/svg';ET.register_namespace('',SVG);ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
files=list(N.rglob('*.svg'))+list((W/'figures').glob('*.svg'))+list((W/'package/06_Graphical_abstract').glob('*.svg'))
count=0
for p in files:
 tree=ET.parse(p);changed=False
 for t in tree.findall('.//{'+SVG+'}text'):
  st=t.get('style','')
  m=re.search(r'(?:^|;)\s*font:\s*([^;]+)',st)
  if not m:continue
  value=m.group(1);size=re.search(r'(\d+(?:\.\d+)?)px',value);assert size,(p,value)
  st=st[:m.start()]+st[m.end():];st=st.lstrip('; ')
  weight='700' if re.search(r'\b700\b|\bbold\b',value) else '400'
  st+='; font-family:Arial; font-size:'+size.group(1)+'px; font-weight:'+weight
  t.set('style',st);t.set('font-family','Arial');t.set('font-size',size.group(1));t.set('font-weight',weight);changed=True;count+=1
 if changed:tree.write(p,encoding='utf-8',xml_declaration=True)
for n in ['PANEL_MANIFEST.json','PAGE_AND_PANEL_MANIFEST.json']:
 p=N/n;data=json.loads(p.read_text())
 def update(o):
  if isinstance(o,dict):
   if 'svg' in o and 'svg_sha256' in o and (N/o['svg']).exists():o['svg_sha256']=sha(N/o['svg'])
   for v in o.values():update(v)
  elif isinstance(o,list):
   for v in o:update(v)
 update(data);data['SVG_font_shorthand_expanded_for_office']=True;p.write_text(json.dumps(data,indent=2))
(W/'review/SVG_OFFICE_FONT_NORMALIZATION.json').write_text(json.dumps(dict(status='EXPLICIT_ARIAL_FONT_ATTRIBUTES_WRITTEN',SVG_files=len(files),text_nodes=count,scope='Lossless expansion of CSS font shorthand; no text or data changes; final Word PDF proof required'),indent=2))
print('SVG_FONTS_NORMALIZED',len(files),count)

