from pathlib import Path
import json,re,hashlib,shutil,zipfile,datetime
from docx import Document
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';C=P/'02_Code_and_aggregate_data';A=P/'03_Author_review';B=W.parent/'cross_document_numeric_audit_20261108_v1/package'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
doc=json.loads((W/'review/DOCUMENT_BUILD.json').read_text());native=json.loads((P/'05_Figure_assets/JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json').read_text())
assert doc['main_figures']==5 and doc['main_tables']==0 and doc['main_body_words']<=3000
assert doc['supplement_figures']==24 and len(doc['image_sources'])==37
assert native['actual_minimum_text_pt']==10 and all(len(f['panels'])<=4 for f in native['figures'])
assert json.loads((W/'review/FINAL_DOCUMENT_NUMERIC_VERIFICATION.json').read_text())['status']=='PASS'
assert json.loads((W/'review/CHINESE_COMPANIONS_VERIFICATION.json').read_text())['legends']==29
for f in (S/'Chapters').glob('*_ZH.*'):
 if f.suffix in ['.md','.docx','.pdf']:shutil.copy2(f,P/'07_中文核对稿/分章节'/f.name)
shutil.copy2(S/'FIGURE_LEGENDS.md',S/'Chapters/FIGURE_LEGENDS.md')
old=A/'Historical_review_before_figure_redesign_20261109'
if not old.exists():shutil.move(str(A/'Current_revision_review'),old)
review=A/'Current_revision_review';review.mkdir(exist_ok=True)
for f in W.joinpath('review').glob('*.json'):
 if f.name.startswith(('REDESIGN_INTEGRATION','CONTACT_SHEETS','SEALED_PACKAGE','ARCHIVE_RECEIPT')):continue
 shutil.copy2(f,review/f.name)
for n in ['REFERENCE_VERIFICATION.csv','REFERENCE_VERIFICATION.json','REFERENCE_VERIFICATION_ZH.md','REFERENCE_NUMBERING_AND_COUNTS.json']:
 if (old/n).exists():shutil.copy2(old/n,review/n)
for n in ['FINAL_REVISION_ACCEPTANCE.json','REVISION_STATUS.json','CONTENTS_MANIFEST.json']:
 if (P/n).exists() and not (old/('ROOT_'+n)).exists():shutil.copy2(P/n,old/('ROOT_'+n))
p=W/'review/SKILL_AND_REFERENCE_USE_ZH.md'
p.write_text(p.read_text().replace('具体字号与嵌入后的实际尺寸另见验收记录；这些参数是本稿实现选择，不将其说成期刊强制色号或字号。','补图在最终Word中按170毫米原宽插入，实测全部Arial10号；长图按原面板跨页排布。图题12号、图注8号。主图采用单独矢量PDF。配色为本稿实现选择，未将其说成期刊强制色号。'))
shutil.copy2(p,review/p.name)
release=C/'figure_redesign_20261109_v1';release.mkdir(exist_ok=True)
active=['draw_main_figures.py','draw_supplement_figures.py','jno_native_panels.py','compose_jno_pages.py','sync_native_assets.py','build_current_documents.py','build_chinese_companions.py','build_track_changes.py','jno_document_format.py','render_current_documents.py','verify_and_render_chinese.py','audit_final_documents.py','nature_validate_figure.py','normalize_svg_fonts.py','finalize_figure_package.py']
for n in active:shutil.copy2(W/'code'/n,release/n)
shutil.copytree(W/'references',release/'SFL_reference_records',dirs_exist_ok=True)
for n in ['NEW_MAIN_FIGURES.json','NEW_SUPPLEMENT_FIGURES.json','FROZEN_SOURCE_PRESERVATION.json']:
 shutil.copy2(W/'review'/n,release/n)
(release/'README_ZH.md').write_text("""# 20261109 图形与文档代码

本目录补充重绘和文档代码；原研究全部分析代码及已验收补充分析保留于相邻analysis_sources、aggregate_data及原ANALYSIS_CODE.zip，不以补充绘图代码替代研究代码。

当前执行根为t630:/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/figure_redesign_20261109_v1/。脚本置于code/，输入package/为本包内容，fonts/为不分发的授权Arial字体。重现时需在单独工作目录建立相同布局并指定已有Arial字体；不得覆盖封存包。先运行draw_main_figures.py和draw_supplement_figures.py，再运行compose_jno_pages.py --root <工作目录>/jno_native，随后运行normalize_svg_fonts.py，再运行sync_native_assets.py。文档构建还依赖记录的共享解释器和原项目纯文本辅助函数。现有绝对路径和依赖均明示，未声称脱离该环境的一键独立安装。

绘图解释器：/home/lei/codex-workspaces/aki-prediction-manuscript/envs/prediction_gpu/bin/python
文档解释器：/home/lei/codex-workspaces/bmjopen-2026-125572-final-revision-20260914/envs/document-rebuild-20261011/bin/python
PDF组合解释器：/home/lei/codex-workspaces/shared-python-envs/envs/upar-structure-docking-py312-cpu-20261104-v1/bin/python

只读取已有汇总表；没有新增拟合或bootstrap。原始患者数据、凭证和字体文件不在代码包中。SFL图型参考的来源与固定提交见SFL_reference_records；未执行其模拟数据示例。
""")
z=P/'01_Journal_files/FIGURE_REDESIGN_CODE.zip'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED) as out:
 for f in sorted(release.rglob('*')):
  if f.is_file():out.write(f,str(f.relative_to(C)))
assert sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip')
p=C/'CODE_AVAILABILITY.md';t=p.read_text()
if '20261109 figure presentation' not in t:t+='\n\n## 20261109 figure presentation\nCurrent figure/document code is in figure_redesign_20261109_v1/ and FIGURE_REDESIGN_CODE.zip. This local presentation revision has not been pushed to GitHub. The frozen analysis archive is unchanged.\n'
p.write_text(t)
report=f"""# JAMA Network Open 图形与投稿包核对

本次完成5幅主图和24幅补图的呈现修订，所有图的总面板数均不超过4。正文{doc['main_body_words']}词，正文0张表，图表合计5项；两张可编辑三线表作为eTable 2和eTable 20的摘录置于附件。Key Points 80词，结构式摘要323词。研究类型保留回顾性临床队列，采用TRIPOD+AI报告框架。

主图为183毫米可编辑矢量PDF，白底、Arial及深色文字，蓝灰/橙/紫色。同类比较使用同尺度。汇总估计保留原区间，频率/计数使用并列柱形，资源情景和完整LLM结果用矩阵表达。没有为变化图型新增分析或模拟患者分布。

补图65个面板，按170毫米原宽排为37个矢量图页，实测所有内部文字Arial10号；图题Arial12号、图注Arial8号。已审阅全部37页、5幅主图及临床图形摘要，并复核三项标签和图例排版修复。SFL来源、实际技能及静态预检警告处理见本目录记录。

825个冻结来源文件与前一封存包逐字节一致。正文结果数字在去除图号后保持。52个物理Word表对应32个编号eTables，所有单元格与源文档一致；最终Word/PDF的91项检查通过。29条中英图注的显式数值对应。OOXML修订稿可接受为当前正文、拒绝为其记录的基线。新图具有单独源数据哈希与数值对象指纹，不沿用旧图的几何验收结论。

作者、伦理、基金、利益冲突、访问条件和AI使用历史仍须按真实文件确认，未把占位声明补为事实。此验收针对图形、文档格式和文件一致性，不代表期刊接收或已正式投稿。投稿文件位于01_Journal_files；历史图与验收明确归档于Historical目录。

期刊依据：https://jamanetwork.com/journals/jamanetworkopen/pages/instructions-for-authors （2026-11-09核对）
"""
(review/'FINAL_FIGURE_AND_PACKAGE_REVIEW_ZH.md').write_text(report)
(P/'README_ZH.md').write_text(f"""# JAMA Network Open 图形修订投稿包（20261109）

英文投稿文件：01_Journal_files；中文正文、图注和附信：07_中文核对稿；可编辑来源：04_Editable_sources；矢量图：05_Figure_assets；临床图形摘要：06_Graphical_abstract；全部既有代码及本次绘图代码：02_Code_and_aggregate_data。

正文{doc['main_body_words']}词，5幅主图，每幅4面板；两张三线表放入附件。附件包括32个编号eTables及24幅eFigures，每幅最多4面板。补图按Arial10号原尺寸排成37个图页，跨页不增加面板。29条图注均有中英文。

本轮重绘与文档核对见03_Author_review/Current_revision_review/FINAL_FIGURE_AND_PACKAGE_REVIEW_ZH.md。研究统计结果保持；新绘图代码随包提供，未另推送GitHub。历史版本与回执明确归档。

作者真实声明仍待作者确认，尚未正式投稿。
""")
accept=dict(status='PASS_FIGURE_REDESIGN_AND_DOCUMENT_CONSISTENCY',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),main_words=doc['main_body_words'],main_figures=5,main_tables=0,maximum_panels_per_figure=4,supplement_figures=24,supplement_panels=65,supplement_vector_pages=37,supplement_actual_minimum_font_pt=10,legends_English_Chinese=29,numbered_eTables=32,physical_Word_tables=52,document_checks=91,frozen_source_files_unchanged=825,new_model_fits=0,new_bootstrap=0,author_real_declarations_confirmed=False,formal_submission=False,report='03_Author_review/Current_revision_review/FINAL_FIGURE_AND_PACKAGE_REVIEW_ZH.md',documents_sha256={str(f.relative_to(P)):sha(f) for f in (P/'01_Journal_files').glob('*') if f.is_file()})
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(accept,indent=2))
(P/'REVISION_STATUS.json').write_text(json.dumps(dict(status=accept['status'],author_review_required=True,formal_submission=False,final_receipt='FINAL_REVISION_ACCEPTANCE.json'),indent=2))
sourceindex=[dict(path=str(f.relative_to(C)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(C.rglob('*')) if f.is_file() and f!=C/'CURRENT_SOURCE_INDEX.json']
(C/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps(sourceindex,indent=2))
manifest=[dict(path=str(f.relative_to(P)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(P.rglob('*')) if f.is_file() and f!=P/'CONTENTS_MANIFEST.json']
(P/'CONTENTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for r in manifest:assert sha(P/r['path'])==r['sha256'],r['path']
receipt=dict(status='SEALED_VERIFIED',files=len(manifest)+1,manifest_sha256=sha(P/'CONTENTS_MANIFEST.json'),package=str(P),bytes=sum(x['bytes'] for x in manifest)+(P/'CONTENTS_MANIFEST.json').stat().st_size)
(W/'review/SEALED_PACKAGE.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))

