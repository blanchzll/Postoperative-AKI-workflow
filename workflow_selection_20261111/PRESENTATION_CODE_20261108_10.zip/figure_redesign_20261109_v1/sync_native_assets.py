from pathlib import Path
import shutil,json,hashlib,re
W=Path(__file__).resolve().parents[1];P=W/'package';F=P/'05_Figure_assets';N=W/'jno_native'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
j=json.loads((N/'PAGE_AND_PANEL_MANIFEST.json').read_text())
assert j['figures_count']==24 and j['actual_minimum_text_pt']==10
for i in range(1,6):
 key=f'Figure_{i}'
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(W/'figures'/f'{key}.{ext}',F/key/f'{key}.{ext}')
 shutil.copytree(W/'figures/panels'/key,F/'Independent_panels'/key,dirs_exist_ok=True)
 shutil.copy2(W/'figures'/f'{key}.pdf',P/'01_Journal_files'/f'FIGURE_{i}.pdf')
old=W/'review/flat_supplement_assets_before_Arial10';old.mkdir(exist_ok=True)
for i in range(1,25):
 key=f'eFigure_{i}';folder=F/key
 if folder.exists():
  if not (old/key).exists():shutil.move(str(folder),old/key)
  else:shutil.rmtree(folder)
 folder.mkdir()
 shutil.copy2(N/'composites'/f'{key}.pdf',folder/f'{key}.pdf')
 (folder/'README_ZH.md').write_text('本图的Arial10号矢量图页及可编辑SVG见../JNO_VECTOR_PAGES/pages/；当前PDF为相同原尺寸图页的合并文件。每幅补图的总面板数不超过4，跨页不会新增面板。\n')
 panel=F/'Independent_panels'/key
 if panel.exists():shutil.rmtree(panel)
 shutil.copytree(N/'panels'/key,panel)
v=F/'JNO_VECTOR_PAGES'
if v.exists():
 hist=W/'review/vector_pages_before_Arial10'
 if not hist.exists():shutil.move(str(v),hist)
 else:shutil.rmtree(v)
shutil.copytree(N,v)
j['final_visual_review']='Inspected all37 vector pages via contact sheets; three formatting repairs separately checked'
(v/'PAGE_AND_PANEL_MANIFEST.json').write_text(json.dumps(j,indent=2))
index=json.loads((F/'FIGURE_SOURCE_INDEX.json').read_text())
for x in index:
 key=x['label'].replace(' ','_');base=F/key
 assets=list(base.glob('*'))
 if key.startswith('eFigure'):
  assets += [v/p[k] for p in j['pages'] if p['figure']==key for k in ['svg','pdf','png']]
  x['panels']=next(p['panels'] for p in j['figures'] if p['figure']==key)
  x['native_font_pt']=10;x['native_width_mm']=170
 x['assets']={str(p.relative_to(P)):sha(p) for p in assets if p.is_file()}
(F/'FIGURE_SOURCE_INDEX.json').write_text(json.dumps(index,indent=2))
# Use the actual page count in the document acceptance checks.
p=W/'code/audit_final_documents.py';s=p.read_text()
s=s.replace("ck('24 native vector pages in Word',len(sd.inline_shapes)==24)","npages=len(json.loads((P/'05_Figure_assets/JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json').read_text())['pages']);ck('all native vector pages in Word',len(sd.inline_shapes)==npages)")
s=s.replace("ck('24 SVGs',len(svg)==24)","ck('all native SVGs',len(svg)==npages)")
p.write_text(s)
print(json.dumps(dict(status='NATIVE_ARIAL10_ASSETS_SYNCHRONIZED',figures=24,pages=j['pages_count'],panels=j['panels_count'])))
