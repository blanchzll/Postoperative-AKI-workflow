# 20261109 图形与文档代码

本目录补充重绘和文档代码；原研究全部分析代码及已验收补充分析保留于相邻analysis_sources、aggregate_data及原ANALYSIS_CODE.zip，不以补充绘图代码替代研究代码。

当前执行根为t630:/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/figure_redesign_20261109_v1/。脚本置于code/，输入package/为本包内容，fonts/为不分发的授权Arial字体。重现时需在单独工作目录建立相同布局并指定已有Arial字体；不得覆盖封存包。先运行draw_main_figures.py和draw_supplement_figures.py，再运行compose_jno_pages.py --root <工作目录>/jno_native，随后运行normalize_svg_fonts.py，再运行sync_native_assets.py。文档构建还依赖记录的共享解释器和原项目纯文本辅助函数。现有绝对路径和依赖均明示，未声称脱离该环境的一键独立安装。

绘图解释器：/home/lei/codex-workspaces/aki-prediction-manuscript/envs/prediction_gpu/bin/python
文档解释器：/home/lei/codex-workspaces/bmjopen-2026-125572-final-revision-20260914/envs/document-rebuild-20261011/bin/python
PDF组合解释器：/home/lei/codex-workspaces/shared-python-envs/envs/upar-structure-docking-py312-cpu-20261104-v1/bin/python

只读取已有汇总表；没有新增拟合或bootstrap。原始患者数据、凭证和字体文件不在代码包中。SFL图型参考的来源与固定提交见SFL_reference_records；未执行其模拟数据示例。
