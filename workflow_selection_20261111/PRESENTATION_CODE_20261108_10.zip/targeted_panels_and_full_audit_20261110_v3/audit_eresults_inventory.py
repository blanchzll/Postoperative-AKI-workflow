
from pathlib import Path
import csv,re,json,math,collections,hashlib,bisect
from decimal import Decimal
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';S=P/'04_Editable_sources'
def rows(rel):return list(csv.DictReader((C/rel).open()))
def src(n):return 'aggregate_data/source_data/'+n+'.csv'
# Each eResults section is assigned its relevant result family before matching.
maps={
1:[src('F1_partitions'),'clinical_supplement_20261108_v1/results/COHORT_OPERATION_PATIENT_COUNTS.csv'],
2:[src('S9_ALL_ORIGINAL_PAIRED_METRICS'),src('F2_preoperative_differences')],
3:[src('Table_3_stage_and_input_differences'),'aggregate_data/supplement/aggregate_tables/supplement_tables/S5_overlap/process_resolution_20261025_v1/NONOVERLAP_SUPPORT.csv'],
4:[src('Workload_all250_operating_rules'),src('Workload_all2250_scenarios'),src('Workload_all2325_hypothetical_effects')],
5:[src('F5_public_model_points'),src('Coded9_SOURCE_THRESHOLD_COVERAGE'),src('Public_source_thresholds_long')],
6:[src('S2_calibration_update_points'),src('S2_calibration_update_support'),src('Policy_fixed_random_all16')],
7:[src('S3_POD1_LR_differences'),src('S3_POD1_LR_points')],
8:[src('S7_ALT_all_metrics')],
9:[src('S5_conditional_stability')],
10:[],
11:[],
12:[src('LLM_all54_comparisons_all_metrics'),src('S4_LLM_all24_calibrated_points')],
13:[src('S9_MARGIN_SENSITIVITY'),src('S9_CROSS_CONTEXT_SENSITIVITY'),src('S9_TIPPING_POINT_SUMMARY'),src('S9_PERFORMANCE_SUPPORT'),src('S9_ALL_ORIGINAL_PAIRED_METRICS')],
14:[],
15:[src('Translation_geography_BRIDGE_INTERVALS'),src('Translation_temporal_BRIDGE_INTERVALS'),src('Translation_INSPIRE_common6_INCREMENT_POINTS'),src('Translation_geography_preop_INCREMENT_POINTS'),src('Translation_temporal_preop_INCREMENT_POINTS')],
16:[src('Coded9_HISTORY_COUNTS'),src('Coded9_PAIRED_DIFFERENCES_VS_SIX_RF'),src('Coded9_POINT_ESTIMATES'),src('Coded9_SOURCE_THRESHOLD_COVERAGE'),src('Coded9_HISTORY_CODEBOOK')],
17:['aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv','aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv','probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv',src('Translation_geography_preop_INCREMENT_POINTS'),src('Translation_temporal_preop_INCREMENT_POINTS')],
18:['aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv','aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv','aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv','measurement_consistency_20261104_v1/aggregates/WRITING_ELIGIBLE_AGGREGATES.csv','measurement_consistency_20261104_v1/aggregates/WINDOW_QUALIFICATION.csv'],
19:[]}
maps[18]+=[src('Coded9_POINT_ESTIMATES'),src('Coded9_PAIRED_DIFFERENCES_VS_SIX_RF'),src('Coded9_SOURCE_THRESHOLD_COVERAGE')]
# Supplementary clinical results are finite aggregate files, never patient records.
maps[19]=[str(p.relative_to(C)) for p in (C/'clinical_supplement_20261108_v1/results').glob('*.csv')]
# Relevant rendered eTable sections also bind numerical descriptions and conventional units.
ts={int(m[1]):m[2] for m in re.finditer(r'^## eTable (\d+)\.(.*?)(?=^## eTable |\Z)',(S/'ETABLES.md').read_text(),re.M|re.S)}
tabs={1:[2,15],2:[3,19],3:[4],4:[18],5:[6,7],6:[13,14],7:[15],8:[16],9:[17],10:[16],11:[8],12:[9],13:[12,19],14:[2,10],15:[5,11],16:[6,7],17:[20,21],18:[22,23,24],19:list(range(25,33))}
# Protocol constants and result-file dimensions are classified separately from estimates.
constants={1:[3710,205,3693,2428,138,2411,2947,39,273,272,9,27,38,6],
2:[39,10,20,27,9,1000,95],3:[20,1000,738,29],4:[250,2250,2325,10,20,5,15,0,.5,1,.75,-.1,.2,.1,.3],
5:[20,10,80,100],6:[12,16,50],7:[22,132,1],8:[20],9:[10,200,20,10,90],10:[44],
14:[27],12:[24,54],13:[20,10,27,9,1000,5,7,0,.5,3,84,42,4,6,78],15:[12,20,10,32,2,8,50,80,95],
16:[9,6,54,27,42,47,49,8,20,80,1000,95],17:[5208,168,20,95,1000,0,.05,.01,.30,2,5,240,48,10,9,27,38,6],18:[20,80,3,7,1,2],19:[20,9,27,38,6,3,5,7,0,48,2,90,95]}
npat=r'(?<![A-Za-z_])[-−]?\d[\d,]*(?:\.\d+)?'
def nums(s):return re.findall(npat,s.replace('–',' ').replace('−','-'))
def equal(s,v):
 try:
  d=Decimal(s.replace(',',''));v=Decimal(str(v))
  return v.is_finite() and abs(d-v)<=Decimal(10)**d.as_tuple().exponent/2+Decimal('1e-10')
 except:return False
inv=[];unmatched=[];sources={}
res=(S/'ERESULTS.md').read_text()
for m in re.finditer(r'^## (\d+)\. ([^\n]+)\n(.*?)(?=^## \d+\.|^## Graphical|\Z)',res,re.M|re.S):
 sec=int(m[1]);pool=[]
 for rel in maps[sec]:
  pp=C/rel;assert pp.exists(),rel
  sources[rel]=hashlib.sha256(pp.read_bytes()).hexdigest()
  rr=rows(rel)
  for i,r in enumerate(rr,2):
   key={k:r[k] for k in ['context','model','comparison_id','comparison','metric','source_line','population','policy','probability','reference'] if k in r}
   for k,v in r.items():
    try:
     z=float(v)
     if math.isfinite(z):
      pool.append((v,rel,i,k,key))
      if 'per1000' in (k+r.get('metric','')) and 'review' in (k+r.get('metric','')):pool.append((str(z/10),rel,i,k+' ÷10 to percent',key))
      if any(x in k.lower() for x in ['rate','sensitivity','p_win','p_tie','p_loss','p_infeasible','fraction','percent','proportion','wilson','lo','hi']):pool.append((str(100*z),rel,i,k+' ×100',key))
    except:pass
 for n in tabs[sec]:
  for li,line in enumerate(ts[n].splitlines(),1):
   if line.startswith('|'):
    for v in nums(line):pool.append((v.replace(',',''),f'eTable {n}',li,'displayed table',{}))
 pool.sort(key=lambda x:float(x[0]));sorted_values=[float(x[0]) for x in pool]
 s=re.sub(r'\be?(?:Table|Figure)s?\s+\d+(?:[–\-]\d+)?','',m[3])
 s=re.sub(r'(?i)\bSection \d+\b','',s)
 for mt in re.finditer(npat,s.replace('–',' ').replace('−','-')):
  token=mt[0];d=Decimal(token.replace(',',''));v=float(d);tol=float(Decimal(10)**d.as_tuple().exponent/2)+1e-10
  matches=pool[bisect.bisect_left(sorted_values,v-tol):bisect.bisect_right(sorted_values,v+tol)]
  row=dict(section=sec,number=token,context=s[max(0,mt.start()-60):mt.end()+65],status='SOURCE_MATCH' if matches else 'PROTOCOL_OR_DIMENSION' if any(equal(token,c) for c in constants.get(sec,[])) else 'REVIEW',
           matches=[dict(source=x[1],row=x[2],field=x[3],source_value=x[0],row_key=x[4]) for x in matches[:4]])
  inv.append(row)
  if row['status']=='REVIEW':unmatched.append(row)
(W/'review/ERESULTS_NUMBER_INVENTORY.json').write_text(json.dumps(inv,ensure_ascii=False,indent=2))
(W/'review/ERESULTS_NUMBER_REVIEW.json').write_text(json.dumps(unmatched,ensure_ascii=False,indent=2))
(W/'review/ERESULTS_INVENTORY_SOURCE_HASHES.json').write_text(json.dumps(sources,indent=2))
print(json.dumps(dict(number_occurrences=len(inv),source_match=sum(x['status']=='SOURCE_MATCH' for x in inv),protocol_or_dimension=sum(x['status']=='PROTOCOL_OR_DIMENSION' for x in inv),review=len(unmatched))))
print(json.dumps(unmatched,ensure_ascii=False,indent=2))

