from pathlib import Path
import csv,json,re,hashlib,math
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';B=W.parent/'composite_main_figures_20261109_v2/package'
meta=json.loads((W/'review/COMPOSITE_MAIN_FIGURES.json').read_text());checks=[];cache={}
def rows(path):
 if path not in cache:
  with (C/path).open() as f:cache[path]=list(csv.DictReader(f))
 return cache[path]
def row(path,**kw):
 rr=[x for x in rows(path) if all(x[k]==str(v) for k,v in kw.items())];assert len(rr)==1,(path,kw,len(rr));return rr[0]
def values(r,val='estimate',lo='lower95',hi='upper95',sign=1):
 v=float(r[val])*sign
 if lo not in r:return v,None,None
 ends=sorted([float(r[lo])*sign,float(r[hi])*sign]);return v,ends[0],ends[1]
cap='aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv'
bnd='aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv'
pri='aggregate_data/source_data/Primary_model_intervals.csv'
pro='probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv'
pp='aggregate_data/source_data/Coded9_POINT_ESTIMATES.csv'
cov='aggregate_data/source_data/Coded9_SOURCE_THRESHOLD_COVERAGE.csv'
di='aggregate_data/source_data/Coded9_PAIRED_DIFFERENCES_VS_SIX_RF.csv'
mi='aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv'
mp='aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv'
cut='aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv'
dele='clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv'
ids=['geography_9v27_champ','temporal_9v27_champ','geography_27v38_champ','temporal_27v38_champ'];names=['Geo 9→27','Time 9→27','Geo 27→38','Time 27→38']
for x in meta['ledger']:
 f,p,k=x['figure'],x['panel'],x['label'];v=lo=hi=None
 if f==1 and p=='B':
  v,lo,hi=values(row('aggregate_data/source_data/Table_3_stage_and_input_differences.csv',model=k,metric='AUROC'))
 elif f==1 and p=='C':
  ctx,kind=k.split(':');path='aggregate_data/source_data/Translation_'+ctx+'_CAPTURE_REVIEW_CURVE.csv'
  v=len([r for r in rows(path) if 'preop_'+kind+'_champion' in r['model']])
 elif f==1 and p=='D':v,lo,hi=values(row(cap,comparison_id=k),val='delta_captured_per1000',lo='delta_captured_per1000_lower95',hi='delta_captured_per1000_upper95')
 elif f==2 or f==3 and p in ['A','B']:v,lo,hi=values(row(bnd,comparison_id=k,mode='calibrated',budget_percent=20),val='signed_allowable_extra_cost_per1000')
 elif f==3 and p=='C':v=float(row(bnd,comparison_id=ids[names.index(k)],mode='calibrated',budget_percent=20)[x['source_key']])
 elif f==3 and p=='D':
  cid,law=k.split(':');v,lo,hi=values(row(pro,comparison=cid,distribution=law),val='mean_delta_per1000_fallback',lo='mean_delta_per1000_fallback_patient_lower95',hi='mean_delta_per1000_fallback_patient_upper95')
 elif f==4 and p=='B':
  line,metric=k.split(':');models={r['model'] for r in rows(di) if r['model'].startswith(line+'__') and '__calibrated' in r['model']};assert len(models)==1
  v,lo,hi=values(row(di,model=next(iter(models)),metric=metric),sign=-1 if metric=='Brier' else 1)
 elif f==4 and p=='C':v=float(row(pp,model=k)['capacity20_captured_n'])
 elif f==4 and p=='D':
  line,kind,*_=k.split('__');v=float(row(cov,source_line=line,model=kind)[x['source_key'].split(':')[-1]])
 elif f==5 and p=='B':
  line,mode=k.split(':');v,lo,hi=values(row(mi,model=line+'__'+mode,metric='Brier'))
 elif f==5 and p=='C':
  line,rule=k.split(':');metric='reviewed_n' if x['source_key'].endswith('reviewed_n') else 'captured_n'
  if rule=='Target 20%':v=float(row(mp,model=line+'__calibrated')['capacity20_'+metric])
  else:v=float(row(cut,source_line=line,rule='training_capacity20' if rule=='Source 20%' else 'training_sensitivity80',metric=metric)['estimate'])
 elif f==5 and p=='D':
  pop,mode=k.split(':');r=row(dele,population=pop,mode=mode)
  if x['source_key'].endswith('deleted_fraction'):v=float(r['deleted_fraction'])
  else:v,lo,hi=values(r,val='lost_known_fraction',lo='lost_event_Wilson_lo',hi='lost_event_Wilson_hi')
 else:raise RuntimeError(('Unhandled ledger binding',x))
 for actual,expected in [(x['value'],v),(x['lower95'],lo),(x['upper95'],hi)]:
  assert (actual is None and expected is None) or (actual is not None and expected is not None and math.isclose(actual,expected,rel_tol=1e-12,abs_tol=1e-12)),(x,expected)
 checks.append(dict(figure=f,panel=p,label=k,status='PASS'))
for rel,h in meta['source_csvs'].items():assert hashlib.sha256((C/rel).read_bytes()).hexdigest()==h,rel
preserved=[]
for folder in ['aggregate_data','analysis_sources','clinical_supplement_20261108_v1/results','probabilistic_resource_analysis_20261105_v1/aggregate_data']:
 for path in (B/'02_Code_and_aggregate_data'/folder).rglob('*'):
  if path.is_file():
   f=P/path.relative_to(B);assert path.read_bytes()==f.read_bytes()
   preserved.append(dict(path=str(f.relative_to(P)),sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
a=(B/'04_Editable_sources/MANUSCRIPT_EN.md').read_text().split('## Results\n')[1].split('## Discussion\n')[0]
b=(P/'04_Editable_sources/MANUSCRIPT_EN.md').read_text().split('## Results\n')[1].split('## Discussion\n')[0]
strip=lambda s:re.sub(r'\([^()]*?(?:eFigure|Figure|eTable)[^()]*\)','',s)
nums=lambda s:re.findall(r'[-−]?\d[\d,]*(?:\.\d+)?',strip(s))
assert nums(a)==nums(b),'Result numbers changed'
# All supplement graphics are unchanged; only two caption identities were corrected.
for n in range(1,25):
 for p in (B/f'05_Figure_assets/eFigure_{n}').rglob('*'):
  if p.is_file():assert p.read_bytes()==(P/p.relative_to(B)).read_bytes(),p
out=dict(status='PASS_COMPOSITE_FIGURE_KEYED_NUMERICAL_BINDINGS_AND_FROZEN_SOURCE_PRESERVATION',keyed_numeric_bindings=len(checks),source_CSVs=len(meta['source_csvs']),frozen_files=len(preserved),all_supplement_graphic_files_unchanged=True,result_numbers_unchanged=True,new_fits=0,new_bootstrap=0,checks=checks,source_preservation=preserved)
(W/'review/COMPOSITE_NUMERIC_VERIFICATION.json').write_text(json.dumps(out,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','source_preservation']}))

