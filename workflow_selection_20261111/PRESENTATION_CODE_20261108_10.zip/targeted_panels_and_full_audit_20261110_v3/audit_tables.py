from pathlib import Path
import re,json,csv,hashlib,math,collections
from decimal import Decimal
W=Path(__file__).resolve().parents[1]
P=W/'package';C=P/'02_Code_and_aggregate_data';S=P/'04_Editable_sources'
checks=[];issues=[];ledger=[]
def check(label,passed,detail=None):
 checks.append(dict(check=label,passed=bool(passed),detail=detail))
 if not passed:issues.append(dict(check=label,detail=detail))
def tables(text):
 out=[]; current=[]
 for l in text.splitlines()+['']:
  if l.startswith('|'):
   vals=[v.strip() for v in l.strip('|').split('|')]
   if not all(re.fullmatch(r'[: -]+',v or ' ') for v in vals): current.append(vals)
  elif current:out.append(current);current=[]
 return out
def sections(text):
 return {int(m[1]):m[2] for m in re.finditer(r'^## eTable (\d+)\.(.*?)(?=^## eTable |\Z)',text,re.M|re.S)}
def nums(s):
 s=s.replace('−','-').replace('–',' ').replace('×',' ').replace(',','') if not '(' in s else s.replace('−','-').replace('–',' ')
 # thousands separators only, retain CI commas
 s=re.sub(r'(?<=\d),(?=\d{3}\b)', '',s)
 return re.findall(r'(?<![A-Za-z_])[-+]?\d+(?:\.\d+)?(?:[eE][-+]?\d+)?',s)
def numeric_equal(a,b):
 aa=nums(a);bb=nums(b)
 if len(aa)!=len(bb): return False
 for x,y in zip(aa,bb):
  dx,dy=Decimal(x),Decimal(y)
  tol=Decimal(10)**dx.as_tuple().exponent/2 if '.' in x else Decimal('0.5') if ('.' in y and Decimal(y)!=int(Decimal(y))) else Decimal('0.00000001')
  if abs(dx-dy)>tol+Decimal('0.000000001'):return False
 return True
def compare_rows(n,expected,source):
 actual=tables(sections((S/'ETABLES.md').read_text())[n]);exp=tables(expected)
 check(f'eTable{n}:table_count',len(actual)==len(exp),[len(actual),len(exp)])
 for ti,(at,ex) in enumerate(zip(actual,exp),1):
  check(f'eTable{n}:table{ti}:row_count',len(at)==len(ex),[len(at),len(ex)])
  for ri,(ar,er) in enumerate(zip(at[1:],ex[1:]),1):
   if len(ar)!=len(er):
    check(f'eTable{n}:table{ti}:row{ri}:columns',False,[ar,er]);continue
   for ci,(a,e) in enumerate(zip(ar,er),1):
    if not nums(a) and not nums(e):continue
    ok=numeric_equal(a,e);label=f'eTable{n}:table{ti}:row{ri}:column{ci}'
    check(label,ok,dict(current=a,source=e) if not ok else None)
    ledger.append(dict(location=label,current=a,source_value=e,source=str(source),status='PASS' if ok else 'REVIEW'))
base=(C/'document_code/assemble_supplement_text.py').read_text()
part=base[base.index('def read(rel):'):base.index('assert set(tables)')]
old=W.parent/'manuscript_final_20261031_v1/supplement/SUPPLEMENTARY_TABLES_EN.md'
part=part.replace("(B/'supplement/SUPPLEMENTARY_TABLES_EN.md').read_text()",repr(old.read_text()))
env=dict(Path=Path,json=json,re=re,csv=csv,B=C/'aggregate_data',conv=lambda s:s)
exec(compile(part,'<read-only table reconstruction>','exec'),env)
for n,(title,body) in env['tables'].items():
 if n==4:continue
 if n==2:
  f=C/'aggregate_data/tables/Table_1_Clinical_characteristics.csv'
  rr=list(csv.DictReader(f.open()));body=env['table'](list(rr[0]),[list(r.values()) for r in rr])+'\n\n'+body
 compare_rows(n,body,env['sources'][str(n)])
# Reconstruct the later clinical tables only; no file-copy or manuscript-edit code is executed.
clinical=(C/'document_code/current_revision_20261108/integrate_clinical_supplement.py').read_text()
defs=clinical[clinical.index('def num('):clinical.index("context={'geography_preop'")]
contextpart=clinical[clinical.index("context={'geography_preop'"):clinical.index('# Copy only aggregate tables')]
part=clinical[clinical.index('# New supplementary tables'):clinical.index("et=S/'ETABLES.md'")]
env2=dict(Path=Path,csv=csv,re=re)
exec(defs+contextpart,env2)
def read(name):
 return list(csv.DictReader((C/'clinical_supplement_20261108_v1/results'/name).open()))
env2['read']=read
part=part.replace("ci(r,'observed_low_risk_event_rate','wilson_lo','wilson_hi')","ci(r,'observed_low_risk_event_rate','patient_boot_lo','patient_boot_hi') if int(r['low_risk_events'])>0 else ci(r,'observed_low_risk_event_rate','wilson_lo','wilson_hi')")
part=part.replace("if ds:","if ds and r['policy']!='no_collection':")
exec(compile(part,'<read-only clinical table reconstruction>','exec'),env2)
for text in env2['b']:
 for n,body in sections(text).items():compare_rows(n,body,'clinical_supplement_20261108_v1/results; original per-row construction')
# eTable4 explicit comparison direction / metric / capacity map
actual=tables(sections((S/'ETABLES.md').read_text())[4])[0][1:]
src=list(csv.DictReader((C/'aggregate_data/tables/Table_S19_Stage_comparisons.csv').open()))
check('eTable4 28 source rows',len(actual)==len(src)==28)
for i,(a,r) in enumerate(zip(actual,src),1):
 for col,key in [(5,'estimate'),(6,'lower95'),(7,'upper95')]:
  check(f'eTable4 row{i} {key}',numeric_equal(a[col],r[key]),None if numeric_equal(a[col],r[key]) else [a,r])
  ledger.append(dict(location=f'eTable4 row{i} {key}',current=a[col],source_value=r[key],source='aggregate_data/tables/Table_S19_Stage_comparisons.csv',status='PASS' if numeric_equal(a[col],r[key]) else 'REVIEW'))
(W/'review/TABLE_NUMERIC_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(W/'review/TABLE_NUMERIC_LEDGER.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
(W/'review/TABLE_REVIEW_ITEMS.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2))
print(json.dumps(dict(checks=len(checks),cell_ledger=len(ledger),issues=len(issues)),ensure_ascii=False))
print(json.dumps(issues[:45],ensure_ascii=False,indent=2))

