from pathlib import Path
import json,re,csv,collections,hashlib,zipfile
from docx import Document
from pypdf import PdfReader
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';checks=[]
def ck(k,v,detail=None):
 checks.append(dict(check=k,status='PASS' if v else 'FAIL',details=detail));assert v,(k,detail)
def tables(text):
 out=[];cur=[]
 for l in text.splitlines()+['']:
  if l.startswith('|'):
   r=[c.strip() for c in l.strip('|').split('|')]
   if not all(re.fullmatch('[: -]+',x or ' ') for x in r):cur.append(r)
  elif cur:out.append(cur);cur=[]
 return out
def norm(s):
 s=re.sub(r'(?m)^\s*\d+\s*$', '',s)
 return re.sub(r'\s+','',s.replace('\u00ad','').replace('\xa0',' ')).replace('**','')

def display(s):
 return s.replace('preop_full_champion_','27-input ').replace('preop_compact_champion_','9-input ').replace('endop_full_champion_','38-input ').replace('_',' ').replace('geography','geographic').replace('**','').replace('`','').lower()
m=(S/'MANUSCRIPT_EN.md').read_text()
paras=[x for x in m.split('## Results')[1].split('## Discussion')[0].split('\n\n') if x.strip() and not x.strip().startswith('#')]
main=Document(P/'01_Journal_files/MANUSCRIPT.docx');word=[p.text for p in main.paragraphs]
for i,p in enumerate(paras,1):ck('English Results paragraph '+str(i)+' in final Word',p.strip() in word)
ck('main Wilson interval explicit',any('11.9%; Wilson 95% CI, 5.9%–22.5%' in x for x in word))
ck('main outdated bootstrap-only interval absent',not any('11.9%; 95% CI, 4.3%–20.4%' in x for x in word))
sd=Document(P/'01_Journal_files/SUPPLEMENT_1.docx');mts=tables((S/'ETABLES.md').read_text());ck('52 physical tables for32 numbered eTables',len(mts)==len(sd.tables)==52)
for i,(mt,wt) in enumerate(zip(mts,sd.tables),1):
 rows=[[c.text for c in r.cells] for r in wt.rows]
 ck('all table cells in Word table '+str(i),[[display(c) for c in r] for r in rows]==[[display(c) for c in r] for r in mt],None if rows==mt else dict(source_rows=len(mt),Word_rows=len(rows),allowed='underscores displayed as spaces'))
ck('both SCr interval methods identified in supplement',any('Wilson 95% CI, 5.9%–22.5%; patient-bootstrap 95% CI, 4.3%–20.4%' in p.text for p in sd.paragraphs))
npages=len(json.loads((P/'05_Figure_assets/JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json').read_text())['pages']);ck('all native vector pages in Word',len(sd.inline_shapes)==npages)
with zipfile.ZipFile(P/'01_Journal_files/SUPPLEMENT_1.docx') as z:
 svg=[z.read(n) for n in z.namelist() if n.startswith('word/media/') and n.endswith('.svg')]
 ck('all native SVGs',len(svg)==npages)
 ck('updated flow SVG embedded',any(b'Screened source' in x for x in svg))
 ck('old Adults flow label absent',not any(b'>Adults<' in x for x in svg))
for name in ['MANUSCRIPT','SUPPLEMENT_1','FIGURE_LEGENDS','COVER_LETTER']:
 f=P/'01_Journal_files'/(name+'.pdf');r=PdfReader(f);ck(name+' PDF readable',len(r.pages)>0)
 if name=='MANUSCRIPT':
  text='\n'.join(p.extract_text() or '' for p in r.pages);ck('final main PDF Wilson result',norm('11.9%; Wilson 95% CI, 5.9%–22.5%') in norm(text))
 if name=='SUPPLEMENT_1':
  text='\n'.join(p.extract_text() or '' for p in r.pages);ck('final supplement PDF corrected source label','Screened source' in text)
for f in [P/'03_Author_review/MANUSCRIPT_ZH.docx',P/'07_中文核对稿/正文_中文核对稿.docx',S/'Chapters/RESULTS_ZH.docx']:
 d=Document(f);ss='\n'.join(p.text for p in d.paragraphs)
 ck(str(f.relative_to(P))+' correct CI','11.9%；Wilson 95%CI，5.9%至22.5%' in ss)
 ck(str(f.relative_to(P))+' corrected exclusion unit','303条记录' in ss and '303名成人' not in ss)
ck('English main results source same as independent chapter',paras[-1].strip() in [p.text for p in Document(S/'Chapters/RESULTS_EN.docx').paragraphs])
for f in [P/'07_中文核对稿/正文_中文核对稿.pdf',P/'03_Author_review/MANUSCRIPT_ZH.pdf']:
 text='\n'.join(p.extract_text() or '' for p in PdfReader(f).pages)
 ck(str(f.relative_to(P))+' PDF updated CI',norm('Wilson 95%CI，5.9%至22.5%') in norm(text))
# Main table extracts must equal their two corresponding full supplementary tables.
full=(S/'ETABLES.md').read_text();ext=(S/'MAIN_TABLES.md').read_text()
for en,fn in zip(tables(ext),[tables(full.split('## eTable 2.')[1].split('## eTable 3.')[0])[0],tables(full.split('## eTable 20.')[1].split('## eTable 21.')[0])[0]]):ck('editable main-table extract matches full supplement',en==fn)
(W/'review/FINAL_DOCUMENT_NUMERIC_VERIFICATION.json').write_text(json.dumps(dict(status='PASS',checks=checks,main_words=len(m.split('## Introduction\n')[1].split('## Acknowledgment')[0].split()),physical_tables=52,numbered_eTables=32,Word_result_paragraphs=14,English_and_Chinese=True),ensure_ascii=False,indent=2))
print(json.dumps(dict(status='PASS',checks=len(checks),all_Word_tables_matched=len(mts),main_result_paragraphs=14)))

