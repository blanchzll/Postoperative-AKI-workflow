
from pathlib import Path
import json,re,shutil,hashlib
from xml.etree import ElementTree as ET
W=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/targeted_panels_20261110_v3');P=W/'package';S=P/'04_Editable_sources';F=P/'05_Figure_assets';B=W.parent/'composite_main_figures_20261109_v2'
hist=P/'03_Author_review/Historical_before_targeted_panels_20261110_v3';hist.mkdir(exist_ok=True)
for n in ['CONTENTS_MANIFEST.json','FINAL_REVISION_ACCEPTANCE.json','REVISION_STATUS.json']:
 p=P/n
 if p.exists():shutil.move(str(p),hist/n)
p=P/'03_Author_review/Current_revision_review'
if p.exists():shutil.move(str(p),hist/'Prior_current_revision_review')
changes=[]
def change(file,old,new,reason):
 p=S/file;s=p.read_text();assert old in s,(file,old)
 s=s.replace(old,new);p.write_text(s);changes.append(dict(file=file,before=old,after=new,reason=reason))
change('EMETHODS.md','303 adult records with insufficient renal information','303 records with insufficient renal information','One excluded record has unrecorded age; direct-source counts verified.')
change('EMETHODS.md','The full 54-category codebook is supplied in eTable 6.','The full 54-category codebook is supplied in the aggregate file Coded9_HISTORY_CODEBOOK.csv.','eTable6 contains eight metric views; exact categories are in the CSV.')
change('EMETHODS.md','Exact categories and all raw/calibrated views are given in eTable 6.','Exact categories are retained in Coded9_HISTORY_CODEBOOK.csv; all raw/calibrated views are given in eTable 6.','Distinguish codebook from metric table.')
change('EMETHODS.md','## Exploratory performance-loss reference margins\n\n## Representative virtual clinical use','## Representative virtual clinical use','Remove empty duplicated subsection; complete margin method retained in section7.')
change('ERESULTS.md','Figure 4 shows calibrated AUROC and Brier, paired 20% capture differences, and the source-sensitivity-80% operating rule with selected records, captured events and actual target sensitivity together.',
       'Figure 4 shows released coded-history counts, paired AUROC/AP/Brier differences, empirical capture–review curves, and source-sensitivity-80% operating points alongside target-ranked 20% capacity. Labels report selected records and captured events.','Align description with current Figure4A–D.')
change('ERESULTS.md','described in S16.','described in Section 16.','Current section numbering.')
change('ERESULTS.md','views in S16','views in Section 16','Current section numbering.')
change('FIGURE_LEGENDS.md','Scenario-based work and event-effect quantities are presented in eFigure 13.','Scenario-based work and event-effect quantities are presented in eFigure 12.','eFigure13 is calibration; scenarios are eFigure12.')
change('FIGURE_LEGENDS_ZH.md','情景工作量及事件效应量见eFigure 13。','情景工作量及事件效应量见eFigure 12。','Chinese cross-reference matches scenario figure.') if '情景工作量及事件效应量见eFigure 13。' in (S/'FIGURE_LEGENDS_ZH.md').read_text() else None
# Record exact matching Chinese cross-reference if its original phrasing differs.
p=S/'FIGURE_LEGENDS_ZH.md';s=p.read_text();parts=re.split(r'(?=^## 补图\d+\.)',s,flags=re.M)
for j,b in enumerate(parts):
 if b.startswith('## 补图6.') and 'eFigure 13' in b:
  old=b;parts[j]=b.replace('eFigure 13','eFigure 12');changes.append(dict(file=p.name,before=old,after=parts[j],reason='Scenario figure is eFigure12, not calibration eFigure13.'))
p.write_text(''.join(parts))
change('FIGURE_LEGENDS.md','paired contrasts and intervals remain in eTable 9 and aggregate files.','point estimates are also reported in eTable 9, and paired contrasts and intervals remain in the aggregate files.','eTable9 displays point estimates; complete paired intervals are in aggregate CSVs.')
p=S/'FIGURE_LEGENDS_ZH.md';s=p.read_text()
s=s.replace('配对比较和区间保留于eTable 9和汇总文件。','点估计也见eTable 9，配对比较和区间保留于汇总文件。')
s=s.replace('配对差及区间保留于eTable 9和汇总文件。','点估计也见eTable 9，配对差及区间保留于汇总文件。')
p.write_text(s)
EN1=("Clinical cohort pathway, paired workflow comparisons, and event coverage",
"A, Study flow, eligibility, geographic and temporal development/evaluation partitions, predictor availability, training-contained development, and the clinical review question. Counts identify operations and events unless patient groups are specified. One record aged younger than 18 years and 303 records with unavailable renal information were excluded from 4,014 screened operations; the latter include one record with unrecorded age. The geographic and temporal partitions shown are for the preoperative cohort. B, Paired additional-information-minus-baseline AUROC differences for nine versus 27 preoperative inputs and 27-input preoperative versus 38-input operation-end workflows. Nine-to-27 comparisons use 1,159/72 geographic and 1,683/66 temporal operations/events; stage comparisons use 1,158/72 and 1,011/36. These compare complete selected workflows, including their model and preprocessing choices. Whiskers are the original paired 95% intervals from 2,000 hospital-stratified patient-group bootstrap samples. C, Empirical capture–review curves over 0%–50% capacity for the nine- and 27-input preoperative systems; full curves remain in eFigures 6 and 19. D, Absolute captured/known-event counts and paired 27-minus-nine-input capture differences at target-ranked 20% capacity. Geographic and temporal lists contain 232 and 337 operations. Rankings use frozen predictions; observed outcomes are used to summarize capture. Public sources retain their separately defined SCr outcomes. AUROC indicates area under the receiver operating characteristic curve; SCr, serum creatinine.")
ZH1=("临床队列路径、配对流程比较与事件覆盖",
"A，研究流程、入选条件、地理及时间开发/评价划分、输入时点、训练内开发及临床复核问题。除另注明患者组外，数量为手术记录及事件。4,014次筛查手术中排除一条年龄不足18岁的记录及303条肾脏资料不可用记录，后者包含一条年龄未记录者。所示地理及时间划分为术前队列。B，九至27项术前输入及27项术前至38项术毕完整流程的配对AUROC差，方向均为追加信息流程减基础流程。九至27项地理及时间比较分别为1,159/72及1,683/66次手术/事件；阶段比较为1,158/72及1,011/36。比较包含各完整选定流程的模型与预处理差异。误差线复用原始2,000次医院分层患者组bootstrap配对95%区间。C，九项和27项术前系统在0%至50%容量的经验捕获—复核曲线，完整曲线见eFigures 6和19。D，目标排序20%容量下捕获/已知事件数及27项减九项的配对捕获差，地理及时间名单包含232及337次手术。排序使用冻结预测，观察结局用于汇总捕获。公共来源保留各自SCr结局定义。AUROC为受试者工作特征曲线下面积；SCr为血清肌酐。")
EN5=("MIMIC clinical transport, workload, and measurement conditions",
"A, Qualification of 1,231 anatomically matched candidates, excluding 467 without baseline SCr and five without follow-up SCr, yielding 759 patients and 59 recorded events; observed laboratory-input counts are shown below. B, Raw and source-calibrated Brier scores with the original 95% intervals, alongside the apparent observed-prevalence constant as a point reference. AUROC summaries and calibrated-minus-reference Brier differences are annotated; complete comparisons are in eTable 32. C, Review fraction and recorded-event coverage for target-ranked 20% capacity, source-20%-capacity cutoffs and source-sensitivity-80% cutoffs, with reviewed-patient and captured-event counts. Geographic and temporal source models use six-input random forests. D, Five retrospective SCr-deletion rules, each showing the fraction of originally known events no longer detected. Filled slate circles represent all 759 patients/59 events; open orange squares represent the nested geographic source-low-risk subset of 258 patients/11 events. Whiskers are the saved marginal Wilson 95% intervals, including for zero observed loss. The aligned columns give lost/known-event counts and observed test-removal percentages. The two populations overlap; no between-population significance contrast is displayed. Rule-specific patient-bootstrap results remain in the aggregate tables. Calendar-window endpoint definitions and full supporting results are retained in eTables 22–24 and 28–32 and eFigures 17 and 23. SCr indicates serum creatinine.")
ZH5=("MIMIC临床迁移、复核负担与测量条件",
"A，1,231名解剖学匹配候选者中，排除467名无基线SCr及五名无随访SCr者，得到759名患者及59例记录事件，下方列出实验室输入的观测数。B，原始及源校准Brier评分与原始95%区间，以目标队列实际发生率常数作为表观点参照；标注AUROC概况及校准减参照的Brier差，完整比较见eTable 32。C，目标排序20%容量、源20%容量切点及源80%敏感性切点下的复核比例与记录事件覆盖，标签注明复核人数及捕获事件。两套源模型均为六输入随机森林。D，逐行显示五种SCr回顾性删减规则下不再可见的原有已知事件比例。深灰蓝实心圆为全部759人/59例事件，橙色空心方块为其中地理源低风险亚组258人/11例。误差线为已保存的边际Wilson 95%区间，包括零观察损失。右侧列出损失/已知事件数及实际检验删除百分比。两个人群存在包含关系，图中未显示人群间显著性对比；规则特异的患者bootstrap结果保留于汇总表。日历窗口结局定义和完整支持结果见eTables 22至24、28至32及eFigures 17、23。SCr为血清肌酐。")
for lang,new in [('EN',{1:EN1,5:EN5}),('ZH',{1:ZH1,5:ZH5})]:
 p=S/('FIGURE_LEGENDS.md' if lang=='EN' else 'FIGURE_LEGENDS_ZH.md')
 s=p.read_text()
 for n,(title,body) in new.items():
  pattern=(r'^## Figure '+str(n) if lang=='EN' else r'^## 图'+str(n))+r'\..*?(?=^## |\Z)'
  s,num=re.subn(pattern,(f'## Figure {n}. ' if lang=='EN' else f'## 图{n}. ')+title+'\n\n'+body+'\n\n',s,flags=re.M|re.S);assert num==1
 p.write_text(s)
# Ensure Chinese eFigure11 location statement does not still direct interval readers to a point-only table.
p=S/'FIGURE_LEGENDS_ZH.md';s=p.read_text();m=re.search(r'^## 补图11\..*?(?=^## )',s,re.M|re.S)
print('CHINESE_EFIGURE11',m[0])
for n in ['MANUSCRIPT_EN.md','COVER_LETTER.md']:
 p=S/n;s=p.read_text().replace('through November 9, 2026','through November 10, 2026')
 if n=='COVER_LETTER.md':
  s=s.replace('November 9, 2026','November 10, 2026')
  s=s.replace('frozen six-input RF discrimination and calibration were reduced','frozen six-input RFs showed modest discrimination and low calibration slopes')
 p.write_text(s)
for n in ['MANUSCRIPT_ZH.md','COVER_LETTER_ZH.md']:
 p=S/n;s=p.read_text().replace('2026年11月9日','2026年11月10日');p.write_text(s)
p=P/'06_Graphical_abstract/STUDY_FRAMEWORK_AND_CONCLUSIONS_ZH.md';s=p.read_text()
s=s.replace('（11.9%；患者bootstrap95%CI 4.3%至20.4%）','（11.9%；Wilson 95%CI 5.9%至22.5%；患者bootstrap 95%CI 4.3%至20.4%）');p.write_text(s)
(S/'Chapters/FIGURE_LEGENDS.md').write_text((S/'FIGURE_LEGENDS.md').read_text())
pairs=json.loads((B/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
for lang,k in [('EN','english'),('ZH','chinese')]:
 ss=(S/('FIGURE_LEGENDS.md' if lang=='EN' else 'FIGURE_LEGENDS_ZH.md')).read_text()
 pattern=r'^## (e?)Figure (\d+)\. [^\n]+\n\n(.*?)(?=^## |\Z)' if lang=='EN' else r'^## (补?)图(\d+)\. [^\n]+\n\n(.*?)(?=^## |\Z)'
 for m in re.finditer(pattern,ss,re.M|re.S):
  key=('e'+m[2]) if m[1] else int(m[2]);row=next(x for x in pairs if x['figure']==key);row[k]=m[3].strip()
(W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2))
(W/'review/REPORTING_CORRECTIONS.json').write_text(json.dumps(changes,ensure_ascii=False,indent=2))
# Update targeted source audit code for new bindings; original numeric ledger of other figures preserved.
target=json.loads((W/'review/TARGETED_FIGURE_BINDINGS.json').read_text())
meta=json.loads((B/'review/COMPOSITE_MAIN_FIGURES.json').read_text())
meta['figures']=[next((y for y in target['figures'] if y['figure']==x['figure']),x) for x in meta['figures']]
meta['ledger']=[x for x in meta['ledger'] if x['figure'] not in [1,5]]+target['ledger']
meta['source_csvs'].update(target['source_csvs'])
meta['revision']='20261110_v3'
(W/'review/COMPOSITE_MAIN_FIGURES.json').write_text(json.dumps(meta,indent=2))
# Audit script maintains exact row-key verification, not pooled number coincidence.
p=W/'code/audit_composite_numbers.py';s=p.read_text().replace("B=W.parent/'figure_redesign_20261109_v1/package'","B=W.parent/'composite_main_figures_20261109_v2/package'")
s=s.replace("ctx,metric=x['source_key'].split(':')[1:];v,lo,hi=values(row(pri,context=ctx,model=k,metric=metric))","v,lo,hi=values(row('aggregate_data/source_data/Table_3_stage_and_input_differences.csv',model=k,metric='AUROC'))")
s=s.replace("pop,mode=k.split(':');v,lo,hi=values(row(dele,population=pop,mode=mode),val='lost_known_fraction',lo='lost_known_fraction_lo',hi='lost_known_fraction_hi')",
"""pop,mode=k.split(':');r=row(dele,population=pop,mode=mode)
  if x['source_key'].endswith('deleted_fraction'):v=float(r['deleted_fraction'])
  else:v,lo,hi=values(r,val='lost_known_fraction',lo='lost_event_Wilson_lo',hi='lost_event_Wilson_hi')""")
p.write_text(s)
print('INTEGRATED_CAPTION_AND_REPORTING_SOURCE_CHANGES',len(changes))

