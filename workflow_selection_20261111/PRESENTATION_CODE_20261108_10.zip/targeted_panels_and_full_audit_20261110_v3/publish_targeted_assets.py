
from pathlib import Path
import re,json,hashlib,shutil
from xml.etree import ElementTree as ET
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';F=P/'05_Figure_assets'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
SVG='http://www.w3.org/2000/svg';ET.register_namespace('',SVG);ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
for p in (W/'figures').rglob('*.svg'):
 tree=ET.parse(p);changed=False
 for t in tree.findall('.//{'+SVG+'}text'):
  st=t.get('style','');m=re.search(r'(?:^|;)\s*font:\s*([^;]+)',st)
  if not m:continue
  size=re.search(r'(\d+(?:\.\d+)?)px',m.group(1));assert size
  weight='700' if re.search(r'\b700\b|\bbold\b',m.group(1)) else '400'
  st=(st[:m.start()]+st[m.end():]).lstrip('; ')+'; font-family:Arial; font-size:'+size.group(1)+'px; font-weight:'+weight
  t.set('style',st);t.set('font-family','Arial');t.set('font-size',size.group(1));t.set('font-weight',weight);changed=True
 if changed:tree.write(p,encoding='utf-8',xml_declaration=True)
for n in [1,5]:
 key=f'Figure_{n}'
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(W/'figures'/f'{key}.{ext}',F/key/f'{key}.{ext}')
 target=F/'Independent_panels'/key
 # Preserve originals in sealed parent; only known targeted panel files are replaced.
 for p in (W/'figures/panels'/key).iterdir():shutil.copy2(p,target/p.name)
 shutil.copy2(W/'figures'/f'{key}.pdf',P/f'01_Journal_files/FIGURE_{n}.pdf')
idx=json.loads((F/'FIGURE_SOURCE_INDEX.json').read_text())
for m in re.finditer(r'^## ((?:e)?Figure \d+)\. ([^\n]+)\n\n(.*?)(?=^## |\Z)',(S/'FIGURE_LEGENDS.md').read_text(),re.M|re.S):
 item=next(x for x in idx if x['label']==m[1]);item.update(title=m[1]+'. '+m[2],caption=m[3].strip())
 if m[1] in ['Figure 1','Figure 5']:
  item['composite_revision']='20261110_v3'
  item['assets']={str(p.relative_to(P)):sha(p) for p in (F/m[1].replace(' ','_')).iterdir() if p.is_file()}
(F/'FIGURE_SOURCE_INDEX.json').write_text(json.dumps(idx,indent=2))
print('COPIED_TARGETED_ASSETS_AND_ALIGNED_ALL_29_SOURCE_CAPTIONS')

