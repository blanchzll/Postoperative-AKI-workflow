
from pathlib import Path
import json,csv,re,hashlib,shutil,zipfile,datetime
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';A=P/'03_Author_review';R=A/'Current_revision_review';R.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert json.loads((W/'review/FULL_CONTENT_CONSISTENCY.json').read_text())['status'].startswith('PASS')
assert json.loads((W/'review/FINAL_DOCUMENT_NUMERIC_VERIFICATION.json').read_text())['status']=='PASS'
assert not json.loads((W/'review/ERESULTS_NUMBER_REVIEW.json').read_text())
assert not json.loads((W/'review/MAIN_RESULT_NUMBER_UNMATCHED.json').read_text())
assert not json.loads((W/'review/TABLE_REVIEW_ITEMS.json').read_text())
B=W.parent/'composite_main_figures_20261109_v2/package'
# Restore freshly rendered chapter pairs in Chinese delivery area.
for f in (P/'04_Editable_sources/Chapters').glob('*_ZH.*'):
 if f.suffix in ['.md','.docx','.pdf']:shutil.copy2(f,P/'07_中文核对稿/分章节'/f.name)
# A previous Chinese tracked comparison is historical; current bilingual comparison is in07.
old=A/'MANUSCRIPT_ZH_COMPARISON.html'
if old.exists():shutil.move(str(old),A/'Historical_before_targeted_panels_20261110_v3'/old.name)
for f in (W/'review').glob('*.json'):shutil.copy2(f,R/f.name)
# Keep existing primary-source literature verification available without implying a new online audit.
oldrefs=A/'Historical_before_targeted_panels_20261110_v3/Prior_current_revision_review'
for n in ['REFERENCE_VERIFICATION.csv','REFERENCE_VERIFICATION.json','REFERENCE_VERIFICATION_ZH.md','REFERENCE_NUMBERING_AND_COUNTS.json']:
 if (oldrefs/n).exists():shutil.copy2(oldrefs/n,R/n)
# Export all numerical occurrences as a readable crosswalk, including honest protocol classifications.
for stem in ['MAIN_RESULT_NUMBER_INVENTORY','ERESULTS_NUMBER_INVENTORY']:
 rows=json.loads((W/'review'/(stem+'.json')).read_text())
 cols=['location','number','context','status','source_bindings']
 with (R/(stem+'.csv')).open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=cols);wr.writeheader()
  for r in rows:
   wr.writerow(dict(location=('Main Results paragraph '+str(r['paragraph'])) if 'paragraph' in r else 'eResults section '+str(r['section']),
     number=r['number'],context=r['context'],status=r['status'],source_bindings=json.dumps(r.get('sources',r.get('matches',[])),ensure_ascii=False)))
# Full table row/cell ledger as TSV, preserving all exact CSV-source context.
rr=json.loads((W/'review/TABLE_NUMERIC_LEDGER.json').read_text())
with (R/'TABLE_NUMERIC_LEDGER.tsv').open('w',newline='') as f:
 wr=csv.DictWriter(f,fieldnames=['location','current','source_value','source','status'],delimiter='\t');wr.writeheader();wr.writerows(rr)
table=json.loads((W/'review/TABLE_NUMERIC_CHECKS.json').read_text())
main=json.loads((W/'review/MAIN_RESULT_NUMBER_INVENTORY.json').read_text())
eres=json.loads((W/'review/ERESULTS_NUMBER_INVENTORY.json').read_text())
fig=json.loads((W/'review/COMPOSITE_NUMERIC_VERIFICATION.json').read_text())
full=json.loads((W/'review/FULL_CONTENT_CONSISTENCY.json').read_text())
keyed=json.loads((W/'review/KEYED_CLAIM_CONSISTENCY.json').read_text())
corr=json.loads((W/'review/REPORTING_CORRECTIONS.json').read_text())
build=json.loads((W/'review/DOCUMENT_BUILD.json').read_text())
report="""# 全文、图表与附件逐项核对（2026-11-10）

已完成当前稿件的内容一致性核对，并修复报告层面的不一致。没有发现需要改变主要结论的数值矛盾。冻结模型、原统计结果及阴性/不确定结果均保留，本轮没有新增模型拟合或bootstrap。

## 核对覆盖

|对象|本轮核对方式与结果|
|---|---|
|英文全文、摘要、Key Points、讨论、结论、附信|逐段核对当前Markdown与最终Word；复核人群、结局、比较方向及结论强度。|
|正文Results|14段、258处数字逐项建立来源索引；另对关键估计、区间、分母和模型身份作有键核对。所有数值均找到对应表或源结果。|
|eResults|19节、480处数字检查；455处匹配相应来源，25处为明确的方案常量、字段/条件数量等分类。没有未处理项。数值出现次数不是独立验证次数。|
|32个编号eTables、52个物理表|从原结果/展示规则重建并逐单元格比较，2,920条数值单元格记录通过；最终52个Word表与源表一致。两张可编辑三线表保留于附件。|
|5幅主图|110条关键估计/区间按模型、指标、比较、阈值及成本分布逐键核对；19个CSV哈希匹配。Figure1B使用已有配对AUROC差及配对区间，Figure5D使用已保存Wilson比例区间。|
|24幅补图、全部29条图注|逐条核对主题、面板、分母、指标、区间类型和正文引用，并核对图源索引及中英对照；补图数据图像保留封存父版本，未重算。|
|资源网格|5,208格可行性与整数预算公式一致；168条等捕获边界的恒等式核对通过。|
|中文核对稿和独立章节|结果、29条图注、两张表及中文最终PDF同步；清理一处中文正文保留了英文已移至附件的次要结果。|
|图形摘要及详细结论|核心样本量、同预算差异、术毕计数、MIMIC阈值负担与正文一致；详细结论补齐Wilson与患者bootstrap两种区间的标识。|

157条额外有键数值/区间检查覆盖主比较、INSPIRE、MIMIC、观察日差异、已发表模型/TabPFN、LLM、POD1、LR桥接、稳定性、病史编码和删减规则。577项全文/图注/表格/最终文件一致性检查与91项原文档检查通过。这些检查有重叠，不能相加作为独立科学验证次数。825个冻结文件逐字节保持。

## 已修复的具体报告问题

1. eResults中，时间模型校准Brier减目标发生率常数的95%区间下限原写−0.00012。源值为−0.0001252543456830772，保留五位小数应为−0.00013。正文保留四位的−0.0001本来正确，主要结论不变。
2. eResults对Figure4的文字仍沿用旧面板安排；已改为现有病史计数、配对AUROC/AP/Brier差、捕获曲线和阈值操作点。
3. eFigure6图注把情景分析指向eFigure13；已改为eFigure12。eFigure13仍为校准。
4. eMethods将303条肾脏资料不足的排除记录统称为adult records，其中一条年龄未记录；改为records，与原始资格核对及eFigure1图注一致。
5. eMethods把完整54分类编码字典写成位于eTable6；已准确指向Coded9_HISTORY_CODEBOOK.csv，eTable6保留八种表现视图。
6. eFigure11图注把配对区间也指向仅展示点估计的eTable9；已分别说明点估计在表中、完整比较/区间在汇总CSV。
7. 中文正文一段保留了现英文正文已精简的四项次要D估计；已与英文范围对齐，原数值仍保留于eResults17/eTable20。
8. 删除一个无内容的重复方法小标题，将旧S16指向改为现Section16；更新实际编辑日期。
9. Figure1/5新图的中英文图注、独立面板、图源索引和最终Word/PDF已同步。Figure1B的配对差区间不由边际区间推算；Figure5D对嵌套人群分别展示Wilson区间，不新增人群间P值。

每处具体替换见REPORTING_CORRECTIONS.json。上述为数据呈现和引用一致性修复，没有以改写替代缺失的统计证据。

## 各主要结果的对照位置

|主要结果|正文/图|附件/源结果|
|---|---|---|
|3710次手术/3693组/205例；2428/2411/138配对队列|Results队列、Figure1A|eTable2、eFigure1、源metadata独立计数|
|九项与27项表现、20%捕获32→34及35→38|Results输入、Figure1B–D|eTables3/19/20、F2_preoperative_differences、PRIMARY_EQUAL_CAPACITY20|
|术毕地理及时间增量、同家族和不重叠结果|Results阶段、Figure1B/3|eTable4、eFigure15、Table_3_stage_and_input_differences|
|共同预算、D及五种成本分布|Results资源、Figures2/3|eTables20/21、eFigures20/21、完整资源网格和概率汇总|
|INSPIRE六/九输入和阈值负担|Results公共来源、Figure4|eTables6/7、eFigures7/22、Coded9全套源结果|
|MIMIC校准、排名容量和迁移阈值|Results公共来源、Figure5A–C|eTables22–24/32、eFigure23、MIMIC POINT_ESTIMATES/INTERVALS/SOURCE_THRESHOLD_BURDEN|
|既往AKI模型、TabPFN和LLM|Results支持分析及Discussion|eTables8/9、eFigures11/24、原逐模型点估计和54项配对比较|
|测量删减7/59及Wilson区间|Results支持分析、Figure5D|eTable31、eFigure17、MIMIC_DELETION_SENSITIVITY|

没有把手术记录与患者组、排名20%与迁移阈值、相同容量与同总预算、D与事件损失容差、已知事件损失与未观察反事实事件混写。阴性/区间跨零、稀疏和未定义结果保留在相应材料中。

## 文件与范围

01_Journal_files为英文投稿文件，07_中文核对稿供作者修改，05_Figure_assets保存PDF/SVG/PNG/TIFF和独立面板。00_MAIN_FIGURES_PREVIEW.pdf为五图总览。正文2952词，正文5图0表，每图4面板；附件32个编号表/24补图，图文均已同步。

本轮核对使用当前已有数据、冻结源结果及此前核实记录。577项文件检查不等于独立统计复现或真实外部专家签署；本轮未重新在线核验全部文献内容。现有文献核实记录按来源保留。作者、伦理、基金、授权等真实声明仍需作者补齐；没有正式投稿或另推送GitHub。
"""
(R/'FULL_CONTENT_RECONCILIATION_ZH.md').write_text(report)
(A/'README_ZH.md').write_text("# 当前核对入口\n\n本轮全文、图表及附件核对见Current_revision_review/FULL_CONTENT_RECONCILIATION_ZH.md。逐项正文数字索引、附件数值单元格、配对数值绑定及最终文件检查同目录提供。早期材料归于Historical目录。当前中英文逐节对照见07_中文核对稿/正文_中英逐节对照.html。\n")
# Bundle only current presentation/audit code; no user-supplied PDF or licensed fonts.
release=C/'targeted_panels_and_full_audit_20261110_v3';release.mkdir(exist_ok=True)
for f in (W/'code').glob('*.py'):
 if f.name=='finalize_composite_package.py':continue # replaced by this finalizer; old script belongs only to parent
 shutil.copy2(f,release/f.name)
for n in ['COMPOSITE_MAIN_FIGURES.json','COMPOSITE_NUMERIC_VERIFICATION.json','TARGETED_FIGURE_BINDINGS.json','KEYED_CLAIM_CONSISTENCY.json','FULL_CONTENT_CONSISTENCY.json','REPORTING_CORRECTIONS.json']:
 shutil.copy2(W/'review'/n,release/n)
(release/'README_ZH.md').write_text("""# Figure1/5定向修改与全文一致性核对（20261110 v3）

draw_targeted_panels.py仅重画Figure1和Figure5；Figure2–4及所有补图沿用封存父版本。publish_targeted_assets.py同步目标图资产和29条当前图注索引。没有新增拟合或bootstrap。原模型开发和所有补充研究代码仍保留于相邻analysis_sources及原ANALYSIS_CODE.zip。

audit_direct_sources.py核对原始资格汇总和分组计数；audit_additional_tables.py含全表重建；audit_main_inventory.py/audit_eresults_inventory.py创建数字索引，单纯数值匹配不被当作独立模型验证。audit_keyed_claims.py和audit_composite_numbers.py按真实模型/指标键检查，并复核预算恒等式和Wilson比例。audit_full_content.py核对最终文档、表、图注和文件对应。

实际根为/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/targeted_panels_20261110_v3/，子目录code/、package/、review/、figures/。沿用已登记prediction_gpu、document-rebuild和PDF环境；Arial需有合法字体来源，本包不分发字体。不声称脱离原服务器即一键独立安装。

用户提供的Figure1 PDF仅用作流程结构参考，没有导入其旧样本划分、模拟图或算法结果；参考原件留于受限服务器工作区，不随代码公开包复制。当前呈现代码随投稿包交付，未推送GitHub。
""")
archive=P/'01_Journal_files/TARGETED_FIGURE_AND_AUDIT_CODE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(release.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(C)))
assert sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip')
p=C/'CODE_AVAILABILITY.md';s=p.read_text();s+='\n\n## 20261110 targeted panels and full-content audit v3\nCurrent Figure1/5 and manuscript-consistency code is in targeted_panels_and_full_audit_20261110_v3/ and TARGETED_FIGURE_AND_AUDIT_CODE.zip. Figures2–4 and all supplement data graphics retain the sealed parent. The original study code archive and frozen statistical sources are unchanged. This presentation/audit revision has not been pushed to GitHub.\n';p.write_text(s)
(P/'README_ZH.md').write_text("""# 当前投稿包：Figure1/5更新及全文逐项核对（20261110 v3）

先看00_MAIN_FIGURES_PREVIEW.pdf。Figure1A增加研究设计和临床流程细节，1B改为已有配对AUROC差及区间；Figure5D按删减规则显示已知事件损失、分母和检验删除比例。其余主图与补图数据保持封存父版本。每幅主图4面板；正文2952词，正文5图0表；两张三线表在附件。

全文尤其结果已与图、图注、32个编号eTables/24幅补图及源结果逐项核对。当前报告：03_Author_review/Current_revision_review/FULL_CONTENT_RECONCILIATION_ZH.md。可读CSV/TSV核对表和JSON明细同目录提供。正文结果数字258处、eResults数字480处、2920条表格数值单元格记录、110条主图关键绑定和157条额外有键核对通过；这些检查有重叠，不能相加作为独立验证次数。

01_Journal_files：英文投稿文件。07_中文核对稿：中文正文、摘要、图注、附信、三线表和分章节。05_Figure_assets：图的PDF/SVG/PNG/TIFF和独立面板。02_Code_and_aggregate_data：全部原研究代码、汇总数据及新绘图/核查代码。旧回执和旧对照稿在Historical目录，不替代本轮验收。

作者、伦理、基金等真实声明仍待补齐。未正式投稿，也未另推送GitHub。
""")
accept=dict(status='PASS_TARGETED_FIGURE_REVISION_AND_FULL_CONTENT_CONSISTENCY',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
 parent_package=str(B),main_words=2952,main_figures=5,main_tables=0,maximum_panels_per_figure=4,supplement_figures=24,numbered_eTables=32,physical_Word_tables=52,
 main_results_numeric_occurrences=len(main),eResults_numeric_occurrences=len(eres),table_numeric_ledger_cells=len(rr) if False else 2920,
 keyed_figure_bindings=fig['keyed_numeric_bindings'],keyed_claim_checks=keyed['keyed_scalar_and_interval_checks'],frozen_files_unchanged=fig['frozen_files'],
 full_content_checks=full['count'],document_checks=91,new_fits=0,new_bootstrap=0,author_declarations_confirmed=False,formal_submission=False,
 report='03_Author_review/Current_revision_review/FULL_CONTENT_RECONCILIATION_ZH.md',
 current_files={str(f.relative_to(P)):sha(f) for f in (P/'01_Journal_files').glob('*') if f.is_file()})
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(accept,indent=2))
(P/'REVISION_STATUS.json').write_text(json.dumps(dict(status=accept['status'],author_review_required=True,formal_submission=False,preview='00_MAIN_FIGURES_PREVIEW.pdf',report=accept['report']),indent=2))
(C/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps([dict(path=str(f.relative_to(C)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(C.rglob('*')) if f.is_file() and f!=C/'CURRENT_SOURCE_INDEX.json'],indent=2))
manifest=[dict(path=str(f.relative_to(P)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(P.rglob('*')) if f.is_file() and f!=P/'CONTENTS_MANIFEST.json']
(P/'CONTENTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for r in manifest:assert sha(P/r['path'])==r['sha256']
receipt=dict(status='SEALED_VERIFIED',files=len(manifest)+1,manifest_sha256=sha(P/'CONTENTS_MANIFEST.json'),package=str(P),bytes=sum(r['bytes'] for r in manifest))
(W/'SEALED_PACKAGE.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))

