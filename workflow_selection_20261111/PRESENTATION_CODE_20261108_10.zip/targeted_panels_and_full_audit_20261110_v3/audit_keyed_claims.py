
from pathlib import Path
import csv,json,math,hashlib,re
from decimal import Decimal
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';S=P/'04_Editable_sources';checks=[];cache={}
def get(rel,**key):
 if rel not in cache:cache[rel]=list(csv.DictReader((C/rel).open()))
 rr=[r for r in cache[rel] if all(r[k]==str(v) for k,v in key.items())]
 assert len(rr)==1,(rel,key,len(rr))
 return rr[0]
def bind(label,rel,key,values,location,factor=1):
 r=get(rel,**key)
 for field,display in values.items():
  raw=float(r[field])*factor;d=Decimal(str(display))
  tol=float(Decimal(10)**d.as_tuple().exponent/2)+1e-11
  assert abs(raw-float(d))<=tol,(label,field,raw,display)
  checks.append(dict(claim=label,location=location,source=rel,row_key=key,field=field,raw_value=r[field],display_value=display,display_factor=factor,status='PASS'))
def src(s):return 'aggregate_data/source_data/'+s+'.csv'
def triple(label,rel,key,vals,loc,fields=('estimate','lower95','upper95'),factor=1):
 bind(label,rel,key,dict(zip(fields,vals)),loc,factor)
# Primary marginal performance with the correct model/context, never a pooled number search.
for ctx,model,v in [
 ('geography_preop','preop_compact_champion_LR',['.698','.631','.765']),
 ('temporal_preop','preop_compact_champion_Voting',['.729','.650','.804']),
 ('geography_preop','preop_full_champion_LR',['.699','.633','.767']),
 ('temporal_preop','preop_full_champion_Voting',['.717','.639','.795'])]:
 triple(ctx+model,src('Primary_model_intervals'),dict(context=ctx,model=model,metric='AUROC'),v,'Main Results paragraph3; eTable3')
for cid,vals,counts in [
 ('geography_9v27_champ',['1.726','-3.448','6.914'],[1159,72,232,32,34]),
 ('temporal_9v27_champ',['1.783','-2.375','4.756'],[1683,66,337,35,38]),
 ('geography_27v38_champ',['12.953','5.172','21.552'],[1158,72,232,22,37]),
 ('temporal_27v38_champ',['.989','-5.935','6.938'],[1011,36,203,18,19])]:
 rel='aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv'
 r=get(rel,comparison_id=cid)
 # Source identifiers are different from generic n/events only if actual headers use their exact frozen names.
 bind(cid,rel,dict(comparison_id=cid),dict(zip(['n','events','base_reviews_n','base_captured_n','extra_captured_n'],counts)),'Main Results paragraphs3–4; Figures1D/3C; eTable20')
 triple(cid,rel,dict(comparison_id=cid),vals,'Main Results3–4; eTable20',('delta_captured_per1000','delta_captured_per1000_lower95','delta_captured_per1000_upper95'))
for cid,v in zip(['geography_9v27_champ','temporal_9v27_champ','geography_27v38_champ','temporal_27v38_champ'],
 [['72.476','-24.937','98.467'],['38.622','-24.941','80.337'],['135.579','91.692','167.114'],['39.565','-220.629','132.418']]):
 triple(cid,'aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv',dict(comparison_id=cid,mode='calibrated',budget_percent=20),v,'Main Results5; Figure3A/B; eTable20',('signed_allowable_extra_cost_per1000','lower95','upper95'))
prob='probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv'
for cid,law,vals in [
 ('geography_9v27_champ','ratio_uniform_030',['-5.58','-9.60','-2.60']),
 ('temporal_9v27_champ','ratio_uniform_030',['-3.81','-6.36','-1.66']),
 ('geography_27v38_champ','ratio_low_030',['5.19','-1.68','12.60']),
 ('geography_27v38_champ','ratio_high_030',['-2.70','-5.18','-.16'])]:
 triple(cid+law,prob,dict(comparison=cid,distribution=law),vals,'Abstract; Main Results7; Figure3D; eTable20',('mean_delta_per1000_fallback','mean_delta_per1000_fallback_patient_lower95','mean_delta_per1000_fallback_patient_upper95'))
for law,val in [('ratio_low_030','83.2'),('ratio_high_030','6.7')]:
 bind('Geo stage cost mass',prob,dict(comparison='geography_27v38_champ',distribution=law),{'p_win':val},'Main Results7',100)
for line,model,capture in [('geography','coded9_LR',123),('temporal','coded9_Voting',128)]:
 triple('INSPIRE paired capture '+line,src('Coded9_PAIRED_DIFFERENCES_VS_SIX_RF'),
        dict(model=line+'__'+model+'__calibrated MINUS '+line+'__six_RF__calibrated',metric='capacity20_captured_per1000'),
        ['.331','-1.489','1.986'] if line=='geography' else ['.662','-.827','2.155'],'Main Results9; Figure4; eTables6–7')
 bind('INSPIRE source80 '+line,src('Coded9_SOURCE_THRESHOLD_COVERAGE'),dict(source_line=line,model=model),
      {'reviewed_percent':'64.70' if line=='geography' else '47.15','target_sensitivity_percent':'85.77' if line=='geography' else '77.87'},'Main Results9; Figure4D')
for line,v,b,cs in [('geography',['.614','.549','.680'],['.080','.064','.098'],['.236','.014','.454']),
                    ('temporal',['.621','.552','.688'],['.074','.058','.091'],['.355','-.107','.740'])]:
 rel='aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv'
 for met,vals in [('AUROC',v),('Brier',b),('calibration_slope',cs)]:
  triple('MIMIC '+line+met,rel,dict(model=line+'__calibrated',metric=met),vals,'Main Results12; Figures5B/C; eTable22')
 for rule,rn,cn in [('training_capacity20',279 if line=='geography' else 210,33 if line=='geography' else 22),
                     ('training_sensitivity80',501 if line=='geography' else 759,48 if line=='geography' else 59)]:
  for metric,val in [('reviewed_n',rn),('captured_n',cn)]:
   bind('MIMIC threshold '+line+rule,'aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv',dict(source_line=line,rule=rule,metric=metric),{'estimate':val},'Main Results12; Figure5C; eTable23')
obs='measurement_consistency_20261104_v1/aggregates/WRITING_ELIGIBLE_AGGREGATES.csv'
triple('Observation-day event-rate difference',obs,dict(result_id='OBSERVATION_EVENT_RATE_DIFFERENCE'),['9.91','6.82','13.01'],'Main Results11; eTable24',factor=100)
for band,n,e in [('1to2',254,3),('3plus',505,56)]:
 bind('Observation-day denominator',obs,dict(result_id='OBSERVATION_Cr_days_1to2_vs_3plus__'+band),dict(n=n,events=e),'Main Results11')
for line,vals in [('geography',['.00880','.00489','.01290']),('temporal',['.00266','-.00013','.00538'])]:
 triple('Brier minus apparent target constant '+line,'clinical_supplement_20261108_v1/results/MIMIC_BRIER_REVERIFIED.csv',dict(population='MIMIC_current759_59',line=line,probability='calibrated',reference='target_rate_reestimated',metric='model_minus_null_Brier'),
 vals,'Main Results12 (four decimals); eResults19 (five decimals); eTable32',('estimate','lo','hi'))
pub='aggregate_data/supplement/aggregate_tables/supplement_tables/S12_published/published_benchmark_comparison_20261024_v1/POINT_ESTIMATES.csv'
for ctx,mod,value in [('SIM_geography','our_endop_cal','.739'),('SIM_geography','SIM_original_2009','.673'),('SIM_geography','SIM_original_2021','.675'),('Chen_geography','Chen_Table4_ordinal_score','.652'),('Chen_temporal','Chen_Table4_ordinal_score','.734')]:
 bind('Published benchmark',pub,dict(context=ctx,model=mod),{'AUROC':value},'Main Results13; eTable8')
for ctx,n in [('Chen_geography',41),('Chen_temporal',91)]:
 bind('Chen eligible denominator',pub,dict(context=ctx,model='Chen_Table4_ordinal_score'),{'n':n},'Main Results13; eTable8')
tab=next(str(p.relative_to(C)) for p in (C/'aggregate_data/supplement/aggregate_tables/supplement_tables/S13_TabPFN').rglob('POINT_ESTIMATES.csv') if p.parent.name=='temporal_paired')
for mod,val in [('tabpfn_endop_full','.752'),('main_cal_endop_full','.697')]:
 bind('Native temporal TabPFN',tab,dict(model=mod),{'AUROC':val},'Main Results13; eTable8')
for mod,val in [('llm_biomedlm_2_7b_before_endop_cal','.499'),('llm_biomedlm_2_7b_after_endop_cal','.398')]:
 bind('BioMedLM adaptation',src('S4_LLM_all24_calibrated_points'),dict(line='geography',model=mod),{'AUROC':val},'Main Results13; eTable9; eFigure11')
for line,vals in [('geography',['-.00014498','-.00036562','.00001763']),('temporal',['.00002433','-.00001798','.00007145'])]:
 triple('Conditional POD1 LR '+line,src('S3_POD1_LR_differences'),dict(context=line+'_all',model='all_pod1__LR MINUS all_preop__LR',metric='Brier'),vals,'eResults7; eTable15; eFigure9')
for line,vals in [('geography',['-.00779','-.03606','.02313']),('temporal',['-.00671','-.02225','.00881'])]:
 triple('Source LR bridge '+line,src('Translation_'+line+'_BRIDGE_INTERVALS'),dict(context=line,model='nine_LR__calibrated MINUS six_LR__calibrated',metric='AUROC'),vals,'eResults15; eTable11; eFigure14')
bind('Conditional stability',src('S5_conditional_stability'),dict(route='temporal_paired_preop_full'),dict(top20_overlap_fraction_mean='.582',training_sensitivity80_fixed_cut_flip_mean='.354'),'eResults9; eTable17; eFigure10')
for model,val in [('Diabetes',387),('Hypertension',439),('HeartDisease',354)]:
 bind('Released coded history',src('Coded9_HISTORY_COUNTS'),dict(predictor=model),{'coded_one':val},'eResults16; Figure4A; eFigure22B')
rel='clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv'
for pop in ['all_observed_records','geography_low_risk6']:
 for mode in ['first_per_calendar_day','odd_calendar_days','even_calendar_days','calendar_days1_2_only','calendar_day1_only']:
  r=get(rel,population=pop,mode=mode);n=int(r['original_known_events']);k=int(r['lost_known_events_lower_bound']);z=1.959963984540054
  ph=k/n;den=1+z*z/n;mid=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
  assert abs(mid-half-float(r['lost_event_Wilson_lo']))<1e-12
  assert abs(mid+half-float(r['lost_event_Wilson_hi']))<1e-12
  assert math.isclose(k/n,float(r['lost_known_fraction']),abs_tol=1e-12)
  checks.append(dict(claim='Wilson interval and event denominator',location='Figure5D; eFigure17B; eTable31',row_key=dict(population=pop,mode=mode),source=rel,status='PASS'))
# Formula identity and all complete grid cells are checked directly without a new bootstrap.
g=cache.setdefault('grid',list(csv.DictReader((C/'aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv').open())))
for r in g:
 n=int(r['n']);budget=int(r['budget_percent']);a=Decimal(r['extra_cost_per_person_review_equivalents'])
 K=(budget*n+99)//100;remaining=Decimal(K)-a*n
 assert (r['feasible_at_point']=='True')==(remaining>=0)
# Final artifact coverage: every numbered figure/table has one current caption and appears in the source.
en=(S/'FIGURE_LEGENDS.md').read_text();zh=(S/'FIGURE_LEGENDS_ZH.md').read_text()
assert len(re.findall(r'^## (?:e)?Figure \d+\.',en,re.M))==29
assert len(re.findall(r'^## (?:补)?图\d+\.',zh,re.M))==29
assert re.findall(r'^## eTable (\d+)\.',(S/'ETABLES.md').read_text(),re.M)==list(map(str,range(1,33)))
# Meaning and evidence units retained after review.
semantics=[
 ('cohort units','Operations are the outcome and capacity units; patient groups govern source partitioning and bootstrap.','Main Methods/Results; eTable2; eFigure1'),
 ('preop vs paired','3710/205 and 2428/138 cohorts are kept separate; geographic stage1158 differs from preop1159.','Figure1; eTables2–4/20'),
 ('endpoints','Chinese recorded composite, INSPIRE timed relative/absolute SCr, and MIMIC date-ratio endpoints are not pooled.','Main Methods; eMethods3/8/10/11; Figures4/5'),
 ('contrast direction','Extra minus base for AUROC/capture and D; Figure4B Brier decrease reverses both CI endpoints.','Figures1–5; eTables3/4/20/22'),
 ('capacities','ceil(qN) rank-based selection differs from frozen source cutoffs and shortest outcome-informed inverse lists.','Main Methods; eMethods6/9; Figures3C/4D/5C'),
 ('cost assumptions','All five distributions are analyst-specified; expected values use pre-spending fallback, not empirical cost distributions.','Main Results7/Discussion; Figure3D; eTable20; eFigures20/21'),
 ('interval types','Paired differences use saved paired CIs; plot5D uses Wilson proportions; random-allocation and training-stability quantiles remain separate.','eMethods2/4/6/11; Figure5D; eFigures4/10/17'),
 ('complete workflows','Stage champion differences include family/preprocessing changes; same-family and non-overlap findings are retained.','Main Results4/Discussion; eFigure15; eTable4'),
 ('nested populations','The MIMIC low-risk group is a subset; separate Wilson intervals are not a direct between-group test.','Figure5D; eFigure17B; eTable31'),
 ('time interval','INSPIRE surgery-start-to-SCr interval is not warning lead time; surgery-date demand is not observed shift workload.','eResults19; eFigures8/18; eTables27/29'),
 ('published benchmarks','SIM–AKI/Chen eligible subsets and ranking-only Chen are retained; TabPFN is native unrecalibrated.','Main Supporting Results/Discussion; eMethods5; eTable8'),
 ('LLM benchmarks','All24 calibrated conditions and54 contrasts retained; BioMedLM adverse adaptation remains visible.','Main Results13/Discussion; eMethods5; eResults12; eTables9; eFigures11/24'),
 ('conclusions','Higher mean event coverage under assigned costs is not equated with improved observed patient outcomes or proven equivalence.','Abstract/Key Points/Discussion/Conclusions; cover letter; graphical abstract')]
out=dict(status='PASS_KEYED_CLAIM_AND_SEMANTIC_CONSISTENCY',checks=checks,keyed_scalar_and_interval_checks=len(checks),resource_grid_feasibility_cells=len(g),
semantic_review=[dict(topic=a,finding=b,locations=c,status='CONSISTENT_AFTER_CORRECTION') for a,b,c in semantics],
source_hashes={rel:hashlib.sha256((C/rel).read_bytes()).hexdigest() for rel in cache if rel!='grid'},new_model_fits=0,new_bootstrap_samples=0)
(W/'review/KEYED_CLAIM_CONSISTENCY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','semantic_review','source_hashes']}))

