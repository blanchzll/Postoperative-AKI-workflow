from pathlib import Path
import re,json,csv,hashlib,datetime
R=Path(__file__).resolve().parents[1];E=R/'sources';P=R/'package'
items=json.loads((E/'reference_inventory.json').read_text());refs=json.loads((E/'FINAL_MAIN_REFERENCES.json').read_text())
purpose={
'10.1038/s41581-021-00418-2':('Postoperative AKI is associated with complications, CKD and mortality; risk assessment is relevant to perioperative care.','Abstract; kidney health assessment and outcomes sections'),
'10.1093/bjsopen/zrab150':('OAKS uses six routinely available preoperative predictors and was externally evaluated after gastrointestinal surgery.','Abstract Methods; Predictors'),
'10.1093/bjsopen/zrag124':('A nationwide colorectal cancer study developed an internally validated preoperative prediction model.','Abstract; Methods predictors'),
'10.1016/j.bja.2024.02.018':('Nine published preoperative models were independently evaluated for discrimination, calibration, net benefit and recalibration; miscalibration was reported.','Structured abstract Methods and Results'),
'10.1001/jamanetworkopen.2019.16921':('The study compared perioperative predictor stages and high-risk fractions of 10%, 20% and 30%.','Methods risk stratification; Results'),
'10.1038/s41551-022-00872-8':('CoAI selects predictor features under acquisition-cost constraints during model development.','Abstract; CoAI framework and feature selection methods'),
'10.1213/ane.0000000000005057':('Intraoperative information was added to a baseline abdominal surgery prediction model and evaluated.','Abstract; model development and validation'),
'10.1093/jamiaopen/ooag092':('Preoperative and combined intraoperative prediction were compared; incremental discrimination was limited at the available sampling frequency.','Abstract; Discussion'),
'10.1136/bmj-2023-074820':('External validation should examine calibration, discrimination and clinical usefulness in the intended setting.','Summary points; validation steps 3 and 4'),
'10.1136/bmj-2023-078378':('TRIPOD+AI supplies reporting guidance for regression and machine-learning prediction models.','Statement and checklist; corrected publisher version'),
'10.1038/s41597-024-03517-4':('INSPIRE is a public perioperative research dataset; provider-specific measurement and release details are documented separately.','Data descriptor; official version 1.4.2 documentation'),
'10.13026/1eay-yc85':('The INSPIRE dataset used is version 1.4.2, published June 9, 2026.','Official version header, citation and documentation'),
'10.1038/s44360-026-00096-z':('PhysioNet provides the biomedical research platform hosting the public resources.','Platform description; official resource citation instructions'),
'10.1038/s41597-022-01899-x':('MIMIC-IV is an electronic health record research dataset.','Data descriptor; corrected article'),
'10.13026/kpb9-mt58':('The MIMIC-IV dataset used is version 3.1, published October 11, 2024.','Official version header, citation and documentation'),
'10.1111/joim.70130':('SIM-AKI is a published severity-index prediction model; the manuscript retains the documented eligibility and mappings for its benchmark.','Full article Methods and prediction-index formulas; original analysis mappings remain frozen'),
'10.1016/j.jfma.2026.05.063':('Chen et al. developed an elderly abdominal surgery AKI model; the present study labels its mapped benchmark as ranking only.','Structured abstract; coefficient mapping is from the previously accepted analysis record, not re-extracted from an inaccessible full text in this revision'),
'10.1038/s41586-024-08328-6':('TabPFN is a published tabular foundation model used as a benchmark.','Abstract and model description'),
'10.1038/kisup.2012.7':('KDIGO distinguishes absolute and relative SCr changes and urine-output criteria.','Recommendation 2.1.1; risk assessment and monitoring recommendations'),
'10.1016/s0140-6736(25)01717-9':('BigpAK-2 randomized high-risk major-surgery patients to bundled preventive care; moderate/severe AKI was lower in the intervention group.','Structured abstract Methods and Findings; full text not accessed'),
'10.1001/jama.2024.22718':('Personalized recommendations after detected AKI did not demonstrate improvement in the primary composite outcome.','Abstract; primary outcome table'),
'10.1001/jamanetworkopen.2023.51710':('AKI alerts with a care bundle changed some care measures but did not demonstrate improvement in the primary kidney-function outcome.','Abstract; Results Tables 2 and 3'),
'10.1001/jamanetworkopen.2026.22554':('Prediction-triggered early nephrology consultation was tested and did not demonstrate improvement in the primary creatinine-change outcome.','Abstract; primary outcome results'),
'10.1001/jamanetworkopen.2024.40969':('A clinical-vignette trial distinguished standalone LLM performance from physician reasoning with access to the LLM.','Abstract; randomized comparison and secondary exploratory standalone analysis'),
'10.1038/s41746-026-02363-5':('Language-aware EHR representations were evaluated for transfer across countries and coding systems.','Abstract; external datasets and results'),
'10.1038/s41746-026-02915-9':('LLM-based EHR encoding was compared with specialized and conventional predictors; portability and computational requirements were examined.','Abstract; comparative evaluation; computational runtime; corrected publisher version'),
'10.1038/s41746-026-02572-y':('Hopkins LLM used structured EHR data and task adaptation for clinical and operational prediction with external evaluations.','Abstract; model adaptation and external validation'),
'10.1038/s41467-024-55629-5':('A real-time AKI model was transported and refitted across geographically distinct hospitals.','Abstract; external validation and transported-versus-refitted results'),
'10.1001/jama.2025.17235':('Individualized perioperative blood pressure management was tested in major abdominal surgery without demonstrated improvement in its primary composite outcome.','Abstract; primary outcome table'),
'10.1136/bmj-2024-082505':('PROBAST+AI distinguishes quality, risk of bias and applicability in prediction-model evaluation.','Summary points; tool domains'),
'10.1002/cam4.70646':('AKI risk varied across cancer treatments and surgical procedures in a nationwide cohort.','Abstract; treatment-specific risk results')
}
rows=[];main=(P/'04_Editable_sources/MANUSCRIPT_EN.md').read_text();body=main.split('## References\n')[0]
for x in items:
 d=x['doi'];stem=d.replace('/','__');key=d.lower();assert key in purpose,d
 ep=json.loads((E/(stem+'_europepmc.json')).read_text());a=next((v for v in ep['resultList']['result'] if v.get('doi','').lower()==key),ep['resultList']['result'][0] if ep['resultList']['result'] else {})
 dcfile=E/(stem+'_datacite.json')
 if dcfile.exists():dc=json.loads(dcfile.read_text())['data']['attributes'];assert dc['doi'].lower()==key;title=dc['titles'][0]['title'];year=dc['publicationYear'];identity='DataCite and official version page'
 else:assert a.get('doi','').lower()==key,(d,a.get('doi'));title=a['title'];year=int(a['pubYear']);identity='PubMed/Europe PMC exact DOI record; Crossref where available'
 m=next((v for v in refs if v['doi'].lower()==key),None)
 src=E/(stem+'_primary_retrieval.json');j=json.loads(src.read_text());textfile=E/j['file'] if j.get('file') else None
 full=textfile and textfile.exists() and not j.get('challenge') and j.get('characters',0)>5000
 access='official_resource_documentation' if d.startswith('10.13026/') else ('full_article_or_author_manuscript' if full else 'structured_abstract_only')
 contexts=[]
 if m:
  pat=re.compile(r'\[([0-9,]+)\]')
  for line in body.splitlines():
   if any(m['number'] in list(map(int,z.group(1).split(','))) for z in pat.finditer(line)):contexts.append(line)
 if not m:contexts=['Supplement eMethods: KDIGO SCr and urine-output components are distinguished.']
 row={'main_reference_number':m['number'] if m else 'Supplement only','doi':d,'title':title,'year':year,'identity_status':'PASS','identity_sources':identity,'actual_access':access,'content_status':'SUPPORTED_FOR_CITED_SCOPE','supported_claim':purpose[key][0],'source_location':purpose[key][1],'primary_url':j.get('url',''),'indexed_abstract_url':'https://pubmed.ncbi.nlm.nih.gov/'+a.get('id','')+'/' if a else '', 'source_file':str(textfile.relative_to(R)) if full else str((E/(stem+'_europepmc.json')).relative_to(R)),'source_sha256':hashlib.sha256((textfile if full else E/(stem+'_europepmc.json')).read_bytes()).hexdigest(),'citation_contexts':contexts,'correction_links':a.get('commentCorrectionList')}
 rows.append(row)
assert len(rows)==31
(R/'review/REFERENCE_VERIFICATION.json').write_text(json.dumps({'status':'PASS_IDENTITIES_AND_SCOPE_MATCHED_CLAIMS_WITH_ACCESS_LIMITS_RECORDED','verified_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'references':rows,'skills':['medical-evidence-writing','phd-paper-verification','paper-search-mcp'],'BioMCP_available':False,'paper_search_route':'Installed older CLI lacks tool subcommand; DOI search with -s crossref completed successfully; no package installation or upgrade','public_API_extraction_review':'Four public abstracts only; returned extraction checked against source abstracts; not independent scientific validation','new_statistics':False},ensure_ascii=False,indent=2)+'\n')
fields=['main_reference_number','doi','title','year','identity_status','actual_access','content_status','supported_claim','source_location','primary_url','source_file','source_sha256']
with (R/'review/REFERENCE_VERIFICATION.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows({k:x[k] for k in fields} for x in rows)
limits=[x for x in rows if x['actual_access']=='structured_abstract_only']
from collections import Counter
counts=dict(Counter(x['actual_access'] for x in rows))
report='# 逐条参考文献核实\n\n正文30条，附件9条，合并去重31篇。31篇均确认身份，并按实际访问范围核对其在稿件中的具体用途。24/30条正文文献发表于2024–2026年；本轮新增3篇目标期刊原始研究，另保留Lei等2019年关键近邻。\n\n## 实际访问范围\n\n'+str(counts)+'\n\n以下文献全文受限，本轮仅核对结构化摘要支持的论点：\n\n'+'\n'.join('- '+x['doi']+'：'+x['supported_claim'] for x in limits)+'\n\nChen系数映射沿用此前验收分析，本轮没有重新从未获取的全文抽取系数，也没有重跑模型。其排名用途和小合格子集在正文与附件中保留。\n\n## 更正记录\n\nMIMIC-IV原文两项更正涉及Table 1列标题和遗漏作者；当前元数据已包含更正作者。TRIPOD+AI的q902更正涉及作者单位。Hegselmann等EHR编码论文有2026年10月14日更正，涉及方法说明等条目；本稿引用其已更新原文中的编码、比较及计算资源结论，不引用受更正的参数。更正来源见原文链接与sources目录。本核查未将更正等同于撤稿；未声称穷尽所有数据库的撤稿登记。\n\n## 核实方法\n\n使用medical-evidence-writing、phd-paper-verification和paper-search-mcp，并结合PubMed/Europe PMC、Crossref、DataCite及出版社/PhysioNet官方页面。当前服务器未发现可用BioMCP命令或连接工具，没有声称其已经运行。公开摘要API仅作辅助抽取，内容已由Codex对照原文复核。逐条证据、访问范围、哈希和引用位置见REFERENCE_VERIFICATION.json及CSV。\n'
(R/'review/REFERENCE_VERIFICATION_ZH.md').write_text(report)
print(json.dumps({'identities_verified':len(rows),'access':counts,'abstract_only_DOIs':[x['doi'] for x in limits]}))
