from pathlib import Path
import json,urllib.request,urllib.parse,concurrent.futures,datetime,xml.etree.ElementTree as ET,time
R=Path(__file__).resolve().parents[1];S=R/'sources'
refs=[x for x in json.loads((S/'reference_inventory.json').read_text()) if x.get('new_reference_candidate')]
opener=urllib.request.build_opener(urllib.request.ProxyHandler({'http':'http://127.0.0.1:7890','https':'http://127.0.0.1:7890'}))
def get(url):
 req=urllib.request.Request(url,headers={'User-Agent':'AKI-reference-verification/1.0 academic source verification','Accept':'application/json, application/xml, text/html;q=0.8,*/*;q=0.5'})
 with opener.open(req,timeout=40) as res:return res.read(),res.geturl(),res.headers.get('Content-Type','')
def one(item):
 d=item['doi'];stem=d.replace('/','__');out={'doi':d,'retrieved_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 for provider,url in [('crossref','https://api.crossref.org/works/'+urllib.parse.quote(d,safe='')),('europepmc','https://www.ebi.ac.uk/europepmc/webservices/rest/search?query='+urllib.parse.quote('DOI:"'+d+'"')+'&format=json&resultType=core')]:
  p=S/(stem+'_'+provider+'.json')
  try:
   if not p.exists():raw,final,ct=get(url);p.write_bytes(raw)
   j=json.loads(p.read_text());out[provider]={'status':'OK','file':p.name,'url':url}
   if provider=='europepmc':
    results=j.get('resultList',{}).get('result',[])
    out['pmid']=results[0].get('id') if results else None
    out['pmcid']=results[0].get('pmcid') if results else None
    out['epmc_hits']=len(results)
  except Exception as e:out[provider]={'status':'ERROR','error':str(e),'url':url}
 if d.startswith('10.13026/'):
  url='https://api.datacite.org/dois/'+urllib.parse.quote(d,safe='')
  try:
   raw,final,ct=get(url);p=S/(stem+'_datacite.json');p.write_bytes(raw);out['datacite']={'status':'OK','file':p.name,'url':url}
  except Exception as e:out['datacite']={'status':'ERROR','error':str(e)}
 pmc=out.get('pmcid')
 if pmc:
  url='https://www.ebi.ac.uk/europepmc/webservices/rest/'+pmc+'/fullTextXML'
  try:
   p=S/(stem+'_fulltext.xml')
   if not p.exists():raw,final,ct=get(url);p.write_bytes(raw)
   root=ET.fromstring(p.read_bytes())
   text='\n'.join(' '.join(x.itertext()) for x in root.iter() if x.tag in ['article-title','title','p','table','caption'])
   (S/(stem+'_fulltext.txt')).write_text(text)
   out['fulltext']={'status':'OK','file':p.name,'url':url,'characters':len(text)}
  except Exception as e:out['fulltext']={'status':'ERROR','error':str(e),'url':url}
 (S/(stem+'_retrieval.json')).write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({'doi':d,'crossref':out['crossref']['status'],'epmc':out.get('epmc_hits'),'fulltext':out.get('fulltext',{}).get('status')}),flush=True)
 return out
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:out=list(pool.map(one,refs))
(S/'NEW_REFERENCE_RETRIEVAL_INDEX.json').write_text(json.dumps(out,indent=2)+'\n')
