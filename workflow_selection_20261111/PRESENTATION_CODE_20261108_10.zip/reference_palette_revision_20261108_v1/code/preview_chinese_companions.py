from pathlib import Path
import pymupdf as fitz
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parents[1];Z=R/'package/07_中文核对稿'
names=['正文_中文核对稿','图注_中文核对稿','Cover_letter_中文核对稿','两张三线表_中文核对稿']
canvas=Image.new('RGB',(1600,2200),'#ddd');draw=ImageDraw.Draw(canvas);out=[]
for k,name in enumerate(names):
 d=fitz.open(Z/(name+'.pdf'));p=d[0];pix=p.get_pixmap(matrix=fitz.Matrix(1.25,1.25),alpha=False);im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples);im.thumbnail((780,1060));canvas.paste(im,(k%2*800+(800-im.width)//2,k//2*1100+30));draw.text((k%2*800+10,k//2*1100+8),'Chinese companion '+str(k+1),fill='black')
 text='\n'.join(p.get_text() for p in d)
 assert any('\u4e00'<=c<='\u9fff' for c in text),name
 out.append({'name':name,'pages':len(d),'extracted_characters':len(text),'contains_Chinese_text':True});d.close()
canvas.save(R/'review/CHINESE_FINAL_CONTACT.png')
(R/'review/CHINESE_PDF_TEXT_CHECK.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(out,ensure_ascii=False))
