from pathlib import Path
import pymupdf as fitz
from PIL import Image,ImageDraw
import json
R=Path(__file__).resolve().parents[1];P=R/'package'
selected=[]
doc=fitz.open(P/'01_Journal_files/MANUSCRIPT.pdf')
targets=['Postoperative acute kidney injury (AKI) is associated','In eligible geographic SIM','Benchmarks also showed','Clinical implications concern','Kirchler M']
for term in targets:
 hits=[i for i,p in enumerate(doc) if term in p.get_text()]
 if hits:selected.append(('MANUSCRIPT',hits[-1]))
doc.close()
doc=fitz.open(P/'01_Journal_files/SUPPLEMENT_1.pdf')
for term in ['eFigure 11.','eFigure 17.']:
 hits=[i for i,p in enumerate(doc) if term in p.get_text() and i>20]
 if hits:selected.append(('SUPPLEMENT_1',hits[0]))
doc.close()
pages=[]
for name,i in selected:
 doc=fitz.open(P/'01_Journal_files'/(name+'.pdf'));p=doc[i];out=R/'review'/f'WORD_FINAL_{name}_P{i+1:03d}.png'
 p.get_pixmap(matrix=fitz.Matrix(1.45,1.45),alpha=False).save(out);doc.close();pages.append({'file':str(out),'document':name,'page':i+1})
for sheet,start in enumerate(range(0,len(pages),4),1):
 canvas=Image.new('RGB',(1600,2200),'#dddddd');draw=ImageDraw.Draw(canvas)
 for k,x in enumerate(pages[start:start+4]):
  im=Image.open(x['file']).convert('RGB');im.thumbnail((780,1050));x0=k%2*800+(800-im.width)//2;y0=k//2*1100+30;canvas.paste(im,(x0,y0));draw.text((k%2*800+10,k//2*1100+8),x['document']+' page'+str(x['page']),fill='black')
 canvas.save(R/'review'/f'WORD_FINAL_CONTACT_{sheet:02d}.png')
(R/'review/FINAL_WORD_VISUAL_PAGES.json').write_text(json.dumps({'selected_pages':pages,'all_supplement_pages_visually_inspected':False,'visual_review':'PENDING'},indent=2))
print(json.dumps({'pages':[(x['document'],x['page']) for x in pages]}))
