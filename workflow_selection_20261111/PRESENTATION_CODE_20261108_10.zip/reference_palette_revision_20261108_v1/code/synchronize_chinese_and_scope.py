from pathlib import Path
import json,re
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources'
en=(S/'MANUSCRIPT_EN.md').read_text()
en=en.replace('Kirchler M, Ferro M, Lorenzini V, van de Water RP, Lippert C, Ganna A.','Kirchler M, Ferro M, Lorenzini V, et al.')
en=en.replace('did not improve their respective primary outcomes.','did not demonstrate improvement in their respective primary outcomes.')
en=en.replace('on October 31, November 1, November 4, and November 5, 2026.','on October 31, November 1, November 4, November 5, and November 8, 2026.')
(S/'MANUSCRIPT_EN.md').write_text(en)
refs=json.loads((R/'sources/FINAL_MAIN_REFERENCES.json').read_text())
for x in refs:
 if '02363' in x['doi']:x['reference']=x['reference'].replace('Kirchler M, Ferro M, Lorenzini V, van de Water RP, Lippert C, Ganna A.','Kirchler M, Ferro M, Lorenzini V, et al.')
(R/'sources/FINAL_MAIN_REFERENCES.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
mapping={int(k):v for k,v in json.loads((R/'review/REFERENCE_NUMBERING_AND_COUNTS.json').read_text())['old_to_new_reference_numbers'].items()}
zh=(S/'MANUSCRIPT_ZH.md').read_text()
def renum(m):
 nums=list(map(int,m.group(1).split(',')))
 return '['+','.join(map(str,sorted(mapping[n] for n in nums)))+']'
zh=re.sub(r'\[(\d+(?:,\d+)*)\]',renum,zh.split('## 参考文献')[0])
def section(s,title,new):
 a,b=s.split('## '+title+'\n',1);old,sep,tail=b.partition('\n## ')
 return a+'## '+title+'\n\n'+new.strip()+'\n'+(sep+tail if sep else '')
intro="""术后急性肾损伤（AKI）与并发症、慢性肾病及死亡相关。[1] 癌症队列显示，不同治疗和手术的AKI风险存在差异。[2] 对胃肠肿瘤手术，风险评估需要将评估时点可获得的信息与选中患者的复核容量联系起来。

常规变量预测和阶段性更新已有研究基础。OAKS使用六项术前变量，丹麦结直肠癌模型也采用术前资料。[3,4] Lei等比较了围术期阶段及高风险比例，其他外科研究则观察到不同的术中信息增益。[5,6,7] 近期实时模型在不同地理位置的医院接受了评价。[8] 然而，对九个已发表模型的外部评价仍发现校准偏差。[9] 这些研究说明，信息时点及迁移表现应与区分度、校准和适用性一起评价。[10,11]

预测信息采集与患者复核共同占用临床资源。CoAI将采集成本纳入模型构建。[12] 对已选择的临床系统，实际比较方案是将这些资源用于依靠现有信息复核更多患者。等长名单比较没有纳入信息采集负担，源概率阈值迁移还可能改变名单长度。因此，临床问题是在可用复核预算内，哪种信息策略能够覆盖更多记录性事件。

本研究比较胃肠肿瘤手术后冻结的九项与27项术前系统及术毕更新。探索性扩展将采集与复核纳入共同假设预算，估计等捕获余量，并考察不同成本分布；同家族比较予以保留。公共来源评价考察INSPIRE及MIMIC-IV日历窗口敏感性队列的校准和阈值负担。目标使用者为规划术后复核的围术期临床人员。"""
discussion="""增加信息的资源价值随场景变化。在五种假设成本分布下，20%预算中扩大九项复核的平均捕获高于采集27项。地理术毕更新有正的采集余量，但分布加权后的取舍取决于成本；时间及同家族阶段结果一致性较弱。MIMIC六项系统区分度中等偏低、校准斜率偏低，源20%切点迁移后名单增大。

OAKS和丹麦模型说明常规术前预测的价值。[3,4] Lei等评价围术期阶段及固定高风险比例，CoAI将特征成本纳入模型构建。[5,12] 本研究将已选择的临床流程与相同资源预算下扩大基础复核进行比较，明确了计入采集负担后剩余的复核容量。

信息可以通过缩短达到同一记录事件数的名单，或在共同预算内覆盖更多事件产生价值。九至27项比较中，所检成本分布下复核容量减少造成的损失，超过了零成本时较小的增益。分布加权同时考虑某条路径更常覆盖更多事件的程度，以及收益和损失的大小。采集负担集中于零附近的自动化流程需要与其匹配的成本分布。

等捕获边界表示指定基础容量下的采集余量。正的D表示匹配基础捕获数后仍可追加采集；负的D表示计入采集前，该路径已需要更多复核。地理术毕边界为每1000条记录135.6个复核当量（95%CI，91.7至167.1）；低成本加权后的正向均值仍不精确。实测任务耗时与采集、复核资源的可互换性决定其服务适用性。

术毕更新同时改变评估时点与信息。独立选择的系统在输入、模型家族、预处理和校准方面存在差异，同家族参考提供更接近条件的比较。时间评价增益较小。因此，选择术毕重估的服务应明确决策时点、合格人群和信息可得性。

基准比较也显示场景差异。SIM–AKI和Chen比较采用各自的合格子集，TabPFN在时间评价中具有更高的AUROC点估计。LLM适配改善了地理术毕Llama区分度，却降低了BioMedLM区分度。近期研究报告了LLM用于EHR预测、编码及跨系统迁移的价值。[22,23,24] 这些研究的信息表示与适配策略有别于本研究的围术期基准。在一项临床病例题试验中，较好的独立LLM表现也未转化为医师借助模型后的诊断推理改善。[25] 因此，模型价值应结合具体任务和流程评价。

公共评价将迁移与工作量联系起来。INSPIRE编码九项与六项的捕获差区间跨零，较小的时间编码九项名单伴随较低覆盖。MIMIC的Brier点估计高于实际发生率参照，同时校准斜率偏低，源切点选出36.8%和27.7%的患者。这些结果补充了既往校准偏差和多中心迁移研究。[8,9] 目标排序固定名义容量，迁移阈值则允许名单长度和覆盖同时变化；两者应与校准共同评价。[10]

测量条件也影响记录性结局。MIMIC要求基线和随访SCr，事件率随观察日数而变化。病情、检测指征、住院时长、出院和事件触发检测均可能参与。删除同日重复结果会损失已知事件。因此，外部估计描述的是其观察过程下的合格人群；复核选择和监测频率属于不同临床决策。

本研究存在以下局限。各中心肾脏信息与配对字段的合格条件，使总体及阶段评价覆盖不同。增量信息价值反映实际采集与插补过程。临床、INSPIRE和MIMIC终点表示不同肾脏结局。MIMIC缺少手术时刻、排除第0日，并依赖可用检测。地理和时间评价共享273条记录、272个分组，且曾接受先前评价。开发事件数限制模型选择，冻结系统bootstrap区间未纳入选择不确定性。资源区间为多重比较中的逐点区间。因检索任务未提供匹配采集耗时分布，成本由分析者指定；资源假定可互换，可负担性在支出前判断，干预效果属于情景假设。

临床意义在于完整复核服务的选择。BigpAK-2通过风险触发的围术期组合照护减少中重度AKI。[26] 个体化血压管理、AKI后建议、电子警报及预测触发会诊试验未显示各自主要结局改善。[27,28,29,30] 触发条件和措施的差异说明，应同时明确风险识别及后续响应。

对胃肠肿瘤手术，本研究为预测信息采集、复核覆盖和重估时点的共同选择提供依据。服务可根据实测采集负担及完成的复核，将追加信息与扩大常规信息复核作比较。本地患者特征、测量安排和复核容量应指导术毕重估与阈值迁移。记录后续照护及患者结局，可评价复核选择之后发生的变化。"""
conclusion="""在所检成本分布下，扩大九项复核的平均记录事件捕获高于采集27项；术毕价值随成本与场景变化。规划术后AKI复核时，应共同考虑信息需求、评估时点、实际覆盖和本地复核容量。"""
zh=section(zh,'前言',intro);zh=section(zh,'讨论',discussion);zh=section(zh,'结论',conclusion)
needle='### 支持分析\n\n'
para='在地理SIM–AKI合格子集中，术毕系统AUROC为0.739，已发表公式变体为0.673至0.675。Chen排序AUROC在地理和时间合格子集中分别为0.652和0.734（41和91条记录）。时间配对TabPFN术毕AUROC为0.752，选定系统为0.697（eTable 8）。全部24种校准LLM条件中，地理术毕适配使Llama AUROC增加0.1052（95%CI，0.0426至0.1669），与选定系统的差仍为−0.1233（−0.1926至−0.0598）；BioMedLM AUROC由0.499降至0.398（eTable 9；eFigure 11）。\n\n'
assert needle in zh;zh=zh.replace(needle,needle+para,1)
zh+='## 参考文献\n\n'+en.split('## References\n',1)[1]
(S/'MANUSCRIPT_ZH.md').write_text(zh)
# The detailed framework now explicitly includes all benchmark families and the integrated implication.
g=P/'06_Graphical_abstract/STUDY_FRAMEWORK_AND_CONCLUSIONS_ZH.md';s=g.read_text()
s=s.split('## Clinical implications（',1)[0]
s+='\n## 基准比较及其解释\n\n既往AKI模型包括SIM–AKI和Chen，另有TabPFN及BioMedLM、Llama 3、MedGemma。完整数据保留于eTables 8–9、eFigure 11及汇总结果。正文结果和讨论现已加入对应概括：模型相对表现随评价人群、预测时点及适配方式变化，不能归结为单一算法普遍优于其他算法。具体数值以更新正文与附件为准。\n\n## 已整合的临床意义\n\n前述英文建议段的核心现已整合进正文Discussion，并结合近期临床研究说明风险识别与响应流程的关系；结论采用更简短的临床启示。\n'
g.write_text(s)
print('Chinese sections and detailed framework synchronized')
