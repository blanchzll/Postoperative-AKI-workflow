from pathlib import Path
import json,re,csv,hashlib,unicodedata
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources';E=R/'sources'
items=json.loads((E/'reference_inventory.json').read_text())
oldmain=re.findall(r'^\[(\d+)\]\s+(.+doi.org/\S+)\s*$',(S/'MANUSCRIPT_EN.md').read_text().split('## References\n',1)[1],re.M)
byid={int(n):{'doi':line.split('doi.org/')[1].rstrip('.'),'reference':line} for n,line in oldmain}
def epmc(doi):
 res=json.loads((E/(doi.replace('/','__')+'_europepmc.json')).read_text())['resultList']['result']
 return next((x for x in res if x.get('doi','').lower()==doi.lower()),res[0] if res else {})
def fullpage(pages):
 if '-' not in pages:return pages
 a,b=pages.split('-',1)
 if a.isdigit() and b.isdigit() and len(b)<len(a):b=a[:-len(b)]+b
 return a+'-'+b
def format_new(x):
 d=x['doi'];m=epmc(d);ji=m['journalInfo'];journal=ji['journal']['medlineAbbreviation'].replace('NPJ Digit Med','npj Digit Med')
 authors=m['authorString'].strip('.').split(', ')
 # Use the indexed first three for >6 named authors, as in the retained AMA references.
 named=[a for a in authors if a not in ['FinnGen'] and 'group' not in a.lower() and 'team' not in a.lower()]
 a=', '.join(named[:3])+', et al.' if len(named)>6 else ', '.join(named)+'.'
 title=m['title'].rstrip('.')+'.'
 vol=ji.get('volume','');issue=ji.get('issue','')
 if journal in ['npj Digit Med','Nat Commun']:issue=''
 pages=fullpage(m.get('pageInfo',''))
 ref=f"{a} {title} {journal}. {m['pubYear']};{vol}"+('('+issue+')' if issue else '')+(':'+pages if pages else '')+'. https://doi.org/'+d
 return ref
for x in items:
 if x.get('new_reference_candidate'):
  n=x['locations'][0]['number_temporary'];byid[n]={'doi':x['doi'],'reference':format_new(x)}
assert set(byid)==set(range(1,31)),set(byid)
byid[2]['reference']=byid[2]['reference'].replace('STARSurg Collaborative, EuroSurg Collaborative.','STARSurg Collaborative and EuroSurg Collaborative.')
s=(S/'MANUSCRIPT_EN.md').read_text()
s=s.replace('Temporal paired TabPFN operation-end AUROC was','Chen ranking AUROC was 0.652/0.734 in the geographic/temporal eligible subsets (41/91 records). Temporal paired TabPFN operation-end AUROC was')
s=s.replace('TabPFN achieved higher temporal discrimination than the selected systems.','TabPFN had higher temporal AUROC point estimates than the selected systems.')
body=s.split('## References\n',1)[0]
pattern=re.compile(r'\[([0-9]+(?:\s*[,–-]\s*[0-9]+)*)\]')
order=[]
def ids(value):
 out=[]
 for part in value.split(','):
  parts=re.split('[–-]',part.strip())
  out.extend(range(int(parts[0]),int(parts[-1])+1))
 return out
for m in pattern.finditer(body):
 for n in ids(m.group(1)):
  assert n in byid,n
  if n not in order:order.append(n)
assert len(order)==30,(len(order),set(byid)-set(order))
mapping={old:i+1 for i,old in enumerate(order)}
def renum(m):return '['+','.join(map(str,sorted(mapping[n] for n in ids(m.group(1)))))+']'
body=pattern.sub(renum,body)
refs=[{'number':mapping[n],**byid[n]} for n in order]
s=body+'## References\n\n'+'\n\n'.join('['+str(x['number'])+'] '+x['reference'] for x in refs)+'\n'
(S/'MANUSCRIPT_EN.md').write_text(s)
(E/'FINAL_MAIN_REFERENCES.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2)+'\n')
# Rebuild both reference manager files from verified, corrected indexed metadata.
bib=[];ris=[]
for x in refs:
 d=x['doi'];m=epmc(d);key='ref'+str(x['number'])
 if d.startswith('10.13026/'):
  dc=json.loads((E/(d.replace('/','__')+'_datacite.json')).read_text())['data']['attributes']
  authors=['%s, %s'%(v.get('familyName',''),v.get('givenName','')) for v in dc['creators']]
  title=dc['titles'][0]['title'];year=str(dc['publicationYear']);journal='PhysioNet';volume=issue=pages='';version=dc.get('version','')
 else:
  au=m.get('authorList',{}).get('author',[])
  authors=[v.get('fullName') or v.get('collectiveName') or '' for v in au]
  authors=[v for v in authors if v] or [m.get('authorString','')]
  title=m['title'].rstrip('.');year=m['pubYear'];j=m.get('journalInfo',{});journal=j.get('journal',{}).get('medlineAbbreviation','');volume=j.get('volume','');issue=j.get('issue','');pages=fullpage(m.get('pageInfo',''));version=''
 def esc(v):return str(v).replace('{','\\{').replace('}','\\}')
 fields={'title':title,'author':' and '.join(authors),'journal':journal,'year':year,'volume':volume,'number':issue,'pages':pages,'doi':d,'url':'https://doi.org/'+d}
 if version:fields['note']='Version '+version
 bib.append('@article{'+key+',\n'+',\n'.join('  '+k+' = {'+esc(v)+'}' for k,v in fields.items() if v)+'\n}')
 ris.append('TY  - JOUR\nID  - '+key+'\n'+'\n'.join('AU  - '+a for a in authors)+'\nTI  - '+title+'\nJO  - '+journal+'\nPY  - '+year+'\nDO  - '+d+'\nUR  - https://doi.org/'+d+('\nVL  - '+volume if volume else '')+('\nIS  - '+issue if issue else '')+('\nSP  - '+pages if pages else '')+'\nER  -')
(S/'references.bib').write_text('\n\n'.join(bib)+'\n')
(S/'references.ris').write_text('\n\n'.join(ris)+'\n')
wc=len(s.split('## Introduction\n',1)[1].split('## Acknowledgment\n',1)[0].split())
assert wc<=3000,wc
recent=sum(int(epmc(x['doi']).get('pubYear','2026'))>=2024 for x in refs if not x['doi'].startswith('10.13026/'))+sum(x['doi'].startswith('10.13026/') for x in refs)
report={'status':'PASS_30_MAIN_REFERENCES_RENUMBERED','main_references':30,'unique_main_and_supplement_references':31,'recent_2024_2026':recent,'new_JNO_articles':3,'total_JNO_articles':4,'word_count':wc,'new_results':False,'original_results_promoted_to_main_summary':True,'old_to_new_reference_numbers':mapping}
(R/'review/REFERENCE_NUMBERING_AND_COUNTS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report))
