from pathlib import Path
import json,shutil,hashlib,difflib,datetime,zipfile
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources';A=P/'03_Author_review'
B=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/graphical_abstract_clinical_20261108_v2/delivery/AKI_JNO_20261108_FINAL_GA_V2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Keep baseline receipts visibly separate from acceptance of the revised files.
old=A/'Current_revision_review'
if old.exists():old.rename(A/'Historical_review_before_reference_palette_revision')
cur=A/'Current_revision_review';cur.mkdir()
vp=R/'review/FINAL_WORD_VISUAL_PAGES.json';j=json.loads(vp.read_text());j['visual_review']='PASS_SELECTED_FINAL_WORD_PAGES';j['reviewer']='Codex';vp.write_text(json.dumps(j,indent=2)+'\n')
for p in (R/'review').iterdir():
 if p.is_file() and p.suffix in ['.json','.md','.csv'] and 'FIRST_PASS' not in p.name:shutil.copy2(p,cur/p.name)
# The raw downloaded full texts remain in the server evidence directory.
(cur/'EVIDENCE_LOCATION_ZH.md').write_text('原文、作者稿、元数据和检索原始记录保存在t630：'+str(R/'sources')+'。本目录核查表提供准确URL、访问范围和SHA256；未将摘要访问记为全文。原文副本不属于期刊待上传文件。\n')
for lang in ['EN','ZH']:
 path=f'MANUSCRIPT_{lang}.md'
 html=difflib.HtmlDiff(wrapcolumn=110).make_file((B/'04_Editable_sources'/path).read_text().splitlines(),(S/path).read_text().splitlines(),fromdesc='Previous Nov8 GA package',todesc='References and JAMA palette revision',context=True,numlines=3)
 (A/f'MANUSCRIPT_{lang}_COMPARISON.html').write_text(html)
# Update active presentation manifests, archiving their unchanged parent receipts.
V=P/'05_Figure_assets/JNO_VECTOR_PAGES';hist=V/'audit/before_color_revision';hist.mkdir(exist_ok=True)
for name in ['PAGE_AND_PANEL_MANIFEST.json','SOURCE_AND_OUTPUT_MANIFEST.json','ACCEPTANCE.json']:
 if (V/name).exists():shutil.copy2(V/name,hist/name)
p=V/'PAGE_AND_PANEL_MANIFEST.json';spec=json.loads(p.read_text())
def update(obj):
 if isinstance(obj,list):
  for v in obj:update(v)
 elif isinstance(obj,dict):
  for ext in ['pdf','svg','png']:
   if isinstance(obj.get(ext),str) and (V/obj[ext]).is_file():obj[ext+'_sha256']=sha(V/obj[ext])
  if isinstance(obj.get('composite_pdf'),str) and (V/obj['composite_pdf']).is_file():obj['composite_sha256']=sha(V/obj['composite_pdf'])
  if isinstance(obj.get('file'),str) and (V/obj['file']).is_file() and 'sha256' in obj:obj['sha256']=sha(V/obj['file'])
  for v in list(obj.values()):update(v)
update(spec)
spec.update(status='PASS_JAMA_COLOR_VARIANT_OF_ACCEPTED_NATIVE_PANELS',palette_revision='references_jama_palette_20261108_v1',parent_manifest='audit/before_color_revision/PAGE_AND_PANEL_MANIFEST.json',original_numeric_fingerprints_retained=True,current_color_and_geometry_verification='../../03_Author_review/Current_revision_review/FINAL_FIGURE_COLOR_AND_GEOMETRY_VERIFICATION.json',final_visual_review='PASS_ALL31_NATIVE_PAGES')
p.write_text(json.dumps(spec,indent=2)+'\n')
(V/'ACCEPTANCE.json').write_text(json.dumps({'status':'PASS_JAMA_COLOR_VARIANT_WITH_FROZEN_GEOMETRY_AND_TEXT','scope':'Presentation only; original scientific/source acceptance retained in audit/before_color_revision','original_acceptance_sha256':sha(hist/'ACCEPTANCE.json'),'page_manifest_sha256':sha(p),'figures':18,'panels':53,'pages':31,'new_statistics':False,'full104_page_supplement_visual_review':False},indent=2)+'\n')
rows=[{'path':str(x.relative_to(V)),'sha256':sha(x)} for x in sorted(V.rglob('*')) if x.is_file() and x.suffix in ['.pdf','.svg','.png']]
(V/'SOURCE_AND_OUTPUT_MANIFEST.json').write_text(json.dumps({'status':'PASS_CURRENT_JAMA_PRESENTATION_OUTPUTS','parent_source_manifest':'audit/before_color_revision/SOURCE_AND_OUTPUT_MANIFEST.json','files':rows},indent=2)+'\n')
p=P/'05_Figure_assets/Independent_panels/PANEL_MANIFEST.json';j=json.loads(p.read_text())
for row in j['panels']:row['sha256']=sha(P/row['file'])
j.update(status='PASS_CURRENT71_JAMA_COLOR_PANEL_PDFS',palette_revision='references_jama_palette_20261108_v1',numeric_fingerprints_unchanged=True);p.write_text(json.dumps(j,indent=2)+'\n')
p=P/'05_Figure_assets/FIGURE_SOURCE_INDEX.json';j=json.loads(p.read_text())
for row in j:
 folder=P/'05_Figure_assets'/row['label'].replace(' ','_')
 row['assets']={str(f.relative_to(P)):sha(f) for f in folder.iterdir() if f.is_file()}
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
# Include all new presentation/verification code beside the unchanged published study archive.
C=P/'02_Code_and_aggregate_data/reference_palette_revision_20261108_v1';C.mkdir()
shutil.copytree(R/'code',C/'code',ignore=shutil.ignore_patterns('__pycache__'))
(C/'README_ZH.md').write_text('本目录为本轮引文整理、文字整合、颜色转换、文档导出和核对代码。未增加模型、bootstrap或情景分析。原公开分析代码及汇总数据保持不变；本轮新增脚本尚未推送到GitHub。原文下载缓存位于服务器sources目录；Arial字体需要使用者自备，不随包分发。流程为：核对公开来源及编号→整合正文→转换矢量颜色并回读→生成预览→重建Word/PDF→核对最终文件。脚本中的服务器冻结输入路径保留溯源，运行前应按README检查对应材料。\n')
with zipfile.ZipFile(P/'01_Journal_files/PRESENTATION_REVISION_CODE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in sorted(C.rglob('*')):
  if x.is_file():z.write(x,str(x.relative_to(C)))
(P/'README_ZH.md').write_text("""# AKI JAMA Network Open 投稿文件：引文与配色修订版

正文2930英文词，摘要323词，Key Points80词。正文30条参考文献，其中24条发表于2024–2026年；附件9条，合并去重31篇。本轮新增3篇目标期刊原始研究，另保留Lei等2019年关键近邻。

31篇均确认身份并按实际访问范围核对引用用途：26篇取得全文或作者稿，2项取得数据集官方说明，3篇仅取得结构化摘要。逐条来源、引用位置和范围见03_Author_review/Current_revision_review/REFERENCE_VERIFICATION.csv及同名JSON。

引言和讨论已更新；正文结果与讨论已纳入SIM–AKI、Chen、TabPFN及LLM比较，全部24种校准LLM条件、54项探索性比较和阴性结果保留在附件。临床意义已整合Discussion，结论保留简洁启示。

5幅主图、18幅补图、图形摘要及71个独立分面采用统一JAMA风格配色。197个图形PDF、90个SVG与原图的数值绘图指令和文字逐文件核对；95个PNG/TIFF同步导出；Supplement 1的31个图页保留可编辑矢量，实际图中文字Arial10pt。图注颜色说明已同步。Supplement 1为104页，两张原主表仍提供可编辑三线表。

01_Journal_files为期刊文件；02为完整原研究代码、汇总数据及本轮修订代码；03为作者内部核对材料；04为可编辑正文与分章节文件；05为图形；06为临床图形摘要和详细框架。

原分析公开版本：https://github.com/blanchzll/Postoperative-AKI-workflow ，提交f2785e68b0eb713c5807a4288c50bc7f40a856de。原分析代码压缩包和967个原代码/汇总文件保持字节一致。本轮新增排版/核查脚本随包提供，尚未推送仓库。未重新拟合模型、抽样或计算情景结果。

原验收记录对应原版本，其输出哈希不覆盖本轮修改。当前文件核对见Current_revision_review、FINAL_REVISION_ACCEPTANCE.json及CONTENTS_MANIFEST.json。作者真实声明仍需按实际文件核实；未执行期刊投稿。
""")
# Preserve old root receipts as baseline evidence instead of labeling them current.
H=A/'Historical_root_receipts_before_reference_palette';H.mkdir()
for name in ['GA_V2_ACCEPTANCE.json','GA_V2_REVISION_NOTE_ZH.md']:
 if (P/name).exists():shutil.move(str(P/name),H/name)
status=json.loads((P/'REVISION_STATUS.json').read_text())
status.update(status='REFERENCE_AND_JAMA_PALETTE_REVISION_COMPLETE_AUTHOR_CONFIRMATION_PENDING',current_revision='references_jama_palette_20261108_v1',main_text_words=2930,main_references=30,unique_references=31,references_2024_2026=24,reference_access={'full_article_or_author_manuscript':26,'official_resource_documentation':2,'structured_abstract_only':3},main_manuscript_unchanged_from_parent=False,full_manuscript_files_revised=True,medical_evidence_writing_applied_to_current_summary=True,all_figures_JAMA_inspired_colors=True,main_manuscript_pages=22,supplement_pages=104,new_presentation_code_included=True,new_presentation_code_uploaded_to_github=False,all_native_figure_pages_visually_inspected=True,all_supplement_pages_visually_inspected=False,current_acceptance='FINAL_REVISION_ACCEPTANCE.json')
(P/'REVISION_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2)+'\n')
(R/'review/SKILL_APPLICATION.json').write_text(json.dumps({'status':'APPLIED_TO_CURRENT_REVISION','skills':{'medical-evidence-writing':'Main-text evidence strength, clinical implications, citation-to-claim scope, Results/Discussion separation and captions','phd-paper-verification':'Exact identities, claim binding, numerical-source consistency and final-document checks','paper-search-mcp':'Exact-title Crossref retrieval with identity gate; older CLI DOI text mismatch excluded','academic-plotting':'Data-figure styling and native vector outputs; user-requested JAMA palette takes precedence over generic palette defaults'},'primary_retrieval':'PubMed/EuropePMC, Crossref, DataCite, publisher articles and PhysioNet','BioMCP_run':False,'public_API_extraction_only':True,'Codex_verified_source_extractions':True,'independent_human_review_claimed':False},indent=2)+'\n')
shutil.copy2(R/'review/SKILL_APPLICATION.json',cur/'SKILL_APPLICATION.json')
a={'status':'PASS_AUTHORIZED_REFERENCE_TEXT_AND_ALL_FIGURE_COLOR_REVISION','scope':'Reference identities and cited scopes, main text and synchronized translations, JAMA-inspired palette and final package','main_words':2930,'main_references':30,'recent_references':24,'unique_references':31,'reference_access_limitations_recorded':True,'reference_verification_sha256':sha(cur/'REFERENCE_VERIFICATION.json'),'document_verification_sha256':sha(cur/'CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json'),'figure_verification_sha256':sha(cur/'FINAL_FIGURE_COLOR_AND_GEOMETRY_VERIFICATION.json'),'track_changes_sha256':sha(cur/'TRACK_CHANGES_VERIFICATION.json'),'visual_review_sha256':sha(cur/'CONTACT_SHEETS.json'),'selected_Word_page_review_sha256':sha(cur/'FINAL_WORD_VISUAL_PAGES.json'),'parent_manifest_sha256':sha(B/'CONTENTS_MANIFEST.json'),'original_analysis_code_and_aggregates_unchanged':True,'new_statistics':False,'formal_submission':False,'author_statements_confirmed':False}
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(a,indent=2)+'\n')
# A current code index includes the original code and this scoped presentation delta.
Croot=P/'02_Code_and_aggregate_data'
rows=[{'path':str(x.relative_to(Croot)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in sorted(Croot.rglob('*')) if x.is_file() and x!=Croot/'CURRENT_SOURCE_INDEX.json']
(Croot/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'status':a['status'],'current_author_review':str(cur),'all_original_analysis_materials_preserved':True}))
