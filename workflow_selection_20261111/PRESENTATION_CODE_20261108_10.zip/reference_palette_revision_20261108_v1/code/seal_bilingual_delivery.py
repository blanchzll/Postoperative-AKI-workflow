from pathlib import Path
import json,re,hashlib,shutil,zipfile,datetime
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources';A=P/'03_Author_review';cur=A/'Current_revision_review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Final source snapshot includes the new editable Chinese companions.
snapshot={str(x.relative_to(P)):sha(x) for folder in [S,P/'06_Graphical_abstract',P/'07_中文核对稿'] for x in sorted(folder.rglob('*')) if x.is_file()}
(R/'review/FINAL_SOURCE_HASHES.json').write_text(json.dumps(snapshot,ensure_ascii=False,indent=2)+'\n')
# Refresh caption text as well as file hashes in the active figure index.
parts=re.split(r'(?=^## (?:e)?Figure \d+\.)',(S/'FIGURE_LEGENDS.md').read_text(),flags=re.M)[1:]
captions={re.match(r'## ((?:e)?Figure \d+)\.',x).group(1):x for x in parts}
p=P/'05_Figure_assets/FIGURE_SOURCE_INDEX.json';j=json.loads(p.read_text())
for row in j:
 part=captions[row['label']];row['title']=part.splitlines()[0][3:];row['caption']='\n'.join(part.splitlines()[1:]).strip()
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
# Root summary and current acceptance refer to the last actual tests.
v=json.loads((R/'review/CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json').read_text())
p=P/'README_ZH.md';s=p.read_text().replace('和967个原代码/汇总文件','和'+str(v['original_code_and_aggregate_files_unchanged'])+'个原代码/汇总文件（当前文件索引与代码可得性说明除外）')
s+='\n07_中文核对稿：完整中文正文、23条图注、Cover letter、摘要要点、两张中文三线表、图形摘要图注，以及中英对照和独立章节。提供8份中文/中英可编辑Word及PDF；分章节中文Word另附。参考文献保留原始题名，便于查证。中文稿供内部修改，01目录为英文投稿文件。\n'
p.write_text(s)
p=P/'REVISION_STATUS.json';j=json.loads(p.read_text());j.update(status='REFERENCES_JAMA_PALETTE_AND_BILINGUAL_PACKAGE_COMPLETE_AUTHOR_CONFIRMATION_PENDING',Chinese_companion_DOCX=8,Chinese_independent_chapters=5,Chinese_figure_legends=23,Chinese_editable_three_line_tables=2,Chinese_manuscript_pages=14,Chinese_legend_pages=8,Chinese_cover_pages=1,Chinese_table_pages=2)
p.write_text(json.dumps(j,ensure_ascii=False,indent=2)+'\n')
report="""# 本轮最终修改说明

正文参考文献由18条扩充至30条，其中24条发表于2024–2026年，新增3篇JAMA Network Open原始研究；附件9条，去重31篇。使用medical-evidence-writing、phd-paper-verification和paper-search-mcp核对身份与具体引用用途。26篇取得全文/作者稿、2项取得数据集官方说明、3篇仅取得结构化摘要，访问范围逐条标明。

前言已结合近期原始研究明确临床问题和具体比较；结果与讨论已加入SIM–AKI、Chen、TabPFN及LLM基准概括，临床意义整合进讨论，结论简化为服务设计启示。正文2930词，保留原有方法、统计结果及重要阴性结果。

全部5幅主图、18幅补图及图形摘要统一为ggsci的JAMA风格配色，图注颜色文字同步。197个PDF与90个SVG已核对相对父版本的绘图几何、数值文字及颜色；95份栅格预览同步。31个补图页以矢量SVG嵌入Word，保留71个独立分面。图形总体37页均已查看；最终Word选定7页查看，未声称逐页目检全部104页附件。

中文修改材料集中在07_中文核对稿：正文、23条图注、Cover letter、摘要与要点、两张三线表、图形摘要图注、中英对照、五个独立章节。全部显式图注数字和表格数值核对一致。可编辑Word和PDF均已导出，并查看代表页确认中文字符显示正常。

冻结数据、模型、bootstrap样本、情景输出和公开分析代码压缩包均未重跑或更改。本轮新增引文/排版/核对脚本随包提供，尚未推送GitHub。当前代码索引及代码可得性说明属于本轮更新的元数据。作者真实声明仍需按实际资料核准，未执行期刊系统投稿。

配色来源：https://nanx.me/ggsci/reference/pal_jama.html 。此为参考JAMA图形的色板，并非期刊强制规定的十六进制色号。
"""
(R/'review/FINAL_REVIEW_ZH.md').write_text(report)
# Keep only current final checks in the current-review directory. Earlier records remain in server review/ and archived parent folders.
wanted=['REFERENCE_VERIFICATION.json','REFERENCE_VERIFICATION.csv','REFERENCE_VERIFICATION_ZH.md','REFERENCE_NUMBERING_AND_COUNTS.json','CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json','FINAL_FIGURE_COLOR_AND_GEOMETRY_VERIFICATION.json','JAMA_COLOR_TRANSFORMATION.json','RASTER_REGENERATION.json','CONTACT_SHEETS.json','FINAL_WORD_VISUAL_PAGES.json','TRACK_CHANGES_VERIFICATION.json','CHINESE_COMPANIONS_VERIFICATION.json','CHINESE_DOCUMENT_RENDER.json','CHINESE_PDF_TEXT_CHECK.json','CHINESE_VISUAL_REVIEW.json','FINAL_SOURCE_HASHES.json','SKILL_APPLICATION.json','FINAL_REVIEW_ZH.md']
for p in list(cur.iterdir()):
 if p.is_file() and p.name not in wanted and p.name!='EVIDENCE_LOCATION_ZH.md':
  target=A/'Historical_review_before_reference_palette_revision'/'intermediate_current_revision_records';target.mkdir(exist_ok=True);shutil.move(str(p),target/p.name)
for name in wanted:shutil.copy2(R/'review'/name,cur/name)
# Include this latest presentation code without font binaries or raw article caches.
C=P/'02_Code_and_aggregate_data/reference_palette_revision_20261108_v1'
shutil.copytree(R/'code',C/'code',dirs_exist_ok=True,ignore=shutil.ignore_patterns('__pycache__'))
with zipfile.ZipFile(P/'01_Journal_files/PRESENTATION_REVISION_CODE.zip','w',zipfile.ZIP_DEFLATED) as z:
 for x in sorted(C.rglob('*')):
  if x.is_file():z.write(x,str(x.relative_to(C)))
Croot=P/'02_Code_and_aggregate_data';rows=[{'path':str(x.relative_to(Croot)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in sorted(Croot.rglob('*')) if x.is_file() and x!=Croot/'CURRENT_SOURCE_INDEX.json']
(Croot/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps(rows,indent=2)+'\n')
a=json.loads((P/'FINAL_REVISION_ACCEPTANCE.json').read_text());a.update(status='PASS_REFERENCE_JAMA_PALETTE_AND_BILINGUAL_DELIVERY',Chinese_companions_verified=True,Chinese_companion_DOCX=8,current_document_verification_sha256=sha(cur/'CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json'),Chinese_verification_sha256=sha(cur/'CHINESE_COMPANIONS_VERIFICATION.json'),Chinese_render_sha256=sha(cur/'CHINESE_DOCUMENT_RENDER.json'),Chinese_visual_review_sha256=sha(cur/'CHINESE_VISUAL_REVIEW.json'),final_source_hashes_sha256=sha(cur/'FINAL_SOURCE_HASHES.json'))
a['document_verification_sha256']=sha(cur/'CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json')
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(a,indent=2)+'\n')
# The source-bound GA exports remain current after the palette revision.
p=P/'06_Graphical_abstract/SOURCE_BINDING.json';j=json.loads(p.read_text());j['source_manuscript_sha256']=sha(S/'MANUSCRIPT_EN.md')
j['exports']={x.name:sha(x) for x in p.parent.glob('GRAPHICAL_ABSTRACT_CLINICAL_V2.*')}
p.write_text(json.dumps(j,indent=2)+'\n')
# Seal the final folder, excluding only its own root manifest.
files=[{'path':str(x.relative_to(P)),'bytes':x.stat().st_size,'sha256':sha(x)} for x in sorted(P.rglob('*')) if x.is_file() and x!=P/'CONTENTS_MANIFEST.json']
manifest={'status':'SEALED_CURRENT_ENGLISH_SUBMISSION_AND_CHINESE_AUTHOR_REVISION_PACKAGE','created_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'manifest_excludes_itself':True,'files':files}
(P/'CONTENTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
D=R/'delivery';D.mkdir(exist_ok=True);name='AKI_JNO_20261108_BILINGUAL_JAMA_FINAL';z=D/(name+'.zip')
assert not z.exists(),'Preserve existing delivery'
with zipfile.ZipFile(z,'w',zipfile.ZIP_DEFLATED,compresslevel=4) as archive:
 for x in sorted(P.rglob('*')):
  if x.is_file():archive.write(x,str(Path(name)/x.relative_to(P)))
receipt={'status':'SEALED_PENDING_PORTABLESSD_VERIFICATION','zip':str(z),'zip_sha256':sha(z),'manifest_sha256':sha(P/'CONTENTS_MANIFEST.json'),'file_count':len(files)+1,'zip_bytes':z.stat().st_size,'folder_name':name}
(D/'BUILD_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
