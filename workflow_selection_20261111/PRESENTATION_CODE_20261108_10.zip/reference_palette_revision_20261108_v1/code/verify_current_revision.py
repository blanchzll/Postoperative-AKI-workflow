from pathlib import Path
import json,re,zipfile,hashlib,io,collections
from docx import Document
from pypdf import PdfReader
from pypdf.generic import ContentStream
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources'
B=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/graphical_abstract_clinical_20261108_v2/delivery/AKI_JNO_20261108_FINAL_GA_V2')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
s=(S/'MANUSCRIPT_EN.md').read_text();refs=json.loads((R/'sources/FINAL_MAIN_REFERENCES.json').read_text())
wc=len(s.split('## Introduction\n')[1].split('## Acknowledgment\n')[0].split());assert wc==2930
body=s.split('## References\n')[0]
cites={int(n) for x in re.findall(r'\[([0-9,]+)\]',body) for n in x.split(',')};assert cites==set(range(1,31))
assert len(re.findall(r'^\[\d+\]',s.split('## References\n')[1],re.M))==30
assert len(re.findall(r'^@article', (S/'references.bib').read_text(),re.M))==31
assert (S/'references.ris').read_text().count('TY  - JOUR')==31
allpdfs={}
for name in ['MANUSCRIPT','SUPPLEMENT_1','FIGURE_LEGENDS','COVER_LETTER']:
 p=P/'01_Journal_files'/(name+'.pdf');r=PdfReader(p);text='\n'.join(x.extract_text() for x in r.pages);allpdfs[name]={'pages':len(r.pages),'characters':len(text),'sha256':sha(p)}
 if name=='MANUSCRIPT':
  norm=re.sub(r'\s+','',text).lower()
  for ref in refs:assert ref['doi'].lower() in norm,ref['doi']
  for token in ['SIM','Chen','TabPFN','BioMedLM','Llama','2930','Clinical implications']:assert token in text,token
  assert 'Slate' in text and 'vermilion' not in text
 if name=='SUPPLEMENT_1':
  for token in ['eTable 8','eTable 9','BioMedLM','Llama 3','MedGemma','eFigure 11']:assert token in text,token
# Audit all31 native SVGs actually embedded in the final Word supplement.
with zipfile.ZipFile(P/'01_Journal_files/SUPPLEMENT_1.docx') as z:
 media=[n for n in z.namelist() if n.startswith('word/media/')]
 assert len(media)==31 and all(n.endswith('.svg') for n in media),media
 old=['#0072b2','#d55e00','#8063a6','#b8522d']
 for n in media:
  text=z.read(n).decode().lower();assert not any(c in text for c in old),n
# Original tables, method records and results are unchanged; source references can be reformatted separately.
for name in ['ETABLES.md','ERESULTS.md','EMETHODS.md','MAIN_TABLES.md']:
 assert sha(S/name)==sha(B/'04_Editable_sources'/name),name
unchanged=0
for p in (B/'02_Code_and_aggregate_data').rglob('*'):
 if p.is_file() and p.name not in ['CURRENT_SOURCE_INDEX.json','CODE_AVAILABILITY.md']:assert sha(P/p.relative_to(B))==sha(p),p;unchanged+=1
assert sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip')
# Three-line editable original main tables remain true Word tables.
d=Document(P/'01_Journal_files/Supplementary_tables/EDITABLE_THREE_LINE_TABLES.docx');assert len(d.tables)==2
norefs=lambda txt:re.sub(r'\[\d+(?:,\d+)*\]','REF',txt)
assert norefs(s.split('## Methods\n')[1].split('## Results\n')[0])==norefs((B/'04_Editable_sources/MANUSCRIPT_EN.md').read_text().split('## Methods\n')[1].split('## Results\n')[0])
out={'status':'PASS_CURRENT_REFERENCES_TEXT_DOCX_PDF_AND_FIGURE_EMBEDDING','main_words':wc,'main_references':30,'reference_library_entries':31,'current_citations_resolve':True,'all30_DOIs_present_in_final_pdf':True,'native_supplement_svg_images':31,'frozen_method_text_preserved_except_reference_numbers':True,'frozen_source_tables_methods_results_unchanged':True,'original_code_and_aggregate_files_unchanged':unchanged,'published_analysis_archive_unchanged':True,'editable_three_line_main_tables':2,'pdfs':allpdfs,'new_models':0,'new_bootstraps':0,'new_scenarios':0,'formal_submission':False,'author_declarations_confirmed':False}
(R/'review/CURRENT_DOCUMENT_AND_SOURCE_VERIFICATION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out))
