from pathlib import Path
import re,json,hashlib,zipfile,io
from pypdf import PdfReader,PdfWriter
from pypdf.generic import ContentStream,FloatObject,NameObject,DecodedStreamObject
R=Path(__file__).resolve().parents[1];P=R/'package'
MAP={'#0072b2':'#374e55','#d55e00':'#df8f44','#8063a6':'#6a6599','#b8522d':'#df8f44','#e8f1f7':'#ebeff0','#f5f0e8':'#fcf4ec','#eff5f3':'#f1f7f4'}
COLORS=[k for k in MAP]
def sha(b):return hashlib.sha256(b).hexdigest()
def svg(s):
 def sub(m):return MAP.get(m.group().lower(),m.group())
 return re.sub(r'#[0-9a-fA-F]{6}\b',sub,s)
def normalized_svg(s):
 return re.sub(r'#[0-9a-fA-F]{6}\b','COLOR',s)
def rgb_map(args):
 old=[float(x) for x in args]
 for src,dst in MAP.items():
  target=[int(src[i:i+2],16)/255 for i in [1,3,5]]
  if max(abs(a-b) for a,b in zip(old,target))<0.0021:
   return [FloatObject(int(dst[i:i+2],16)/255) for i in [1,3,5]]
 return args
def fingerprint(reader):
 rows=[];seen=set()
 def one(obj,path):
  key=id(obj)
  if key in seen:return
  seen.add(key)
  cs=ContentStream(obj,reader)
  vals=[]
  for args,op in cs.operations:
   vals.append((op.decode('latin1'), ['COLOR'] if op in [b'rg',b'RG'] else [repr(a) for a in args]))
  rows.append((path,vals))
  for name,v in obj.get('/Resources',{}).get('/XObject',{}).items():
   x=v.get_object()
   if x.get('/Subtype')=='/Form':one(x,path+'/'+str(name))
 for i,pg in enumerate(reader.pages):
  if pg.get_contents() is not None:one(pg.get_contents(),str(i))
  for name,v in pg.get('/Resources',{}).get('/XObject',{}).items():
   x=v.get_object()
   if x.get('/Subtype')=='/Form':one(x,str(i)+'/'+str(name))
 return sha(json.dumps(rows,sort_keys=True).encode())
def patch_pdf(p):
 original=p.read_bytes();reader=PdfReader(io.BytesIO(original));before=fingerprint(reader)
 texts=[x.extract_text() for x in reader.pages];sizes=[tuple(map(float,pg.mediabox)) for pg in reader.pages]
 writer=PdfWriter();writer.clone_document_from_reader(reader)
 seen=set();changes=0
 def patch(obj):
  nonlocal changes
  if id(obj) in seen:return None
  seen.add(id(obj));cs=ContentStream(obj,writer)
  for idx,(args,op) in enumerate(cs.operations):
   if op in [b'rg',b'RG'] and len(args)==3:
    new=rgb_map(args)
    if [float(x) for x in new]!=[float(x) for x in args]:cs.operations[idx]=(new,op);changes+=1
  return cs
 def form(obj):
  cs=patch(obj)
  if cs is None:return
  obj.set_data(cs.get_data())
  for v in obj.get('/Resources',{}).get('/XObject',{}).values():
   x=v.get_object()
   if x.get('/Subtype')=='/Form':form(x)
 for pg in writer.pages:
  if pg.get_contents() is not None:
   cs=patch(pg.get_contents())
   stream=DecodedStreamObject();stream.set_data(cs.get_data());pg[NameObject('/Contents')]=writer._add_object(stream)
  for v in pg.get('/Resources',{}).get('/XObject',{}).values():
   x=v.get_object()
   if x.get('/Subtype')=='/Form':form(x)
 if not changes:return None
 buf=io.BytesIO();writer.write(buf);out=buf.getvalue();after=PdfReader(io.BytesIO(out))
 assert fingerprint(after)==before,('Drawing operators changed',p)
 assert [x.extract_text() for x in after.pages]==texts,('Text changed',p)
 out_sizes=[tuple(map(float,pg.mediabox)) for pg in after.pages]
 assert all(max(abs(a-b) for a,b in zip(x,y))<1e-6 for x,y in zip(sizes,out_sizes)),(p,sizes,out_sizes)
 # PDF number serialization may differ by less than 1e-6 point; native SVG geometry is byte-identical apart from colors.
 p.write_bytes(out)
 return {'path':str(p.relative_to(P)),'source_sha256':sha(original),'output_sha256':sha(out),'color_operators_changed':changes,'noncolor_drawing_operators_unchanged':True,'text_and_page_dimensions_unchanged':True}
previous=json.loads((R/'review/JAMA_COLOR_TRANSFORMATION.json').read_text()) if (R/'review/JAMA_COLOR_TRANSFORMATION.json').exists() else {}
records=previous.get('pdf_records',[]);svg_records=previous.get('svg_records',[])
for folder in [P/'05_Figure_assets',P/'06_Graphical_abstract']:
 for p in sorted(folder.rglob('*.pdf')):
  x=patch_pdf(p)
  if x:records.append(x)
 for p in sorted(folder.rglob('*.svg')):
  old=p.read_text();new=svg(old)
  assert normalized_svg(old)==normalized_svg(new)
  if new!=old:
   p.write_text(new);svg_records.append({'path':str(p.relative_to(P)),'source_sha256':sha(old.encode()),'output_sha256':sha(new.encode()),'geometry_and_text_unchanged':True})
# The five independent submission files are byte-identical copies of recolored figure assets.
for i in range(1,6):
 dst=P/'01_Journal_files'/f'FIGURE_{i}.pdf'
 old=dst.read_bytes()
 candidates=list((P/'05_Figure_assets'/f'Figure_{i}').glob('*.pdf'))
 # Determine original match in immutable parent, then copy its recolored counterpart.
 B=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/graphical_abstract_clinical_20261108_v2/delivery/AKI_JNO_20261108_FINAL_GA_V2')
 matches=[x for x in candidates if sha((B/x.relative_to(P)).read_bytes())==sha(old) or sha(x.read_bytes())==sha(old)]
 assert len(matches)==1,(i,matches)
 dst.write_bytes(matches[0].read_bytes())
for p in [P/'01_Journal_files/SUPPLEMENT_1.docx']:
 with zipfile.ZipFile(p) as z:items=[(x,z.read(x.filename)) for x in z.infolist()]
 n=0
 out=io.BytesIO()
 with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED) as z:
  for info,data in items:
   if info.filename.startswith('word/media/') and info.filename.endswith('.svg'):
    old=data.decode();new=svg(old);assert normalized_svg(old)==normalized_svg(new);data=new.encode();n+=1
   z.writestr(info,data)
 p.write_bytes(out.getvalue())
 assert n==31,n
report={'status':'PASS_VECTOR_COLOR_TRANSFORMATION','palette_source':'https://nanx.me/ggsci/reference/pal_jama.html','palette_note':'JAMA-inspired ggsci palette, not a publisher-mandated hexadecimal specification','mapping':MAP,'pdf_files':len(records),'svg_files':len(svg_records),'embedded_supplement_svgs':31,'new_statistics':False,'pdf_records':records,'svg_records':svg_records,'raster_previews_pending':True}
(R/'review/JAMA_COLOR_TRANSFORMATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['pdf_records','svg_records']}))
