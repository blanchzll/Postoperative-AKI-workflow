from pathlib import Path
import json,urllib.request,concurrent.futures,re
from html.parser import HTMLParser
R=Path(__file__).resolve().parents[1];S=R/'sources'
refs=[x for x in json.loads((S/'reference_inventory.json').read_text()) if x.get('new_reference_candidate')]
op=urllib.request.build_opener(urllib.request.ProxyHandler({'https':'http://127.0.0.1:7890','http':'http://127.0.0.1:7890'}))
class Text(HTMLParser):
 def __init__(self):super().__init__();self.skip=0;self.bits=[]
 def handle_starttag(self,t,a):
  if t in ['script','style','noscript']:self.skip+=1
 def handle_endtag(self,t):
  if t in ['script','style','noscript']:self.skip=max(0,self.skip-1)
 def handle_data(self,d):
  if not self.skip and d.strip():self.bits.append(d.strip())
def get(url,stem):
 try:
  req=urllib.request.Request(url,headers={'User-Agent':'Mozilla/5.0 (academic reference verification)'})
  with op.open(req,timeout=30) as f:raw=f.read();final=f.geturl()
  (S/(stem+'.html')).write_bytes(raw);p=Text();p.feed(raw.decode('utf-8','replace'));text='\n'.join(p.bits);(S/(stem+'.txt')).write_text(text)
  return {'status':'FETCHED','url':url,'final_url':final,'file':stem+'.txt','characters':len(text),'challenge':len(text)<2000 or 'Checking your browser' in text[:3000]}
 except Exception as e:return {'status':'ERROR','url':url,'error':str(e)}
def one(x):
 d=x['doi'];stem=d.replace('/','__')
 ep=S/(stem+'_europepmc.json');res=json.loads(ep.read_text()).get('resultList',{}).get('result',[]) if ep.exists() else []
 pmc=next((y.get('pmcid') for y in res if y.get('pmcid')),None)
 if d.startswith('10.13026/'):url=json.loads((S/(stem+'_datacite.json')).read_text())['data']['attributes']['url']
 elif pmc:url='https://pmc.ncbi.nlm.nih.gov/articles/'+pmc+'/'
 else:url='https://doi.org/'+d
 a=get(url,stem+'_primary_page');a['doi']=d
 (S/(stem+'_primary_retrieval.json')).write_text(json.dumps(a,indent=2)+'\n');print(d,a['status'],a.get('characters'),flush=True);return a
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:res=list(pool.map(one,refs))
(S/'NEW_PRIMARY_PAGE_INDEX.json').write_text(json.dumps(res,indent=2)+'\n')
