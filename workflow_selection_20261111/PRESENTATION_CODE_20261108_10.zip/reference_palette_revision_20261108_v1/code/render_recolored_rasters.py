from pathlib import Path
import concurrent.futures,json,os,hashlib,time
import pymupdf as fitz
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[1];P=R/'package'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def render(name):
 p=Path(name);pdf=p.with_suffix('.pdf')
 if not pdf.exists():return {'path':str(p.relative_to(P)),'status':'NO_MATCHING_PDF'}
 with Image.open(p) as im:size=im.size
 doc=fitz.open(pdf);pg=doc[0]
 pix=pg.get_pixmap(matrix=fitz.Matrix(size[0]/pg.rect.width,size[1]/pg.rect.height),alpha=False)
 im=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
 if im.size!=size:
  assert abs(im.width-size[0])<=1 and abs(im.height-size[1])<=1,(p,size,im.size)
  im=im.resize(size,Image.Resampling.LANCZOS)
 if p.suffix.lower() in ['.tif','.tiff']:im.save(p,dpi=(300,300),compression='tiff_lzw')
 else:im.save(p,dpi=(300,300))
 doc.close();im.close()
 return {'path':str(p.relative_to(P)),'source_pdf':str(pdf.relative_to(P)),'status':'PASS','dimensions':size,'sha256':sha(p)}
if __name__=='__main__':
 mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
 jobs=[str(p) for folder in [P/'05_Figure_assets',P/'06_Graphical_abstract'] for p in folder.rglob('*') if p.suffix.lower() in ['.png','.tif','.tiff']]
 workers=min(len(jobs),len(os.sched_getaffinity(0)),max(1,int((mem-max(4*1024**3,int(mem*.25)))/(1024**3))))
 with concurrent.futures.ProcessPoolExecutor(max_workers=workers) as pool:results=list(pool.map(render,jobs))
 assert all(x['status']=='PASS' for x in results),[x for x in results if x['status']!='PASS']
 (R/'review/RASTER_REGENERATION.json').write_text(json.dumps({'status':'PASS','workers':workers,'MemAvailable_bytes':mem,'per_worker_memory_reservation_bytes':1024**3,'all_owned_workers_joined':True,'files':results},indent=2)+'\n')
 # Contact sheets include every final supplemental vector page, the five main figures and GA.
 spec=json.loads((P/'05_Figure_assets/JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json').read_text())
 paths=[P/'05_Figure_assets/JNO_VECTOR_PAGES'/x['png'] for x in spec['pages']]
 for i in range(1,6):
  candidates=[p for p in (P/'05_Figure_assets'/f'Figure_{i}').glob('*.png')];assert len(candidates)==1;(paths.append(candidates[0]))
 paths.append(P/'06_Graphical_abstract/GRAPHICAL_ABSTRACT_CLINICAL_V2.png')
 sheets=[]
 for idx,start in enumerate(range(0,len(paths),4),1):
  canvas=Image.new('RGB',(1600,1800),'#dddddd');d=ImageDraw.Draw(canvas)
  for k,path in enumerate(paths[start:start+4]):
   with Image.open(path) as im:
    im=im.convert('RGB');im.thumbnail((780,850));left=k%2*800+(800-im.width)//2;top=k//2*900+35;canvas.paste(im,(left,top));d.text((k%2*800+10,k//2*900+10),path.stem,fill='black')
  out=R/'review'/f'JAMA_CONTACT_{idx:02d}.png';canvas.save(out);sheets.append(str(out))
 (R/'review/CONTACT_SHEETS.json').write_text(json.dumps({'figures':24,'supplement_pages':31,'review_items':len(paths),'sheets':sheets,'visual_review':'PENDING'},indent=2))
 print(json.dumps({'status':'PASS_RASTER_REGENERATION','files':len(results),'workers':workers,'review_items':len(paths),'contact_sheets':len(sheets)}))
