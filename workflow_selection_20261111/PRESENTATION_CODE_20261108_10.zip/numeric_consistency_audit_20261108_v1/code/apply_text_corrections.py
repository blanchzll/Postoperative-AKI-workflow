from pathlib import Path
import json,hashlib,shutil,re
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';changes=[]
def update(p,old,new,required=True):
 s=p.read_text();n=s.count(old)
 if required:assert n or new in s,(p,old)
 if n:p.write_text(s.replace(old,new));changes.append(dict(file=str(p.relative_to(P)) if p.is_relative_to(P) else str(p.relative_to(W)),replacements=n,old=old,new=new))
update(S/'MANUSCRIPT_EN.md','11.9%; 95% CI, 4.3%–20.4%','11.9%; Wilson 95% CI, 5.9%–22.5%')
update(S/'MANUSCRIPT_EN.md','Among 303 adults excluded for unavailable renal information','Among 303 records excluded for unavailable renal information')
update(S/'MANUSCRIPT_ZH.md','11.9%；95%CI，4.3%至20.4%','11.9%；Wilson 95%CI，5.9%至22.5%')
update(S/'MANUSCRIPT_ZH.md','因肾脏资料不可用排除的303名成人中，50名缺基线、234名缺术后、19名两者均缺，其中273名来自中心4','因肾脏资料不可用排除的303条记录中，50条缺基线、234条缺术后、19条两者均缺，其中273条来自中心4')
update(S/'ERESULTS.md','11.9%; patient-bootstrap 95% CI, 4.3%–20.4%','11.9%; Wilson 95% CI, 5.9%–22.5%; patient-bootstrap 95% CI, 4.3%–20.4%')
enadd=' After excluding one record aged younger than 18 years, 4,013 screened source records remained; the 303 renal-information exclusions included one record with unrecorded age.'
zhadd=' 排除1条年龄小于18岁的记录后，筛查来源保留4,013条记录；因肾功能资料不可用排除的303条中包含1条年龄未记录的记录。'
for name,addon in [('FIGURE_LEGENDS.md',enadd),('FIGURE_LEGENDS_ZH.md',zhadd)]:
 f=S/name;s=f.read_text();label='## eFigure 1.' if name=='FIGURE_LEGENDS.md' else '## 补图1.';nextlabel='## eFigure 2.' if name=='FIGURE_LEGENDS.md' else '## 补图2.';a,b=s.split(label,1);part,rest=b.split('\n'+nextlabel,1)
 part=part.rstrip()+(addon if addon.strip() not in part else '')+'\n\n';f.write_text(a+label+part+nextlabel+rest);changes.append(dict(file=str(f.relative_to(P)),change='Clarify screened source population'))
# Copies in the author-review comparison files are rebuilt later or updated with the exact local replacements.
for root in [P/'03_Author_review',P/'06_Graphical_abstract',P/'07_中文核对稿']:
 for f in root.glob('*'):
  if not f.is_file() or f.suffix not in ['.md','.html']:continue
  s=f.read_text();u=s.replace('11.9%; 95% CI, 4.3%–20.4%','11.9%; Wilson 95% CI, 5.9%–22.5%').replace('11.9%；95%CI，4.3%至20.4%','11.9%；Wilson 95%CI，5.9%至22.5%').replace('Among 303 adults excluded for unavailable renal information','Among 303 records excluded for unavailable renal information').replace('303名成人','303条记录')
  if u!=s:f.write_text(u)
pairs=json.loads((W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
for x in pairs:
 if x['figure']=='e1':
  x['english']+=enadd;x['chinese']+=zhadd
(W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2))
f=P/'05_Figure_assets/FIGURE_SOURCE_INDEX.json';index=json.loads(f.read_text())
for x in index:
 if x['label']=='eFigure 1':x['caption']+=enadd
f.write_text(json.dumps(index,ensure_ascii=False,indent=2))
# All active SVG representations of the flow label, preserving positions and numeric values.
svgs=[]
for f in (P/'05_Figure_assets').rglob('*.svg'):
 s=f.read_text()
 if '>Adults<' in s:
  f.write_text(s.replace('>Adults<','>Screened source<'));svgs.append(str(f.relative_to(P)))
(W/'review/TEXT_CORRECTIONS.json').write_text(json.dumps(dict(changes=changes,flow_svg_labels_changed=svgs,clinical_estimates_changed=False,model_fits=0,bootstrap_replicates=0),ensure_ascii=False,indent=2))
print(json.dumps(dict(text_changes=len(changes),svg_label_changes=len(svgs))))

