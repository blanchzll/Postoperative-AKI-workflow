from pathlib import Path
import csv,json,hashlib,collections,math,re
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';R=W.parents[1];O=R/'correction_runs/full_data_20261025_postslot/outputs';checks=[];facts={};bindings=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):return list(csv.DictReader(p.open()))
def check(name,value,expected):
 ok=value==expected;checks.append(dict(check=name,value=value,expected=expected,status='PASS' if ok else 'FAIL'));assert ok,(name,value,expected)
for cohort,n,g,e in [('preop',3710,3693,205),('paired',2428,2411,138)]:
 p=O/f'v4_development_inputs_20261018/{cohort}_metadata.csv';rr=read(p);ev=sum(int(x['y']) for x in rr);ng=len(set(x['group_hash'] for x in rr))
 check(cohort+' operation count',len(rr),n);check(cohort+' patient groups',ng,g);check(cohort+' events',ev,e)
 stages=dict(collections.Counter(x['stage'] for x in rr));facts[cohort]=dict(records=n,groups=g,events=e,stages=stages,source=str(p),sha256=sha(p))
 if cohort=='preop':check('AKI stages 1/2/3',[int(stages[str(k)]) for k in [1,2,3]],[146,30,29])
 pre=[x for x in rr if x['geography_partition_v2']=='validation'];tem=[x for x in rr if x['temporal_partition_v2']=='validation']
 if cohort=='preop':
  common=set(x['excel_row'] for x in pre)&set(x['excel_row'] for x in tem)
  check('shared evaluation records',len(common),273);check('shared evaluation groups',len({x['group_hash'] for x in rr if x['excel_row'] in common}),272)
p=R/'outputs/full_data_audit_20261025_v1/candidate_release/clinical/all_records_rrt_reconciled.csv';rr=read(p);ex=[x for x in rr if x['preop_eligible']=='False']
def positive(v):
 try:return math.isfinite(float(v)) and float(v)>0
 except:return False
z=collections.Counter((not positive(x['base']),not (positive(x['pod1']) or positive(x['pod23']))) for x in ex)
check('source after known-under18 exclusion',len(rr),4013);check('renal exclusion count',len(ex),303)
check('baseline only / postop only / both unavailable',[z[(True,False)],z[(False,True)],z[(True,True)]],[50,234,19])
check('center4 renal exclusions',sum(x['center']=='4' for x in ex),273)
check('unrecorded age among renal exclusions',sum(x['age_missing']=='True' for x in ex),1)
facts['renal_exclusions']=dict(records=303,baseline_only=50,postoperative_only=234,both=19,center4=273,unrecorded_age=1,source=str(p),sha256=sha(p))
# Arithmetic and interval-type verification without a bootstrap or model rerun.
p=C/'clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv'
rr=read(p);r=next(x for x in rr if x['population']=='all_observed_records' and x['mode']=='first_per_calendar_day')
check('lost known events',int(r['lost_known_events_lower_bound']),7);check('known event denominator',int(r['original_known_events']),59)
check('measurements removed',int(r['deleted_measurements']),522);check('measurement denominator',int(r['original_measurements']),3586)
n=59;k=7;z=1.959963984540054;ph=k/n;den=1+z*z/n;mid=(ph+z*z/(2*n))/den;half=z*math.sqrt(ph*(1-ph)/n+z*z/(4*n*n))/den
assert abs(mid-half-float(r['lost_event_Wilson_lo']))<1e-12 and abs(mid+half-float(r['lost_event_Wilson_hi']))<1e-12
facts['first_daily_SCr']=dict(numerator=k,denominator=n,percent=100*k/n,Wilson95_percent=[100*(mid-half),100*(mid+half)],patient_boot95_percent=[float(r['lost_known_fraction_lo'])*100,float(r['lost_known_fraction_hi'])*100] if 'lost_known_fraction_lo' in r else None,source=str(p),sha256=sha(p))
b=read(C/'aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv');grid=read(C/'aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv')
check('complete grid rows',len(grid),5208);check('signed boundary rows',len(b),168)
for r in b:assert abs(1000*(int(r['reference_reviews_n'])-int(r['minimum_extra_path_reviews_for_same_capture']))/int(r['n'])-float(r['signed_allowable_extra_cost_per1000']))<1e-10
d=[x for x in grid if x['comparison_id']=='geography_27v38_champ' and x['mode']=='calibrated' and x['budget_percent']=='20' and x['feasible_at_point']=='True' and float(x['delta_captured_per1000_lower95'])>0]
check('geographic positive pointwise effort grid',[round(float(x['extra_cost_per_person_review_equivalents']),2) for x in d],[0,.01,.02,.03,.04,.05])
pr=read(C/'probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv')
for x in pr:
 assert abs(sum(float(x[k]) for k in ['p_win','p_tie','p_loss','p_infeasible'])-1)<1e-12
ds=[x for x in pr if '9v27' in x['comparison']]
check('five laws times two nine-to27 contexts',len(ds),10)
check('all nine-to27 means and upper intervals negative',all(float(x['mean_delta_per1000_fallback'])<0 and float(x['mean_delta_per1000_fallback_patient_upper95'])<0 for x in ds),True)
# Exact benchmark source selections and principal units, as used by the current main text.
ll=read(C/'aggregate_data/source_data/LLM_all54_comparisons_all_metrics.csv')
for label,target in [('adaptation',[.1052,.0426,.1669]),('selected_system',[-.1233,-.1926,-.0598])]:
 rr=[x for x in ll if x['line']=='geography' and x['metric']=='AUROC' and x['comparison'].startswith('llm_llama3_8b_instruct_ngc_v1_after_endop_cal MINUS ')]
 rr=[x for x in rr if ('before_endop' in x['comparison'])==(label=='adaptation')]
 candidates=[x for x in rr if all(abs(float(x[k])-v)<.00005 for k,v in zip(['estimate','lower95','upper95'],target))]
 check('Llama '+label+' keyed estimate/interval',len(candidates),1)
 bindings.append(dict(claim='Llama '+label,row=candidates[0],source='aggregate_data/source_data/LLM_all54_comparisons_all_metrics.csv'))
for count,total,pct in [(279,759,36.8),(210,759,27.7),(465,759,61.3),(522,3586,14.6),(205,3710,5.53)]:
 assert abs(count/total*100-pct)<(.005 if pct==5.53 else .05)
facts['source_counts_and_arithmetic']='PASS'
(W/'review/DIRECT_SOURCE_FACTS.json').write_text(json.dumps(facts,ensure_ascii=False,indent=2))
(W/'review/DIRECT_SOURCE_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(W/'review/BENCHMARK_KEYED_BINDINGS.json').write_text(json.dumps(bindings,ensure_ascii=False,indent=2))
print(json.dumps(dict(status='PASS',direct_checks=len(checks),boundaries_identity_checked=len(b),new_bootstrap_replicates=0,new_fits=0)))

