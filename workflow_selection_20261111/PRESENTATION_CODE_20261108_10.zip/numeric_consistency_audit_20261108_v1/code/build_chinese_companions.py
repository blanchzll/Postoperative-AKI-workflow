from pathlib import Path
import re,json,ast,shutil,html,hashlib
from docx import Document
from docx.shared import Pt,Mm
from docx.oxml.ns import qn
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources';Z=P/'07_中文核对稿';Z.mkdir(exist_ok=True)
src=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/novelty_revision_20261101_v1/code/build_documents.py');tree=ast.parse(src.read_text());ns={}
exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),str(src),'exec'),ns)
style_doc,add_md,write=[ns[k] for k in ['style_doc','add_md','write']]
def chinese_fonts(d):
 for p in d.paragraphs:
  for r in p.runs:
   if r._element.rPr is not None:
    ff=r._element.rPr.find(qn('w:rFonts'))
    if ff is not None:ff.set(qn('w:eastAsia'),'Noto Sans CJK SC')
def make(md,path,letter=False):
 d=style_doc(letter=letter);add_md(d,md);chinese_fonts(d);write(d,path)
# Preserve every original numerical cell and translate the two editable tables.
t=(S/'MAIN_TABLES.md').read_text()
mapping={
'# Main tables':'# 两张可编辑三线表（中文核对稿）',
'## eTable 2 (editable extract). Clinical characteristics and information coverage':'## eTable 2（可编辑摘录）. 临床特征与信息覆盖',
'Characteristic':'临床特征','Main cohort':'主队列','Missing, No.':'缺失数','Paired cohort':'配对队列','Paired missing, No.':'配对队列缺失数',
'Age, y':'年龄，岁','Body mass index, kg/m²':'体重指数，kg/m²','Creatinine, mg/dL':'肌酐，mg/dL','Urea nitrogen, mg/dL':'尿素氮，mg/dL','Serum albumin, g/dL':'血清白蛋白，g/dL','Hemoglobin, g/dL':'血红蛋白，g/dL','Male sex, No. (%)':'男性，例（%）','Diabetes, No. (%)':'糖尿病，例（%）','Hypertension, No. (%)':'高血压，例（%）','Other heart disease, No. (%)':'其他心脏病，例（%）',
'## eTable 20 (editable extract). Capture and equal-capture resource margins at a 20% baseline budget':'## eTable 20（可编辑摘录）. 20%基础预算下的捕获与等捕获资源余量',
'Evaluation (N/events)':'评价（N/事件数）','Additional information':'追加信息','Captured, base → additional':'捕获数：基础 → 追加','Capture difference/1000 (95% CI)':'捕获差/1000（95%CI）','D, review equivalents/1000 (95% CI)':'D：复核当量/1000（95%CI）',
'Geographic preoperative':'地理术前','Temporal preoperative':'时间术前','Geographic paired':'地理配对','Temporal paired':'时间配对','9 → 27 inputs':'9 → 27项输入','Preoperative 27 → operation-end 38':'术前27 → 术毕38',
}
for a,b in sorted(mapping.items(),key=lambda v:-len(v[0])):t=t.replace(a,b)
parts=t.splitlines();out=[]
for line in parts:
 if line.startswith('The main cohort contains '):
  out.append('主队列为3,710条记录、205例事件，配对队列为2,428条、138例。连续值为中位数（IQR），分类比例使用非缺失分母。其他心脏病的定义类别不包括高血压。实验室汇总采用常规单位显示；转换为SI单位时，肌酐乘以88.4（μmol/L），尿素氮除以2.801（mmol/L），白蛋白和血红蛋白乘以10（g/L）。冻结模型保留原输入字典单位，原单位汇总及完整中心/分区数量见Supplement 1的eTable 2；缺失情况见eTable 10。')
 elif line.startswith('At zero additional acquisition effort'):
  out.append('追加采集负担为零时，各路径选中K=ceil(0.20N)条记录：术前比较为232和337条，配对阶段比较为232和203条。捕获差为追加路径减基础路径的每1,000条记录事件捕获数。D=1,000(K−R*)/N，R*为达到基础事件数所需的最短追加信息名单。正D表示等捕获下假设可用的采集余量，负值保留。该指标使用目标结局回顾性计算。区间为冻结系统条件下2,000次配对医院分层患者组bootstrap的逐点百分位95%区间。地理术前家族为logistic回归，时间术前为投票；阶段比较采用地理术前投票/术毕logistic回归，以及时间术前随机梯度提升/术毕投票，属于完整系统比较。地理/时间临床评价重叠273条记录、272组。未测量采集时间、任务互换性和临床获益。完整绝对操作数量、参考及网格结果见Supplement 1和随附汇总表。')
 elif line.startswith('Conditional cost-weighted'):
  out.append('这四项比较的条件性成本加权捕获及损失汇总见Supplement 1的eTable 20。')
 else:out.append(line)
t='\n'.join(out)+'\n';(S/'MAIN_TABLES_ZH.md').write_text(t)
# Fix one literal phrasing without changing the resampling count.
p=S/'FIGURE_LEGENDS_ZH.md';v=p.read_text().replace('在每个2,000次样本中重新安排采集和复核','在2,000次样本的每一次中重新安排采集和复核');p.write_text(v)
pairs=json.loads((R/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
for x in pairs:x['chinese']=x['chinese'].replace('在每个2,000次样本中重新安排采集和复核','在2,000次样本的每一次中重新安排采集和复核')
(R/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2)+'\n')
# Core Chinese editable documents.
for srcname,stem in [('MANUSCRIPT_ZH.md','正文_中文核对稿'),('FIGURE_LEGENDS_ZH.md','图注_中文核对稿'),('COVER_LETTER_ZH.md','Cover_letter_中文核对稿')]:
 text=(S/srcname).read_text();(Z/(stem+'.md')).write_text(text)
 if srcname=='MANUSCRIPT_ZH.md':
  shutil.copy2(P/'03_Author_review/MANUSCRIPT_ZH.docx',Z/(stem+'.docx'));shutil.copy2(P/'03_Author_review/MANUSCRIPT_ZH.pdf',Z/(stem+'.pdf'))
 else:make(text,Z/(stem+'.docx'),letter=srcname.startswith('COVER'))
zh=(S/'MANUSCRIPT_ZH.md').read_text();abstract='# 中文要点与摘要\n\n'+zh.split('## 要点\n',1)[1].split('## 前言\n',1)[0];(Z/'摘要与要点_中文核对稿.md').write_text(abstract);make(abstract,Z/'摘要与要点_中文核对稿.docx')
# Word table builder retains top/bottom and header rules.
import sys
sys.path.insert(0,str(R/'code'));from jno_document_format import style_table_document
d=style_doc();parts=re.split(r'(?=^## )',t,flags=re.M)[1:]
for i,part in enumerate(parts):
 if i:d.add_page_break()
 add_md(d,part,break_tables=False)
style_table_document(d);write(d,Z/'两张三线表_中文核对稿.docx');(Z/'两张三线表_中文核对稿.md').write_text(t);assert len(d.tables)==2
# Full legends and cover in paired editable sections.
bi='# 图注中英对照\n\n'+'\n\n'.join('### '+('Figure '+str(x['figure']) if isinstance(x['figure'],int) else 'eFigure '+x['figure'][1:])+'\n\n英文：\n\n'+x['english']+'\n\n中文：\n\n'+x['chinese'] for x in pairs)
make(bi,Z/'图注_中英对照.docx');(Z/'图注_中英对照.md').write_text(bi)
make('# 投稿附信中英对照\n\n## English\n\n'+(S/'COVER_LETTER.md').read_text()+'\n\n## 中文\n\n'+(S/'COVER_LETTER_ZH.md').read_text(),Z/'Cover_letter_中英对照.docx')
# A section-aligned manuscript comparison avoids guessing one-to-one paragraph correspondence.
en=(S/'MANUSCRIPT_EN.md').read_text()
aliases=[('Key Points','要点'),('Abstract','摘要'),('Introduction','前言'),('Methods','方法'),('Results','结果'),('Discussion','讨论'),('Conclusions','结论'),('Acknowledgment','致谢与声明'),('References','参考文献')]
rows=[]
for a,b in aliases:
 x=en.split('## '+a+'\n',1)[1].split('\n## ',1)[0];y=zh.split('## '+b+'\n',1)[1].split('\n## ',1)[0]
 rows.append('<section><h2>'+html.escape(a+' / '+b)+'</h2><div class="pair"><pre>'+html.escape(x)+'</pre><pre>'+html.escape(y)+'</pre></div></section>')
page='<!doctype html><html lang="zh"><meta charset="utf-8"><title>正文中英逐节对照</title><style>body{font-family:Arial,sans-serif;margin:25px;line-height:1.6}.pair{display:grid;grid-template-columns:1fr 1fr;gap:24px}pre{white-space:pre-wrap;font-family:inherit;font-size:14px;border:1px solid #ddd;padding:15px}h2{color:#374e55}@media print{section{break-before:page}}</style><h1>正文中英逐节对照</h1>'+''.join(rows)+'</html>'
(Z/'正文_中英逐节对照.html').write_text(page)
shutil.copy2(P/'06_Graphical_abstract/STUDY_FRAMEWORK_AND_CONCLUSIONS_ZH.md',Z/'研究框架与详细结论_中文.md')
(Z/'README_中英文对应清单.md').write_text("""# 中文修改与核对文件

- 正文_中文核对稿.docx：完整中文正文，包含要点、摘要、各章节及30条参考文献；对应01_Journal_files/MANUSCRIPT.docx。
- 图注_中文核对稿.docx：全部5幅主图、18幅补图的23条中文图注；对应01_Journal_files/FIGURE_LEGENDS.docx。
- Cover_letter_中文核对稿.docx：中文投稿附信；对应01_Journal_files/COVER_LETTER.docx。
- 摘要与要点_中文核对稿.docx：便于单独修改要点与摘要。
- 两张三线表_中文核对稿.docx：表题、列名、变量及表注已翻译，数值单元格与英文一致。
- 图注_中英对照.docx及Cover_letter_中英对照.docx：英文与中文按图/文档对应。
- 正文_中英逐节对照.html：浏览器中左右逐节核对；不强行将原本段落数不同的部分逐句配对。
- 04_Editable_sources/Chapters：既有中英文章节独立Word文件。
- 研究框架与详细结论_中文.md：含临床意义和基准比较的解释。

中文版本用于作者内部修改核对；01_Journal_files保留英文投稿文件。修改时可注明章节或Figure/eFigure编号，便于同步英文。作者姓名、伦理、基金等真实事实仍按原始文件核实，未自动补写未知声明。
""")
# Rebuild the English cover alone after synchronizing the actual AI-use date.
make((S/'COVER_LETTER.md').read_text().replace('# Cover letter\n','',1),P/'01_Journal_files/COVER_LETTER.docx',letter=True)
print(json.dumps({'Chinese_folder':str(Z),'Chinese_legend_count':23,'Chinese_tables':len(d.tables),'new_Chinese_Docx':len(list(Z.glob('*.docx'))),'paired_English_Chinese_sections':len(aliases)}))
