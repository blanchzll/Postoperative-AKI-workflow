from pathlib import Path
import json,hashlib,shutil,csv,datetime,difflib,zipfile,re
W=Path(__file__).resolve().parents[1];P=W/'package';B=W.parent/'references_jama_palette_20261108_v1/package';S=P/'04_Editable_sources';A=P/'03_Author_review';C=P/'02_Code_and_aggregate_data';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
# Internal draft histories remain visibly historical; regenerate comparison pages with the actual prior version.
for lang in ['EN','ZH']:
 before=(B/'04_Editable_sources'/f'MANUSCRIPT_{lang}.md').read_text();after=(S/f'MANUSCRIPT_{lang}.md').read_text()
 page=difflib.HtmlDiff(wrapcolumn=100).make_file(before.splitlines(),after.splitlines(),fromdesc='Before numerical consistency audit',todesc='Current corrected text',context=True,numlines=4)
 (A/f'MANUSCRIPT_{lang}_COMPARISON.html').write_text(page)
shutil.copy2(S/'FIGURE_LEGENDS.md',S/'Chapters/FIGURE_LEGENDS.md')
z=P/'07_中文核对稿/分章节'
for f in (S/'Chapters').glob('*_ZH.*'):
 if f.suffix in ['.md','.docx','.pdf']:shutil.copy2(f,z/f.name)
# Current figures: refresh actual file hashes and explicitly scope the flow-label update.
V=P/'05_Figure_assets/JNO_VECTOR_PAGES'
mp=V/'PAGE_AND_PANEL_MANIFEST.json';d=json.loads(mp.read_text())
def refresh(obj):
 if isinstance(obj,dict):
  for k in ['svg','pdf','png']:
   if isinstance(obj.get(k),str) and (V/obj[k]).is_file():obj[k+'_sha256']=sha(V/obj[k])
  if obj.get('figure')=='eFigure_1':
   obj['numeric_content_unchanged']=True;obj['source_population_label_corrected']=True
   if 'text_content_unchanged' in obj:obj['text_content_unchanged']=False
  for v in list(obj.values()):refresh(v)
 elif isinstance(obj,list):
  for v in obj:refresh(v)
refresh(d);d['status']='PASS_JAMA_NATIVE_VECTORS_WITH_SCREENED_SOURCE_LABEL_CORRECTION'
d['current_color_and_geometry_verification']='../../03_Author_review/Historical_before_numeric_consistency_20261108/FINAL_FIGURE_COLOR_AND_GEOMETRY_VERIFICATION.json';d['current_numeric_verification']='../../03_Author_review/Current_revision_review/FINAL_NUMERIC_CONSISTENCY_ACCEPTANCE.json';mp.write_text(json.dumps(d,ensure_ascii=False,indent=2))
fp=P/'05_Figure_assets/FIGURE_SOURCE_INDEX.json';fi=json.loads(fp.read_text())
for x in fi:
 for rel in list(x['assets']):x['assets'][rel]=sha(P/rel)
fp.write_text(json.dumps(fi,ensure_ascii=False,indent=2))
gp=P/'06_Graphical_abstract/SOURCE_BINDING.json';ga=json.loads(gp.read_text());ga['current_manuscript_sha256']=sha(S/'MANUSCRIPT_EN.md');ga['current_numeric_review']='../03_Author_review/Current_revision_review/FINAL_NUMERIC_CONSISTENCY_ACCEPTANCE.json';gp.write_text(json.dumps(ga,ensure_ascii=False,indent=2))
# Fresh review receipts bind this final revision; older acceptance pertains to its actual historical bytes.
old=A/'Current_revision_review';hist=A/'Historical_before_numeric_consistency_20261108'
assert old.exists() and not hist.exists();old.rename(hist);cur=A/'Current_revision_review';cur.mkdir()
for f in ['REFERENCE_VERIFICATION.json','REFERENCE_VERIFICATION.csv','REFERENCE_VERIFICATION_ZH.md','REFERENCE_NUMBERING_AND_COUNTS.json','SKILL_APPLICATION.json']:
 shutil.copy2(hist/f,cur/f)
report="""# 正文—图表—附件数值一致性复核

本次以 references_jama_palette_20261108_v1/package 的实际封装文件为起点，在独立修订目录完成核对；未重拟合模型、未生成新bootstrap样本、未改变研究阈值或分析集。

## 结果与修正

1. 每日首次SCr敏感性：正文原报7/59（11.9%），患者bootstrap区间4.3%–20.4%；eFigure 17和eTable 31报同一分子分母的Wilson区间5.9%–22.5%。两种区间均可追溯至同一结果CSV，但主文未说明方法且引用了Wilson图。现主文、中英文独立章节、Word/PDF及中文对照统一为“11.9%；Wilson 95%CI，5.9%–22.5%”。eResults明确并列保留患者bootstrap区间，避免把合法的不同区间当作数据变化。
2. 来源筛查层：原工作簿4,014条记录中有1条已知年龄<18岁，另1条年龄未记录。筛查来源4,013条中，303条因肾功能资料不可用排除，包含该年龄未记录者。eFigure 1中间层“Adults”改为“Screened source”；正文“303 adults”改为“303 records”，中英文图注补明对应范围。最终3,710次手术、205个事件及配对2,428/138不变。

## 实际核对范围

- 正文结果14段、258处显式数字表达已建立位置、上下文及对应表/源数据记录；参考编号、置信水平、每千人尺度和预先规定的容量等单独归类。这一数字清点用于查漏，不能单独代替按场景/模型/概率视图选取源行。
- 32张编号eTable共52个实际Word表：2,920个数值单元格或结果组合完成源值、四舍五入、上下界及明确的显示转换核对；52个Word表的全部单元格另与Markdown源逐一比较。机器标识的规范显示（如endop_full_champion_LR转为38-input LR）按已存在的排版映射核对。
- 主队列、配对队列、患者组数、事件分级、交叉评价重叠、303条排除记录、中心4排除数，重新从已冻结来源计算汇总；未输出患者级资料。
- 主表肌酐、尿素氮、白蛋白及血红蛋白的常规单位显示，依据未四舍五入描述性CSV及指定换算核对；连续值和分类值的分母保留各自定义。
- 全部5幅主图、18幅补图及图形摘要的197份PDF表示，逐份比较相对上一封装版本的数字文字与页数。192份PDF字节不变；5份eFigure 1表示仅修正流程文字，数字保留。另将Figure 2、3、5保存的130行作图源数据，按完整比较/概率视图/预算/阈值键与主CSV逐列匹配。
- 核对168个D值均满足原始列表数量公式；核对全部5,208网格行及20%预算下五种成本分布的声明。上述为读取既存输出和恒等式核验，不是重新分析。
- 既往AKI模型、Chen、TabPFN与24种LLM条件核对到对应合格子集；Llama的两组AUROC差及置信区间使用明确方向和源行。
- 最终正文Word的14段结果全部与现行源稿一致；最终正文PDF、附件PDF、中文正文PDF和Word均核对本轮更正；附件Word内31个SVG保持矢量嵌入。查看更正相关英文、中文及流程图页面，未发现溢出或遮挡。

## 合理差异的解释

总体3,710与配对2,428、不同验证分区及基准模型合格子集是不同分析集；目标20%排序与迁移源20%阈值是不同选择规则；零采集成本下额外捕获、等捕获余量D和成本分布加权均值是不同资源问题。相应人数、事件数、比较方向、单位和区间类型已对应核对，不强行统一这些有定义依据的差异。

本轮检查后，所核对的现行投稿文件未见未解决的数值矛盾。历史修订稿、旧回执和bootstrap/Wilson两种明确标注的结果继续保留溯源，不作为新的现行主文。核对没有替代正式的临床原始病历审核、伦理审批或作者签字。
"""
(cur/'NUMERIC_CONSISTENCY_REPORT_ZH.md').write_text(report)
(W/'review/VISUAL_REVIEW.json').write_text(json.dumps(dict(status='PASS_CORRECTED_RENDERED_PAGES',pages=['MANUSCRIPT.pdf p12','SUPPLEMENT_1.pdf p73','Chinese manuscript PDF p9','independent eFigure1 page1'],inspected_by='Codex',all_document_pages_visually_inspected=False),ensure_ascii=False,indent=2))
for f in (W/'review').glob('*'):
 if f.is_file() and f.suffix in ['.json','.csv'] and f.name not in ['TABLE_REVIEW_ITEMS.json']:shutil.copy2(f,cur/f.name)
# A flat, readable claim ledger accompanies the structured records.
data=json.loads((W/'review/TABLE_NUMERIC_LEDGER.json').read_text())
with (cur/'TABLE_NUMERIC_LEDGER.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(data[0]));writer.writeheader();writer.writerows(data)
# Retain the audit/revision code separately from frozen model code.
release=C/'numeric_consistency_audit_20261108_v1';(release/'code').mkdir(parents=True)
for f in (W/'code').glob('*.py'):shutil.copy2(f,release/'code'/f.name)
(release/'README_ZH.md').write_text('本目录保存2026-11-08现行投稿文件的跨载体数值核对及两项表述修正代码。冻结模型代码和分析结果保持；原始患者资料未随包提供。详见03_Author_review/Current_revision_review/NUMERIC_CONSISTENCY_REPORT_ZH.md。审计脚本读取服务器冻结来源及上一封装版本，不包含重新拟合或bootstrap计算。\\n')
with zipfile.ZipFile(P/'01_Journal_files/NUMERIC_CONSISTENCY_AUDIT_CODE.zip','w',zipfile.ZIP_DEFLATED) as zf:
 for f in sorted(release.rglob('*')):
  if f.is_file():zf.write(f,str(f.relative_to(release)))
ca=C/'CODE_AVAILABILITY.md';ca.write_text(ca.read_text()+'\\nThe 2026-11-08 cross-document numeric audit and local text/flow-label corrections are bundled separately in numeric_consistency_audit_20261108_v1 and NUMERIC_CONSISTENCY_AUDIT_CODE.zip; they have not been pushed as a new GitHub analysis release. No model fits or bootstrap replicates were changed.\\n')
idx=[dict(path=str(f.relative_to(C)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(C.rglob('*')) if f.is_file() and f!=C/'CURRENT_SOURCE_INDEX.json']
(C/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps(idx,ensure_ascii=False,indent=2))
# Current source/document hashes are generated after all changes, including the Chinese chapter copies.
files=[f for sub in ['01_Journal_files','04_Editable_sources','05_Figure_assets','06_Graphical_abstract','07_中文核对稿'] for f in (P/sub).rglob('*') if f.is_file()]
(cur/'FINAL_CURRENT_FILE_HASHES.json').write_text(json.dumps({str(f.relative_to(P)):sha(f) for f in sorted(files)},ensure_ascii=False,indent=2))
tab=json.loads((W/'review/TABLE_NUMERIC_CHECKS.json').read_text());doc=json.loads((W/'review/FINAL_DOCUMENT_NUMERIC_VERIFICATION.json').read_text());fig=json.loads((W/'review/FIGURE_DATA_AND_NUMERIC_EXPORT_CHECKS.json').read_text())
assert all(x['passed'] for x in tab) and doc['status']=='PASS' and fig['status']=='PASS'
accept=dict(status='PASS_CURRENT_MANUSCRIPT_FIGURE_TABLE_SUPPLEMENT_NUMERIC_CONSISTENCY',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_sealed_package=str(B),corrected_reporting_issues=2,unresolved_numeric_conflicts_in_checked_scope=0,table_checks=len(tab),table_ledger_entries=len(data),main_results_paragraphs=14,main_results_number_occurrences=258,numbered_eTables=32,physical_Word_tables=52,vector_PDFs=197,figure_source_rows=130,main_words=2931,new_predictive_fits=0,new_bootstrap_replicates=0,clinical_estimates_changed=False,review_report='NUMERIC_CONSISTENCY_REPORT_ZH.md',documents_sha256={str(f.relative_to(P)):sha(f) for f in (P/'01_Journal_files').glob('*.docx')},author_real_declarations_confirmed=False,formal_submission=False)
(cur/'FINAL_NUMERIC_CONSISTENCY_ACCEPTANCE.json').write_text(json.dumps(accept,ensure_ascii=False,indent=2))
for name in ['FINAL_REVISION_ACCEPTANCE.json','REVISION_STATUS.json']:
 old=P/name
 if old.exists():shutil.copy2(old,hist/name)
 old.write_text(json.dumps(accept,ensure_ascii=False,indent=2))
(P/'README_ZH.md').write_text('# 当前投稿文件包：数值一致性核对版\\n\\n英文投稿文件见01_Journal_files；中文可编辑稿及中英对照见07_中文核对稿。\\n\\n已核对正文、图表、图注、补充材料及对应冻结输出，并修正SCr敏感性置信区间标注和来源筛查层标签两项表述问题。当前正文2931词。完整记录见03_Author_review/Current_revision_review/NUMERIC_CONSISTENCY_REPORT_ZH.md。\\n\\n临床分析数字、模型、阈值、患者组及bootstrap结果保持；旧回执明确归档于Historical目录。两种统计区间在支持结果中明确区分。作者真实声明仍按实际文件核准，未执行正式投稿。\\n')
manifest=dict(status='SEALED_NUMERIC_CONSISTENCY_CHECKED_BILINGUAL_PACKAGE',created_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),manifest_excludes_itself=True,files=[dict(path=str(f.relative_to(P)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(P.rglob('*')) if f.is_file() and f!=P/'CONTENTS_MANIFEST.json'])
(P/'CONTENTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
out=W/'delivery';out.mkdir(exist_ok=True);name='AKI_JNO_20261108_NUMERIC_CHECKED_FINAL';zp=out/(name+'.zip')
assert not zp.exists()
with zipfile.ZipFile(zp,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as zf:
 for f in sorted(P.rglob('*')):
  if f.is_file():zf.write(f,name+'/'+str(f.relative_to(P)))
with zipfile.ZipFile(zp) as zf:assert zf.testzip() is None
receipt=dict(status='SEALED_PENDING_SSD_VERIFICATION',folder_name=name,zip=str(zp),zip_bytes=zp.stat().st_size,zip_sha256=sha(zp),manifest_sha256=sha(P/'CONTENTS_MANIFEST.json'),file_count=len(manifest['files'])+1)
(out/'BUILD_RECEIPT.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))

