from pathlib import Path
import json,re,csv,math,collections
from decimal import Decimal
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';S=P/'04_Editable_sources'
text=(S/'MANUSCRIPT_EN.md').read_text()
parts=[x for x in text.split('## Results')[1].split('## Discussion')[0].split('\n\n') if x.strip() and not x.strip().startswith('#')]
ts={int(m[1]):m[2] for m in re.finditer(r'^## eTable (\d+)\.(.*?)(?=^## eTable |\Z)',(S/'ETABLES.md').read_text(),re.M|re.S)}
num_pattern=r'(?<![A-Za-z_])[-−]?\d[\d,]*(?:\.\d+)?'
def nt(s):
 s=s.replace('–',' ').replace('−','-')
 return re.findall(num_pattern,s)
def equal(s,v):
 try:
  d=Decimal(s.replace(',',''));z=Decimal(str(v))
  if not z.is_finite():return False
  return abs(d-z)<=Decimal(10)**d.as_tuple().exponent/2+Decimal('0.00000000001')
 except:return False
maptabs={0:[2],1:[2,10],2:[3,5,20],3:[4,20],4:[20],5:[20,21],6:[20],7:[5,11,12],8:[6,7],9:[24],10:[24],11:[22,23,32],12:[8,9],13:[25,31]}
extras={
0:['clinical_supplement_20261108_v1/results/COHORT_OPERATION_PATIENT_COUNTS.csv','aggregate_data/source_data/F1_centres.csv'],
3:['aggregate_data/supplement/aggregate_tables/supplement_tables/S5_overlap/process_resolution_20261025_v1/NONOVERLAP_SUPPORT.csv'],
6:['probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv'],
8:['aggregate_data/tables/Table_S16_NINE_SOURCE_THRESHOLD_BURDEN.csv','aggregate_data/source_data/Coded9_SOURCE_THRESHOLD_COVERAGE.csv','aggregate_data/source_data/Coded9_PUBLIC9_REVIEWED_SUMMARY.csv'],
11:['aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv'],
12:['aggregate_data/source_data/LLM_all54_comparisons_all_metrics.csv'],
13:['clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv']
}
ledger=[];unmatched=[]
for i,para in enumerate(parts):
 pool=[('95','declared confidence level','protocol'),('1000','reported per1000 scale','unit definition')]
 if i==0:
  facts=json.loads((W/'review/DIRECT_SOURCE_FACTS.json').read_text())
  for coh in ['preop','paired']:
   for key in ['records','groups','events']:pool.append((str(facts[coh][key]),facts[coh]['source'],key))
  for key,v in facts['preop']['stages'].items():pool.append((str(v),facts['preop']['source'],'stage '+key))
  pool.append((str(205/3710*100),facts['preop']['source'],'event percentage'))
 for n in maptabs[i]:
  for l in ts[n].splitlines():
   if l.startswith('|') or n==24:
    for v in nt(l):pool.append((v.replace(',',''),f'eTable {n}',l[:240]))
 for f in extras.get(i,[]):
  rr=list(csv.DictReader((C/f).open()))
  for ri,r in enumerate(rr,2):
   if i==12 and (r.get('metric')!='AUROC' or r.get('line')!='geography' or 'endop' not in r.get('comparison','')):continue
   for k,v in r.items():
    try:
     z=float(v)
     if math.isfinite(z):
      pool.append((v,f+':'+str(ri)+':'+k,str({q:r[q] for q in r if q in ['comparison','line','model','mode','context']})))
      if any(t in k.lower() for t in ['fraction','rate','p_win','lo','hi']):pool.append((str(z*100),f+':'+str(ri)+':'+k+' ×100','percentage conversion'))
    except (ValueError,TypeError):pass
 special={0:[95],1:[303,50,234,19,273,35.5,34.6,53.0],4:[5208,168,20],5:[0,.05,.01,20,95],6:[0,20,95,.30],7:[10,20],9:[61.3],11:[36.8,27.7,80],12:[24],13:[14.6,95]}
 for v in special.get(i,[]):pool.append((str(v),'DIRECT_SOURCE_CHECKS_OR_PROTOCOL_CONSTANT','checked in DIRECT_SOURCE_CHECKS.json or declared protocol/scale'))
 clean=re.sub(r'\be?(?:Table|Figure)s?\s+[\d\s,and–−-]+','',para)
 # confidence level and definition constants are classified, not claimed as a result estimate
 for m in re.finditer(num_pattern,clean.replace('–',' ').replace('−','-')):
  s=m[0];matches=[r for r in pool if equal(s,r[0])]
  rec=dict(paragraph=i+1,number=s,context=clean[max(0,m.start()-65):m.end()+65],status='MATCH' if matches else 'REVIEW',sources=[dict(value=x[0],source=x[1],row_context=x[2]) for x in matches[:5]])
  ledger.append(rec)
  if not matches:unmatched.append(rec)
(W/'review/MAIN_RESULT_NUMBER_INVENTORY.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
(W/'review/MAIN_RESULT_NUMBER_UNMATCHED.json').write_text(json.dumps(unmatched,ensure_ascii=False,indent=2))
print(json.dumps(dict(paragraphs=len(parts),number_occurrences=len(ledger),matched=len(ledger)-len(unmatched),unmatched=len(unmatched))))
print(json.dumps(unmatched,ensure_ascii=False,indent=2))

