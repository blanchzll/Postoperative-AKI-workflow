# Additional direct row-key checks, including new resource / public tables.
import runpy
d=runpy.run_path(str(__file__).replace('audit_additional_tables.py','audit_tables.py'));globals().update({k:v for k,v in d.items() if not k.startswith('__')})
def rows(path):return list(csv.DictReader((C/path).open()))
def one(rr,**kw):
 z=[r for r in rr if all(str(r[k])==str(v) for k,v in kw.items())];assert len(z)==1,(kw,len(z));return z[0]
def cell(loc,current,values,source):
 val=' / '.join(map(str,values)) if isinstance(values,(list,tuple)) else str(values)
 ok=numeric_equal(current,val);check(loc,ok,None if ok else dict(current=current,source=val))
 ledger.append(dict(location=loc,current=current,source_value=val,source=source,status='PASS' if ok else 'REVIEW'))
ts=sections((S/'ETABLES.md').read_text())
primary=rows('aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv')
bounds=rows('aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv')
primary=sorted(primary,key=lambda r:['geography_9v27_champ','temporal_9v27_champ','geography_27v38_champ','temporal_27v38_champ'].index(r['comparison_id']))
for ar,r in zip(tables(ts[20])[0][1:],primary):
 b=one(bounds,comparison_id=r['comparison_id'],mode='calibrated',budget_percent='20')
 cell('eTable20 primary '+r['comparison_id'], ' | '.join(ar[2:]),[r['base_captured_n'],r['extra_captured_n'],r['delta_captured_per1000'],r['delta_captured_per1000_lower95'],r['delta_captured_per1000_upper95'],b['signed_allowable_extra_cost_per1000'],b['lower95'],b['upper95']],'PRIMARY_EQUAL_CAPACITY20.csv + BREAK_EVEN_BOUNDARIES.csv')
for ar in tables(ts[20])[1][1:]:
 r=one(bounds,comparison_id=ar[0].replace(' ','_'),mode='calibrated',budget_percent='20')
 cell('eTable20 boundary '+r['comparison_id'],' | '.join(ar[1:]),[r['n'],r['events'],r['reference_captured_n'],r['minimum_extra_path_reviews_for_same_capture'],r['signed_allowable_extra_cost_per1000'],r['lower95'],r['upper95']],'BREAK_EVEN_BOUNDARIES.csv')
probs=rows('probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv')
for ar in tables(ts[20])[2][1:]:
 a=ar[0];comp=('geography' if a.startswith('Geographic') else 'temporal')+('_9v27_champ' if '9→27' in a else '_27v38_champ')
 law='ratio_uniform_030' if 'Uniform' in a else 'ratio_beta_low_030' if '(2,5)' in a else 'ratio_beta_high_030'
 cand=[x for x in probs if x['comparison']==comp and (x['distribution']==law or (('low' in x['distribution']) and '(2,5)' in a) or (('high' in x['distribution']) and '(5,2)' in a))]
 assert len(cand)==1,(a,law,[x['distribution'] for x in probs]);r=cand[0]
 v=[float(r[k])*100 for k in ['p_win','p_tie','p_loss','p_infeasible']]
 v+=[r[k] for k in ['mean_delta_per1000_fallback','mean_delta_per1000_fallback_patient_lower95','mean_delta_per1000_fallback_patient_upper95']]
 v+=[float(r[k])*100 for k in ['p_win_patient_lower95','p_win_patient_upper95']]
 v+=[r[k] for k in ['expected_regret_base_per1000','expected_regret_extra_fallback_per1000']]
 cell('eTable20 probability '+a,' | '.join(ar[1:]),v,'PRIMARY_20_PERCENT_SUMMARY.csv; proportions multiplied by 100')
grid=rows('aggregate_data/novelty_extension/tables/COMPLETE_GRID_REGION_SUMMARY.csv')
keys=['extra_workflow_positive_pointwise_interval','baseline_workflow_positive_pointwise_interval','interval_includes_zero','infeasible_at_observed_population']
for i,ar in enumerate(tables(ts[21])[0][1:],1):
 comp=ar[0].replace(' ','_');rr=[x for x in grid if x['comparison_id']==comp and x['mode']=='calibrated' and x['budget_percent']==ar[1]]
 vals=[]
 for k in keys:
  zz=[x for x in rr if x['region']==k]
  if not zz:raise ValueError((k,[x['region'] for x in rr]))
  vals.append(zz[0]['grid_cells'])
 cell(f'eTable21 row{i}',' | '.join(ar[2:]),vals,'COMPLETE_GRID_REGION_SUMMARY.csv')
mint=rows('aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv')
mp=rows('aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv')
for ar in tables(ts[22])[0][1:]:
 model=ar[0].replace(' / ','__');v=[]
 for metric in ['AUROC','Brier','calibration_slope']:
  r=one(mint,model=model,metric=metric);v.extend(r[k] for k in ['estimate','lower95','upper95'])
 r=one(mp,model=model);v += [r['capacity20_captured_n'],r['events']]
 cell('eTable22 '+model,' | '.join(ar[1:]),v,'MIMIC INTERVALS.csv + POINT_ESTIMATES.csv')
cuts=rows('aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv')
for ar in tables(ts[23])[0][1:]:
 v=[]
 rr=[x for x in cuts if x['source_line']==ar[0] and x['rule']=='training_'+ar[1]]
 v.append(rr[0]['threshold'])
 for metric in ['reviewed_n','captured_n','sensitivity']:
  r=one(rr,metric=metric);v.extend(r[k] for k in ['estimate','lower95','upper95'])
 cell('eTable23 '+ar[0]+' '+ar[1],' | '.join(ar[2:]),v,'MIMIC SOURCE_THRESHOLD_BURDEN.csv')
inv=rows('aggregate_data/novelty_extension/mimic_calendar_v2/INVERSE_COVERAGE.csv')
for ar in tables(ts[24])[1][1:]:
 r=one(inv,model=ar[0].replace(' / ','__'),sensitivity_target=ar[1])
 cell('eTable24 inverse '+r['model']+ar[1],ar[2],[r[k] for k in ['required_reviews_per1000','lower95','upper95']],'MIMIC INVERSE_COVERAGE.csv')
# Age-stratified rows bind to their exact model/profile and paired difference.
age=rows('measurement_consistency_20261104_v1/aggregates/WRITING_ELIGIBLE_AGGREGATES.csv')
for ar in tables(ts[22])[1][1:]:
 model=ar[0]+'__calibrated';band='under65' if ar[1]=='<65' else '65plus'
 r=one(age,model=model,profile='age_band65__'+band,metric='AUROC')
 v=[r[k] for k in ['n','events','estimate','lower95','upper95']]
 if band=='65plus':
  dr=one(age,model=model,metric='AUROC_difference');v += [dr[k] for k in ['estimate','lower95','upper95']]
 cell('eTable22 age '+model+band,' | '.join(ar[2:]),v,'WRITING_ELIGIBLE_AGGREGATES.csv')
# Conventional-unit display is checked against full-precision descriptive CSV, not rounded SI values.
base=rows('aggregate_data/source_data/Baseline_observed_characteristics.csv')
at=tables(ts[2])[0][1:]
varmap=[('Age',1),('BMI',1),('PreopCr',1/88.4),('PreopBUN',2.801),('PreopAlb',.1),('PreopHb',.1),('Sex',1),('Diabetes',1),('Hypertension',1),('HeartDisease',1)]
for ar,(variable,factor) in zip(at,varmap):
 for cohort,ci,mi in [('preoperative',1,2),('paired',3,4)]:
  r=one(base,cohort=cohort,variable=variable)
  v=[float(r[k])*factor for k in ['median','q1','q3']] if r['median'] else [r['count'],r['percent_observed']]
  cell('eTable2 unit '+variable+' '+cohort,ar[ci],v,'Baseline_observed_characteristics.csv; declared conventional-unit factor '+str(factor))
  cell('eTable2 missing '+variable+' '+cohort,ar[mi],r['missing'],'Baseline_observed_characteristics.csv')
(W/'review/TABLE_NUMERIC_CHECKS.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(W/'review/TABLE_NUMERIC_LEDGER.json').write_text(json.dumps(ledger,ensure_ascii=False,indent=2))
(W/'review/TABLE_REVIEW_ITEMS.json').write_text(json.dumps(issues,ensure_ascii=False,indent=2))
print(json.dumps(dict(checks=len(checks),cell_ledger=len(ledger),issues=len(issues)),ensure_ascii=False))
print(json.dumps(issues[:20],ensure_ascii=False))

