from pathlib import Path
import json,csv,hashlib,math,re,collections
import pymupdf as fitz
from PIL import Image
W=Path(__file__).resolve().parents[1];P=W/'package';B=W.parent/'references_jama_palette_20261108_v1/package';C=P/'02_Code_and_aggregate_data';checks=[];records=[]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(name,ok,details=None):
 checks.append(dict(check=name,status='PASS' if ok else 'FAIL',details=details));assert ok,(name,details)
def numbers(s):return re.findall(r'[-−]?\d+(?:[.,]\d+)*',s)
def read(p):return list(csv.DictReader(p.open()))
pdfs=list((P/'05_Figure_assets').rglob('*.pdf'))+list((P/'06_Graphical_abstract').glob('*.pdf'))
for path in pdfs:
 old=B/path.relative_to(P);a=fitz.open(path);b=fitz.open(old)
 aa='\n'.join(x.get_text() for x in a);bb='\n'.join(x.get_text() for x in b)
 ck('numeric content '+str(path.relative_to(P)),collections.Counter(numbers(aa))==collections.Counter(numbers(bb)))
 ck('page count '+str(path.relative_to(P)),len(a)==len(b))
 if sha(path)!=sha(old):ck('only intended flow label changes '+str(path.relative_to(P)),'eFigure_1' in str(path) and 'Adults' not in aa and 'Screened source' in aa.replace('\xa0',' '))
 records.append(dict(file=str(path.relative_to(P)),pages=len(a),number_tokens=len(numbers(aa)),numeric_text_matches_parent=True,byte_unchanged=sha(path)==sha(old)))
 a.close();b.close()
ck('197 active vector PDFs',len(pdfs)==197,len(pdfs))
# Check the published figure source subsets against their full aggregate tables.
sources={
'Figure_2/N1_equal_budget_capture_SOURCE_DATA.csv':C/'aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv',
'Figure_3/N2_signed_equal_capture_boundary_SOURCE_DATA.csv':C/'aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv'}
source_rows=0;source_cells=0
for rel,source in sources.items():
 rr=read(P/'05_Figure_assets'/rel);master=read(source)
 for i,r in enumerate(rr,1):
  key=[k for k in ['comparison_id','mode','budget_percent','extra_cost_per_person_review_equivalents'] if k in r]
  matches=[x for x in master if all(x[k]==r[k] for k in key)];ck(rel+f' row{i} exact context key',len(matches)==1)
  x=matches[0]
  for k,v in r.items():
   if v==x[k]:continue
   try:ok=math.isclose(float(v),float(x[k]),rel_tol=1e-12,abs_tol=1e-12) or (not v and not x[k])
   except:ok=False
   ck(rel+f' row{i} column{k}',ok,[v,x[k]] if not ok else None)
   source_cells+=1
  source_rows+=1
rr=read(P/'05_Figure_assets/Figure_5/N3_MIMIC_calendar_transport_SOURCE_DATA.csv')
mi=read(C/'aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv');cuts=read(C/'aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv')
for i,r in enumerate(rr,1):
 keys=['model','metric'] if r['model'] else ['source_line','rule','metric'];master=mi if r['model'] else cuts
 candidates=[x for x in master if all(r[k]==x[k] for k in keys)];ck('Figure5 exact context row '+str(i),len(candidates)==1)
 x=candidates[0]
 for k,v in r.items():
  if not v:continue
  if v==x[k]:continue
  ck('Figure5 row'+str(i)+' '+k,math.isclose(float(v),float(x[k]),rel_tol=1e-12,abs_tol=1e-12))
 source_rows+=1
# Frozen original aggregate and code files: presentation copies are considered separately.
same=0
for old in (B/'02_Code_and_aggregate_data').rglob('*'):
 if not old.is_file():continue
 new=P/old.relative_to(B)
 ck('frozen code/aggregate '+str(old.relative_to(B)),new.exists() and sha(old)==sha(new))
 same+=1
# Inspect pages affected by the actual corrections, at rendered journal size.
previews=[];requested=[P/'01_Journal_files/MANUSCRIPT.pdf',P/'01_Journal_files/SUPPLEMENT_1.pdf',P/'07_中文核对稿/正文_中文核对稿.pdf']
for file in requested:
 d=fitz.open(file);sel=[]
 for i,page in enumerate(d):
  text=page.get_text().replace('\xa0',' ')
  if ('Wilson' in text and ('22.5' in text or '5.9%' in text)) or ('Screened source' in text):sel.append(i)
 for i in sel[:2]:
  out=W/'review'/(('MAIN' if file.name=='MANUSCRIPT.pdf' else 'SUPP' if file.name=='SUPPLEMENT_1.pdf' else 'ZH')+f'_CHECK_PAGE_{i+1}.png')
  d[i].get_pixmap(matrix=fitz.Matrix(1.25,1.25)).save(out);previews.append(dict(document=str(file.relative_to(P)),page=i+1,preview=str(out)))
 d.close()
(W/'review/FIGURE_DATA_AND_NUMERIC_EXPORT_CHECKS.json').write_text(json.dumps(dict(status='PASS',checks=checks,figures=records,figure_source_rows_verified=source_rows,frozen_code_and_aggregate_files_unchanged=same,byte_identical_vector_PDFs=sum(x['byte_unchanged'] for x in records),visual_pages=previews),ensure_ascii=False,indent=2))
print(json.dumps(dict(status='PASS',vector_PDFs=len(pdfs),figure_source_rows_verified=source_rows,frozen_files=same,previews=previews),ensure_ascii=False))

