from pathlib import Path
import json,hashlib,shutil,zipfile,datetime
W=Path(__file__).resolve().parents[1];P=W/'package';B=W.parent/'figure_redesign_20261109_v1/package';C=P/'02_Code_and_aggregate_data';A=P/'03_Author_review'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
build=json.loads((W/'review/DOCUMENT_BUILD.json').read_text());numbers=json.loads((W/'review/COMPOSITE_NUMERIC_VERIFICATION.json').read_text());visual=json.loads((W/'review/FINAL_VISUAL_AND_PDF_QUALIFICATION.json').read_text())
assert build['main_body_words']<=3000 and build['main_figures']==5 and build['main_tables']==0
assert numbers['keyed_numeric_bindings']==104 and numbers['frozen_files']==825
assert json.loads((W/'review/FINAL_DOCUMENT_NUMERIC_VERIFICATION.json').read_text())['status']=='PASS'
assert json.loads((W/'review/CHINESE_COMPANIONS_VERIFICATION.json').read_text())['legends']==29
track=json.loads((W/'review/TRACK_CHANGES_VERIFICATION.json').read_text())
assert 'figure_redesign_20261109_v1' in track['baseline'] and track['accept_replays_current_clean'] and track['reject_replays_immediate_parent']
old=A/'Historical_before_composite_main_20261109_v2'
if not old.exists():shutil.move(str(A/'Current_revision_review'),old)
R=A/'Current_revision_review';R.mkdir(exist_ok=True)
for f in W.joinpath('review').glob('*.json'):shutil.copy2(f,R/f.name)
for n in ['REFERENCE_VERIFICATION.csv','REFERENCE_VERIFICATION.json','REFERENCE_VERIFICATION_ZH.md','REFERENCE_NUMBERING_AND_COUNTS.json']:
 if (old/n).exists():shutil.copy2(old/n,R/n)
for n in ['FINAL_REVISION_ACCEPTANCE.json','REVISION_STATUS.json','CONTENTS_MANIFEST.json']:
 if not (old/('ROOT_'+n)).exists():shutil.copy2(P/n,old/('ROOT_'+n))
for f in (P/'04_Editable_sources/Chapters').glob('*_ZH.*'):
 if f.suffix in ['.md','.docx','.pdf']:shutil.copy2(f,P/'07_中文核对稿/分章节'/f.name)
release=C/'composite_main_figures_20261109_v2';release.mkdir(exist_ok=True)
for f in (W/'code').glob('*.py'):shutil.copy2(f,release/f.name)
shutil.copytree(W/'references',release/'SFL_reference_records',dirs_exist_ok=True)
for n in ['COMPOSITE_MAIN_FIGURES.json','COMPOSITE_NUMERIC_VERIFICATION.json','FINAL_VISUAL_AND_PDF_QUALIFICATION.json']:
 shutil.copy2(W/'review'/n,release/n)
(release/'README_ZH.md').write_text("""# 五幅复合主图（20261109 v2）

本次只重排冻结结果，没有训练或重抽样。完整原研究代码保留于相邻analysis_sources及原ANALYSIS_CODE.zip。当前主图代码为draw_composite_main.py；integrate_composites.py同步主图及中英图注；align_supplement_captions.py将补图12/13的原有图注对应与实际图像对齐；audit_composite_numbers.py核对104条有键数值/区间和825个冻结文件。qualify_composites.py核对实际PDF字体和文档图注身份，并建立五幅主图预览。其余脚本用于文档和修订稿。

实际执行根：/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/composite_main_figures_20261109_v2/。code/保存脚本，package/为本包内容，fonts/需自行提供授权Arial字体，本包不分发字体。图形解释器沿用项目已登记prediction_gpu环境；文档沿用document-rebuild-20261011；PDF检查沿用upar-structure-docking-py312-cpu-20261104-v1。环境和旧纯文本辅助函数的绝对路径在代码中明示，不声称脱离该服务器的一键独立安装。

重现顺序：draw_composite_main.py → integrate_composites.py → align_supplement_captions.py → 文档构建/渲染 → audit_composite_numbers.py / audit_final_documents.py / qualify_composites.py。不要对封存包直接重放；新建工作副本。AKI_EXPORT_ONLY用于仅输出选定主图的排版修复，默认输出五幅。原统计种子、方法及阈值未改变。

SFL参考仅用于固定行序、带数值注释矩阵的表达原则，保留固定提交及实际预览元数据。未执行其基因/连线模板，也未导入任何模拟数据。所有新图使用Python/Matplotlib，统计数据由冻结CSV提供。
""")
archive=P/'01_Journal_files/COMPOSITE_MAIN_FIGURE_CODE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(release.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(C)))
assert sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip')
p=C/'CODE_AVAILABILITY.md';s=p.read_text()
s+='\n\n## 20261109 composite main figures v2\nThe active five-main-figure presentation code is in composite_main_figures_20261109_v2/ and COMPOSITE_MAIN_FIGURE_CODE.zip. Statistical results and the original analysis archive are unchanged. This presentation revision is supplied locally and has not been pushed to GitHub.\n'
p.write_text(s)
report=f"""# 五幅主图复合重设计与文件核对

本轮响应Figure1/5信息量不足，以及Figure2/3/4需一并增强的要求。五幅主图全部更新，均为四个数据面板。期刊排版沿用JAMA Network Open，临床胃肠肿瘤手术AKI队列定位保持。

|主图|当前完整问题与四个面板|
|---|---|
|Figure1|临床队列及信息时点；AUROC–Brier二维表现及边际区间；容量–覆盖经验曲线；20%容量的绝对事件数与配对增益。|
|Figure2|四项主比较的同预算资源网格；同尺度颜色、关键精确数值及逐点区间标记、不可行区域、20%等捕获采集余量。|
|Figure3|地理/时间及同家族比较的D与区间；等捕获的实际名单长度；五种成本分布下的平均捕获差与完整区间。|
|Figure4|INSPIRE已发布病史匹配；完整流程AUROC/AP/Brier配对差异；容量–覆盖曲线；源阈值迁移后的名单负担与覆盖操作点。|
|Figure5|MIMIC纳入计数及观测输入；原始/校准概率误差与参照；三种阈值规则的负担–覆盖；观测检验删减后的已知事件损失。|

五幅主图均保留PDF/SVG/300dpi PNG/600dpi TIFF和独立面板；实际PDF字体为Arial，最小7号，文字未越出图页。数值格为矢量多边形，颜色条渐变可能按出版后端嵌入；没有把完整图栅格化。矩阵文字按背景亮度选择深浅，深色正负点和原区间保持。每个面板服务于一个科学问题，未把多个无关小图塞成未标号子面板。已逐幅查看最终图。

104条关键数值/区间按模型、比较、指标、成本分布及阈值规则逐键核对；18个CSV提供数值来源。825个冻结文件逐字节保持，正文结果数字在去除图号后保持，未新增拟合或bootstrap。容量曲线主图展示0–50%范围；完整曲线及不利结果在补图保留。52个物理Word表对应32个编号eTables，91项文档检查通过；29条中英图注数值对应。正文{build['main_body_words']}词，正文5图0表，两张三线表仍在附件。

修正了继承包中补图12/13图注互指的问题：补图12实际为假设性临床使用情景，补图13实际为校准。已同步中英文图注、eResults引用、图源索引和最终Word/PDF；补图数据文件未改变。新修订稿的接受/拒绝回放分别对应当前正文及本轮直接封存父版本。

实际使用phd-skills写作一致性模块、figure-library检索与精确预览，以及academic-plotting的数值图原则；JNO规范和用户的最多四面板规则优先。SFL固定提交为17c15eb65ed1629a4a36626cf1b5d1030cb54d67，仅借鉴矩阵注释逻辑；没有移植基因/网络数据或运行模板模拟代码。源代码与查询元数据一并提供。

本轮提高的是已有证据的组织与可读性，不把图形复杂度当作新科学贡献。作者/伦理/基金等真实声明仍待作者核实，未正式投稿。新图形代码随包提供，未另推送GitHub。
"""
(R/'COMPOSITE_FIGURE_REVISION_ZH.md').write_text(report)
(P/'README_ZH.md').write_text(f"""# 当前投稿包：五幅复合主图（20261109 v2）

先查看00_MAIN_FIGURES_PREVIEW.pdf，可按目录逐幅浏览全部新版主图。Figure1–5均重新设计，每幅最多4面板；正文{build['main_body_words']}词，正文图表合计5项。两张三线表位于附件。补充材料保留32个编号eTables及24幅补图；补图保持Arial10号原尺寸排版。正文、29条图注、附信及中文修改稿已同步。

英文投稿文件：01_Journal_files。中文核对：07_中文核对稿。PDF/SVG/PNG/TIFF：05_Figure_assets。完整原代码和新复合图代码：02_Code_and_aggregate_data。当前修改与核对：03_Author_review/Current_revision_review/COMPOSITE_FIGURE_REVISION_ZH.md。历史图与回执明确归档；旧封存包未覆盖。

104条关键数值绑定、825个冻结来源文件及91项文档检查通过。源统计结果未改；补图12/13的原有图注对应已修正。作者真实声明待确认，未正式投稿。
""")
accept=dict(status='PASS_COMPOSITE_MAIN_FIGURE_REVISION_AND_DOCUMENT_CONSISTENCY',verified_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent_package=str(B),main_words=build['main_body_words'],main_figures=5,main_tables=0,main_panels=20,maximum_panels_per_figure=4,supplement_figures=24,supplement_vector_pages=37,bilingual_legends=29,numbered_eTables=32,physical_Word_tables=52,keyed_numeric_bindings=104,frozen_files_preserved=825,new_fits=0,new_bootstrap=0,document_checks=91,caption_alignment_correction=[12,13],author_declarations_confirmed=False,formal_submission=False,report='03_Author_review/Current_revision_review/COMPOSITE_FIGURE_REVISION_ZH.md',current_files={str(f.relative_to(P)):sha(f) for f in (P/'01_Journal_files').glob('*') if f.is_file()})
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(accept,indent=2))
(P/'REVISION_STATUS.json').write_text(json.dumps(dict(status=accept['status'],formal_submission=False,author_review_required=True,preview='00_MAIN_FIGURES_PREVIEW.pdf'),indent=2))
(C/'CURRENT_SOURCE_INDEX.json').write_text(json.dumps([dict(path=str(f.relative_to(C)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(C.rglob('*')) if f.is_file() and f!=C/'CURRENT_SOURCE_INDEX.json'],indent=2))
manifest=[dict(path=str(f.relative_to(P)),bytes=f.stat().st_size,sha256=sha(f)) for f in sorted(P.rglob('*')) if f.is_file() and f!=P/'CONTENTS_MANIFEST.json']
(P/'CONTENTS_MANIFEST.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
for r in manifest:assert sha(P/r['path'])==r['sha256']
rec=dict(status='SEALED_VERIFIED',files=len(manifest)+1,manifest_sha256=sha(P/'CONTENTS_MANIFEST.json'),package=str(P),bytes=sum(r['bytes'] for r in manifest))
(W/'SEALED_PACKAGE.json').write_text(json.dumps(rec,indent=2))
print(json.dumps(rec))

