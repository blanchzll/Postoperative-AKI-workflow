from pathlib import Path
import re,json
W=Path(__file__).resolve().parents[1];S=W/'package/04_Editable_sources'
for lang in ['EN','ZH']:
 p=S/('FIGURE_LEGENDS.md' if lang=='EN' else 'FIGURE_LEGENDS_ZH.md');s=p.read_text();lead='eFigure ' if lang=='EN' else '补图'
 pat=lambda n:r'^## '+re.escape(lead)+str(n)+r'\..*?(?=^## |\Z)'
 a=re.search(pat(12),s,re.M|re.S).group(0);b=re.search(pat(13),s,re.M|re.S).group(0)
 if ('Calibration of the ten' in a) or ('十条主要路径的校准' in a):
  a2=a.replace(lead+'12.',lead+'13.',1);b2=b.replace(lead+'13.',lead+'12.',1)
  s=s.replace(a,'__CAPTION_SWAP_12__').replace(b,'__CAPTION_SWAP_13__').replace('__CAPTION_SWAP_12__',b2).replace('__CAPTION_SWAP_13__',a2);p.write_text(s)
p=W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json';pairs=json.loads(p.read_text());r12=next(x for x in pairs if x['figure']=='e12');r13=next(x for x in pairs if x['figure']=='e13')
if 'ten frozen score bins' in r12['english']:
 for key in ['english','chinese']:r12[key],r13[key]=r13[key],r12[key]
p.write_text(json.dumps(pairs,ensure_ascii=False,indent=2))
p=S/'ERESULTS.md';s=p.read_text()
s=s.replace('Main Figure 1 and eFigure 12 present the compact model alongside the full comparison.','Main Figure 1 and eFigure 13 present the compact model alongside the full comparison.')
s=s.replace('Representative nine-input scenarios use 10%/20% capacity in each line (eFigure 13).','Representative nine-input scenarios use 10%/20% capacity in each line (eFigure 12).')
s=s.replace('These preoperative-use scenarios are displayed in eFigure 13.','These preoperative-use scenarios are displayed in eFigure 12.')
p.write_text(s)
index=W/'package/05_Figure_assets/FIGURE_SOURCE_INDEX.json';data=json.loads(index.read_text())
for n in [12,13]:
 m=re.search(r'^## (eFigure '+str(n)+r')\.(.*?)(?=^## |\Z)',(S/'FIGURE_LEGENDS.md').read_text(),re.M|re.S);part=m.group(2).strip().split('\n',1)
 row=next(x for x in data if x['label']==f'eFigure {n}');row['title']=f'eFigure {n}. '+part[0];row['caption']=part[1].strip()
index.write_text(json.dumps(data,indent=2));(S/'Chapters/FIGURE_LEGENDS.md').write_text((S/'FIGURE_LEGENDS.md').read_text())
print('ALL_CAPTION_AND_REFERENCE_IDENTITIES_ALIGNED')

