from pathlib import Path
import re,json,hashlib,shutil
from xml.etree import ElementTree as ET
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';F=P/'05_Figure_assets'
EN=[
("Clinical information availability, performance, and event coverage","A, Cohort size, preoperative information requirements and operation-end information availability. The main cohort contains 3,710 operations from 3,693 patient groups with 205 recorded AKI events; the paired cohort contains 2,428 operations and 138 events. B, AUROC and Brier score for the nine- and 27-input systems; horizontal and vertical whiskers are separate marginal 95% intervals, not a joint confidence region. C, Existing empirical capture–review curves shown over 0–50% review capacity; full curves remain in eFigures 6 and 19. D, Absolute event counts and paired 27-minus-nine-input capture differences at target-ranked 20% capacity. Geographic and temporal evaluations contain 1,159/72 and 1,683/66 operations/events; their lists contain 232 and 337 records. Intervals reuse the original 2,000 hospital-stratified patient-group bootstrap samples. The curves use retrospective target rankings. AUROC indicates area under the receiver operating characteristic curve."),
("Acquisition costs, review capacity, and captured events","A–D, Geographic nine-to-27-input, temporal nine-to-27-input, geographic 27-to-38-input and temporal 27-to-38-input calibrated primary comparisons. The complete primary grids contain six budgets and 31 acquisition-cost values per comparison. Color shows additional-path minus baseline captured events per 1,000 operations on a common scale; selected cells show exact point estimates. Dots or asterisks identify pointwise 95% intervals excluding zero; nearby redundant dots are omitted around numerical labels. Grey cells are infeasible. Open triangles give the 20% equal-capture acquisition allowance, D divided by 1,000; this allowance is estimated retrospectively using target outcomes. Populations contain 1,159/72, 1,683/66, 1,158/72 and 1,011/36 operations/events. Costs are hypothetical review equivalents per eligible record. Intervals reuse the frozen 2,000 paired patient-group samples; the markers do not imply simultaneous inference. Additional cost-weighted results are retained in eFigure 20."),
("Equal-capture resources and cost-weighted event coverage","A and B, Signed acquisition allowance D with the original 95% intervals, in review equivalents per 1,000 operations, for geographic and temporal evaluation. Selected complete-system, same-family and public-bridge comparisons are retained. C, Baseline review-list size and the shortest additional-information list matching its captured-event count at a 20% baseline budget. D, Mean additional-path-minus-baseline capture differences and original 95% intervals under all five analyst-specified cost laws: Uniform[0,0.30], low-cost, middle-cost, high-cost and wide-tail weights. Exact distributions are specified in eMethods. The planning rule reverts to baseline review before spending when acquisition is unaffordable. Positive values favor additional-information capture; negative values favor expanded baseline review. The results are conditional on the cost laws and frozen systems; intervals reuse the original 2,000 paired patient-group samples. Expected shortfalls are retained in eFigure 21. LR indicates logistic regression."),
("Information representation and clinical review in INSPIRE","A, Released prior coded-history matches for diabetes, hypertension and other heart disease among 6,043 records; no released match does not establish clinical absence. B, Paired complete-workflow performance differences between coded-nine workflows and six-input random forests. AUROC and average precision (AP) are coded-nine minus six-input RF; Brier decrease is six-input RF minus coded-nine, with both limits reversed accordingly. Positive plotted values favor the coded-nine workflow; the comparisons do not isolate an input effect from the model family. C, Complete empirical target-ranking curves shown over 0–50% capacity, with counts at 20% capacity. The cohort contains 253 recorded SCr events. D, Review fraction and event coverage at target-ranked 20% capacity and unchanged source-sensitivity-80% cutoffs; dotted segments connect the two rule-specific operating points. Labels report reviewed records and captured events. Source-specific six-input RFs and coded-nine LR/Voting workflows retain their original information representations. Performance intervals reuse 2,000 frozen patient-group bootstrap samples; D shows observed operating points. Full curves and history matches remain in eFigure 22."),
("MIMIC clinical transport, workload, and measurement conditions","A, Qualification of 1,231 anatomically matched candidates, excluding 467 without baseline SCr and five without follow-up SCr, yielding 759 patients and 59 recorded events; observed counts for four preoperative laboratory inputs are shown below. B, Raw and source-calibrated Brier scores with original 95% intervals, alongside the apparent observed-prevalence constant as a point reference. AUROC summaries and calibrated-minus-reference Brier differences are annotated; complete comparisons are in eTable 32. C, Review fraction and recorded-event coverage for target-ranked 20% capacity, source-20%-capacity cutoffs and source-sensitivity-80% cutoffs; labels report reviewed patients and captured events. Geographic and temporal source models use six-input random forests. D, Existing measurement-thinning sensitivity in all observed records and the geographic six-input source-low-risk group, with 59 and 11 originally known events, respectively. Horizontal and vertical whiskers are separate original patient-bootstrap 95% intervals for measurements removed and known-event loss. These differ from the Wilson interval used for the 7/59 event-loss proportion in the main text. Thinning is a reanalysis of observed measurements, not a clinical monitoring intervention. Calendar-window endpoint definitions and full supporting results are retained in eTables 22–24 and 28–32 and eFigures 17 and 23. SCr indicates serum creatinine.")
]
ZH=[
("临床信息可获得性、预测表现与事件覆盖","A，队列规模、术前信息要求及术毕信息可获得性。主队列包含3,710次手术、3,693个患者组及205例记录性AKI；配对队列包含2,428次手术及138例事件。B，九项与27项输入系统的AUROC和Brier评分；横向和纵向误差线分别为边际95%区间，不表示联合置信区域。C，既有经验捕获—复核曲线展示0–50%复核容量范围，完整曲线保留于eFigures 6和19。D，目标排序20%容量下的绝对事件数及27项减九项输入的配对捕获差。地理与时间评价分别包含1,159/72和1,683/66次手术/事件，名单分别包含232和337条记录。区间复用原始2,000次医院分层患者组bootstrap样本。曲线使用目标队列结局回顾性排序。AUROC为受试者工作特征曲线下面积。"),
("信息采集成本、复核容量与事件捕获","A–D，地理九至27项、时间九至27项、地理27至38项及时间27至38项输入的校准主比较。每项比较的完整主网格包含六种预算及31种采集成本。共用色标表示追加路径减基础路径的每1,000次手术事件捕获差，选定单元格显示精确点估计。圆点或星号表示逐点95%区间不包含零；为清楚显示数值，省略数字邻近的重复圆点。灰色单元格为不可行情景。空心三角表示20%预算的等捕获采集余量，即D除以1,000；该余量根据目标结局回顾性估计。四项比较分别包含1,159/72、1,683/66、1,158/72和1,011/36次手术/事件。成本为每条合格记录的假设复核当量。区间复用冻结的2,000次配对患者组样本，标记不代表同时推断。进一步成本加权结果保留于eFigure 20。"),
("等捕获资源与成本加权事件覆盖","A和B，地理及时间评价的带符号采集余量D及原始95%区间，单位为每1,000次手术的复核当量；保留选定完整系统、同家族及公共桥接比较。C，20%基础预算下的基础名单长度，以及匹配其捕获事件数所需的最短追加信息名单。D，五种由分析者指定的成本分布下，追加路径减基础路径的平均捕获差及原始95%区间，包括Uniform[0,0.30]、低成本、中间成本、高成本和宽尾权重。精确分布见eMethods。规划规则在采集不可负担时，于支出前回退到基础复核。正值倾向追加信息路径，负值倾向扩大基础复核。结果以成本分布及冻结系统为条件，区间复用原始2,000次配对患者组样本。预期短缺保留于eFigure 21。LR为logistic回归。"),
("INSPIRE中的信息表征与临床复核","A，6,043条记录中糖尿病、高血压及其他心脏病的已发布既往编码病史匹配；无已发布匹配不等于临床不存在疾病。B，编码九项流程与六输入随机森林的配对完整流程表现差异；AUROC及平均精确率（AP）为编码九项减六项RF，Brier下降为六项RF减编码九项，并相应反转区间两端。图中正值倾向编码九项流程；比较未将输入作用与模型家族分离。C，既有目标排序经验曲线展示0–50%容量范围，并注明20%容量下的事件数。队列包含253例记录性SCr事件。D，目标排序20%容量与原样迁移源80%敏感性切点下的复核比例及事件覆盖；点线段连接两种规则各自的操作点。标签显示复核记录数及捕获事件数。源特异的六输入RF与编码九项LR/投票流程保留原信息表征。表现区间复用冻结的2,000次患者组bootstrap样本，D显示实际操作点。完整曲线及病史匹配保留于eFigure 22。"),
("MIMIC临床迁移、复核负担与测量条件","A，1,231名解剖学匹配候选者中，排除467名无基线SCr及五名无随访SCr者，得到759名患者及59例记录事件；下方列出四项术前实验室输入的实际观测数。B，原始及源校准Brier评分与原始95%区间，并以目标队列实际发生率常数作为表观点参照；标注AUROC概况及校准评分减参照的Brier差，完整比较见eTable 32。C，目标排序20%容量、源20%容量切点及源80%敏感性切点的复核比例与事件覆盖，标签为复核患者数及捕获事件数。地理及时间源模型均为六输入随机森林。D，全部有观测记录及地理六输入源低风险组的既有测量删减敏感性分析，两组原有已知事件分别为59例和11例。横向及纵向误差线分别为测量删除比例和已知事件损失比例的原始患者bootstrap 95%区间；这与正文7/59事件损失比例所用Wilson区间不同。测量删减是对实际观测的再分析，不是临床监测干预。日历窗口结局定义及完整支持结果保留于eTables 22–24、28–32以及eFigures 17和23。SCr为血清肌酐。")
]
# Explicit CSS makes Arial display correctly in office SVG consumers.
SVG='http://www.w3.org/2000/svg';ET.register_namespace('',SVG);ET.register_namespace('xlink','http://www.w3.org/1999/xlink')
for p in (W/'figures').rglob('*.svg'):
 tree=ET.parse(p);changed=False
 for t in tree.findall('.//{'+SVG+'}text'):
  st=t.get('style','');m=re.search(r'(?:^|;)\s*font:\s*([^;]+)',st)
  if not m:continue
  size=re.search(r'(\d+(?:\.\d+)?)px',m.group(1));assert size
  weight='700' if re.search(r'\b700\b|\bbold\b',m.group(1)) else '400'
  st=(st[:m.start()]+st[m.end():]).lstrip('; ')+'; font-family:Arial; font-size:'+size.group(1)+'px; font-weight:'+weight
  t.set('style',st);t.set('font-family','Arial');t.set('font-size',size.group(1));t.set('font-weight',weight);changed=True
 if changed:tree.write(p,encoding='utf-8',xml_declaration=True)
def blocks(text):return re.split(r'(?=^## (?:(?:e)?Figure \d+|(?:补)?图\d+)\.)',text,flags=re.M)
for lang,arr in [('EN',EN),('ZH',ZH)]:
 p=S/('FIGURE_LEGENDS.md' if lang=='EN' else 'FIGURE_LEGENDS_ZH.md');parts=blocks(p.read_text())
 for i,(title,body) in enumerate(arr,1):
  found=[j for j,b in enumerate(parts) if re.match((r'## Figure ' if lang=='EN' else r'## 图')+str(i)+r'\.',b)]
  assert len(found)==1,(lang,i)
  parts[found[0]]=(f'## Figure {i}. ' if lang=='EN' else f'## 图{i}. ')+title+'\n\n'+body+'\n\n'
 p.write_text(''.join(parts))
pairs=json.loads((W.parent/'figure_redesign_20261109_v1/review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
for i,(en,zh) in enumerate(zip(EN,ZH),1):
 row=next(x for x in pairs if x['figure']==i);row['english']=en[1];row['chinese']=zh[1]
(W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2))
for lang in ['EN','ZH']:
 p=S/f'MANUSCRIPT_{lang}.md';s=p.read_text()
 if lang=='EN':
  s=s.replace('Figure 1C and D','Figure 1B–D').replace('resource-grid rows (Figure 2A–D)','resource-grid rows (primary comparisons in Figure 2A–D)')
  s=s.replace('Figure 4C and D','Figure 4A–D')
  s=s.replace('Figure 5B–D','Figure 5B and C')
  # Supporting monitoring sensitivity is now also a main-figure display.
  s=s.replace('(eFigure 17).','(Figure 5D; eFigure 17).')
 else:
  s=s.replace('Figure 1C和D','Figure 1B至D').replace('（Figure 2A至D）','（主比较见Figure 2A至D）')
  s=s.replace('Figure 4C和D','Figure 4A至D').replace('Figure 5B至D','Figure 5B和C')
  s=s.replace('见eFigure 17。','见Figure 5D及eFigure 17。')
 p.write_text(s)
(S/'Chapters/FIGURE_LEGENDS.md').write_text((S/'FIGURE_LEGENDS.md').read_text())
# Preserve all prior submission figures as an explicitly historical set.
hist=W/'review/previous_main_assets';hist.mkdir(exist_ok=True)
for i in range(1,6):
 key=f'Figure_{i}';folder=F/key
 if not (hist/key).exists():shutil.copytree(folder,hist/key)
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(W/'figures'/f'{key}.{ext}',folder/f'{key}.{ext}')
 target=F/'Independent_panels'/key
 if target.exists():shutil.rmtree(target)
 shutil.copytree(W/'figures/panels'/key,target)
 shutil.copy2(W/'figures'/f'{key}.pdf',P/'01_Journal_files'/f'FIGURE_{i}.pdf')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
idx=json.loads((F/'FIGURE_SOURCE_INDEX.json').read_text())
for i,(title,caption) in enumerate(EN,1):
 item=next(x for x in idx if x['label']==f'Figure {i}');item.update(title=f'Figure {i}. '+title,caption=caption,panels=4,composite_revision='20261109_v2')
 item['assets']={str(p.relative_to(P)):sha(p) for p in (F/f'Figure_{i}').glob('*') if p.is_file()}
(F/'FIGURE_SOURCE_INDEX.json').write_text(json.dumps(idx,indent=2))
print('INTEGRATED_FIVE_COMPOSITE_MAIN_FIGURES_AND_29_BILINGUAL_LEGENDS')

