# 五幅复合主图（20261109 v2）

本次只重排冻结结果，没有训练或重抽样。完整原研究代码保留于相邻analysis_sources及原ANALYSIS_CODE.zip。当前主图代码为draw_composite_main.py；integrate_composites.py同步主图及中英图注；align_supplement_captions.py将补图12/13的原有图注对应与实际图像对齐；audit_composite_numbers.py核对104条有键数值/区间和825个冻结文件。qualify_composites.py核对实际PDF字体和文档图注身份，并建立五幅主图预览。其余脚本用于文档和修订稿。

实际执行根：/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/composite_main_figures_20261109_v2/。code/保存脚本，package/为本包内容，fonts/需自行提供授权Arial字体，本包不分发字体。图形解释器沿用项目已登记prediction_gpu环境；文档沿用document-rebuild-20261011；PDF检查沿用upar-structure-docking-py312-cpu-20261104-v1。环境和旧纯文本辅助函数的绝对路径在代码中明示，不声称脱离该服务器的一键独立安装。

重现顺序：draw_composite_main.py → integrate_composites.py → align_supplement_captions.py → 文档构建/渲染 → audit_composite_numbers.py / audit_final_documents.py / qualify_composites.py。不要对封存包直接重放；新建工作副本。AKI_EXPORT_ONLY用于仅输出选定主图的排版修复，默认输出五幅。原统计种子、方法及阈值未改变。

SFL参考仅用于固定行序、带数值注释矩阵的表达原则，保留固定提交及实际预览元数据。未执行其基因/连线模板，也未导入任何模拟数据。所有新图使用Python/Matplotlib，统计数据由冻结CSV提供。
