from pathlib import Path
import json,hashlib,re
import pymupdf as fitz
from PIL import Image,ImageDraw
W=Path(__file__).resolve().parents[1];P=W/'package';F=P/'05_Figure_assets'
out=[];combined=fitz.open();toc=[]
for i in range(1,6):
 p=P/f'01_Journal_files/FIGURE_{i}.pdf';d=fitz.open(p);assert len(d)==1
 ss=[s for b in d[0].get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l.get('spans',[]) if s['text'].strip()]
 sizes=[s['size'] for s in ss];fonts=sorted(set(s['font'] for s in ss))
 outside=[s['text'] for s in ss if s['bbox'][0]<-.5 or s['bbox'][1]<-.5 or s['bbox'][2]>d[0].rect.width+.5 or s['bbox'][3]>d[0].rect.height+.5]
 assert min(sizes)>=6.98 and all('Arial' in f for f in fonts) and not outside,(p,fonts,outside)
 assert p.stat().st_size<1024**2,p
 combined.insert_pdf(d);toc.append([1,f'Figure {i}',i])
 out.append(dict(figure=i,pdf_bytes=p.stat().st_size,width_mm=d[0].rect.width/72*25.4,height_mm=d[0].rect.height/72*25.4,font_families=fonts,min_font_pt=min(sizes),outside_text=outside,embedded_raster_images=len(d[0].get_images()),sha256=hashlib.sha256(p.read_bytes()).hexdigest()))
combined.set_toc(toc);combined.set_metadata({'title':'Five composite main figures: author preview','subject':'JAMA Network Open presentation; frozen AKI results','creator':'AKI project figure code'})
combined.save(P/'00_MAIN_FIGURES_PREVIEW.pdf',deflate=True,garbage=4);combined.close()
# All current figure titles/captions are taken from the editable source used to build Word.
english=(P/'04_Editable_sources/FIGURE_LEGENDS.md').read_text()
sd=fitz.open(P/'01_Journal_files/SUPPLEMENT_1.pdf')
text='\n'.join(pg.get_text() for pg in sd)
assert 'eFigure 12. Observed capture and assumption-based clinical-use trade-offs' in re.sub(r'\s+',' ',text)
assert 'eFigure 13. Calibration of the ten primary routes' in re.sub(r'\s+',' ',text)
# Check Word-rendered graph fonts, not just source PDFs.
graph_pages=[]
for i,pg in enumerate(sd):
 s=pg.get_text()
 if 'eFigure ' not in s or i<65:continue
 spans=[z for b in pg.get_text('dict')['blocks'] for l in b.get('lines',[]) for z in l.get('spans',[]) if z['text'].strip()]
 plots=[z for z in spans if 85<z['bbox'][1]<600 and z['size']>=9.98 and z['size']<10.02]
 if plots:
  assert all('Arial' in z['font'] for z in plots),(i,[(z['font'],z['text']) for z in plots if 'Arial' not in z['font']])
  graph_pages.append(i+1)
result=dict(status='PASS_CURRENT_MAIN_PDF_FONTS_GEOMETRY_AND_DOCUMENT_FIGURE_IDENTITIES',main_figures=out,maximum_panels=4,supplement_caption_identity={'eFigure12':'clinical-use scenarios','eFigure13':'calibration'},supplement_pages_with_native_Arial10_plot_text=graph_pages,supplement_PDF_pages=len(sd),visual_review='All five current main PNGs inspected; labels, legends, matrix contrast and operating-point callouts checked',new_statistics=0)
(W/'review/FINAL_VISUAL_AND_PDF_QUALIFICATION.json').write_text(json.dumps(result,indent=2))
# Compact style overview for quickly locating the full figure files.
canvas=Image.new('RGB',(2100,870),'#eeeeee');draw=ImageDraw.Draw(canvas)
for j,i in enumerate([2,3,4]):
 im=Image.open(W/'figures'/f'Figure_{i}.png').convert('RGB');im.thumbnail((680,800));x=j*700+(700-im.width)//2
 canvas.paste(im,(x,40));draw.text((j*700+20,15),f'Figure {i}',fill='black')
canvas.save(P/'03_Author_review/FIGURES_2_3_4_OVERVIEW.png')
print(json.dumps(dict(status=result['status'],main_PDF_min_fonts=[r['min_font_pt'] for r in out],main_PDF_bytes=[r['pdf_bytes'] for r in out],supplement_pages=len(sd),native_Arial10_plot_pages=len(graph_pages))))

