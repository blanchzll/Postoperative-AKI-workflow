import json,subprocess,os,select,time,tomllib
from pathlib import Path
W=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/composite_main_figures_20261109_v2')
cfg=tomllib.loads(Path('/home/lei/codex-workspaces/scientific-figure-library/config/codex-server-entry.toml').read_text())['mcp_servers']['figure-library']
env=os.environ.copy();env.update(cfg['env'])
err=(W/'review/SFL_STDERR.log').open('w')
p=subprocess.Popen([cfg['command']]+cfg['args'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=err,env=env)
buf=b''
def send(x):
 p.stdin.write((json.dumps(x)+'\n').encode());p.stdin.flush()
def response(i,timeout=55):
 global buf
 end=time.monotonic()+timeout
 while time.monotonic()<end:
  while b'\n' in buf:
   ln,buf=buf.split(b'\n',1)
   try:r=json.loads(ln)
   except Exception:continue
   if r.get('id')==i:return r
  ready,_,_=select.select([p.stdout],[],[],min(1,max(0,end-time.monotonic())))
  if ready:
   chunk=os.read(p.stdout.fileno(),262144)
   if not chunk:raise RuntimeError('SFL process exited '+str(p.poll()))
   buf+=chunk
 raise TimeoutError('SFL response '+str(i))
try:
 send({'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'aki-figure-review','version':'1'}}})
 init=response(1)
 send({'jsonrpc':'2.0','method':'notifications/initialized','params':{}})
 send({'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}})
 listing=response(2);(W/'review/SFL_TOOL_SCHEMAS.json').write_text(json.dumps(listing,indent=2))
 wanted=[t for t in listing.get('result',{}).get('tools',[]) if t['name'] in ['figure_library_source_status','figure_library_search']]
 send({'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'figure_library_source_status','arguments':{}}})
 status=response(3)
 (W/'review/SFL_SOURCE_STATUS.json').write_text(json.dumps(status,ensure_ascii=False,indent=2))
 searches=[]
 for j,(query,family) in enumerate([('heatmap annotated matrix','heatmap')]):
  rid=10+j*10
  send({'jsonrpc':'2.0','id':rid,'method':'tools/call','params':{'name':'figure_library_search','arguments':{'query':query,'limit':2}}})
  res=response(rid);data=res.get('result',{}).get('structuredContent',{});searches.append(data)
  (W/'references'/('search_'+family+'.json')).write_text(json.dumps(data,ensure_ascii=False,indent=2))
  cs=data.get('candidates',[])
  if cs:
   c=cs[0]
   send({'jsonrpc':'2.0','id':rid+1,'method':'tools/call','params':{'name':'figure_library_preview_exact_headless','arguments':{'providerId':c['providerId'],'exactSelector':c['exactSelector'],'resultSetId':data['resultSetId']}}})
   preview=response(rid+1);small=dict(preview)
   import base64
   result=preview.get('result',{})
   for k,block in enumerate(result.get('content',[])):
    if block.get('type')=='image':
     suffix='.png' if block.get('mimeType')=='image/png' else '.jpg'
     (W/'references'/('preview_'+family+str(k)+suffix)).write_bytes(base64.b64decode(block['data']))
     block['data']='[image saved on server]'
   (W/'references'/('preview_'+family+'.json')).write_text(json.dumps(small,ensure_ascii=False,indent=2))
 print(json.dumps({'candidates':[[dict(id=x['templateId'],title=x['title'],source=x.get('sourceUrl')) for x in d.get('candidates',[])] for d in searches]},ensure_ascii=False))

finally:
 p.stdin.close()
 try:p.wait(timeout=3)
 except subprocess.TimeoutExpired:p.terminate();p.wait(timeout=5)
 err.close()
