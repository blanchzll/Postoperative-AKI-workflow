from pathlib import Path
import os,json,hashlib,re,copy,textwrap
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.font_manager import fontManager
from matplotlib.patches import Rectangle,FancyArrowPatch
from matplotlib.lines import Line2D
W=Path(__file__).resolve().parents[1];P=W/'package';C=P/'02_Code_and_aggregate_data';O=W/'figures'
for f in (W/'fonts').glob('Arial*.ttf'):fontManager.addfont(str(f))
mpl.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'xtick.direction':'out','ytick.direction':'out','axes.linewidth':.65,'savefig.facecolor':'white','text.color':'#222222','axes.labelcolor':'#222222'})
SL='#374E55';OR='#DF8F44';PU='#6A6599';GR='#C9CED1';TE='#79AF97';LIGHT='#F1F4F5';INK='#222222'
COL=[SL,'#8E9EA4',OR,'#EBC8A7']
DIV=LinearSegmentedColormap.from_list('clinical_diverging',[OR,'white',SL])
SEQ=LinearSegmentedColormap.from_list('clinical_seq',['#F5F6F7',SL])
inputs={};ledger=[];manifest=[]
def contrast_color(rgba):
 rgb=np.asarray(rgba[:3],float);linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4);lum=float(np.dot(linear,[.2126,.7152,.0722]))
 return 'white' if 1.05/(lum+.05)>(lum+.05)/.05 else INK
def load(rel):
 p=C/rel;inputs[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return pd.read_csv(p)
def src(name):return load('aggregate_data/source_data/'+name+'.csv')
def one(d,**kw):
 for k,v in kw.items():d=d[d[k]==v]
 assert len(d)==1,(kw,len(d));return d.iloc[0]
def rec(fig,panel,label,source_key,value,lo=None,hi=None):
 ledger.append(dict(figure=fig,panel=panel,label=label,source_key=source_key,value=float(value),lower95=None if lo is None else float(lo),upper95=None if hi is None else float(hi)))
def newfig(n,positions=None):
 f=plt.figure(figsize=(183/25.4,210/25.4),facecolor='white')
 positions=positions or [[.14,.59,.33,.29],[.63,.59,.33,.29],[.14,.13,.33,.29],[.63,.13,.33,.29]]
 return f,[f.add_axes(x) for x in positions]
def title(ax,letter,text,sub=None):
 width=max(28,int(ax.get_position().width*183/25.4*72/3.45))
 wrapped=textwrap.fill(sub,width) if sub else None
 ax.set_title(textwrap.fill(letter+'  '+text,max(28,int(ax.get_position().width*183/25.4*72/4.0))),loc='left',fontweight='bold',pad=32 if wrapped and '\\n' in wrapped else 23 if sub else 12)
 if wrapped:ax.text(0,1.025,wrapped,transform=ax.transAxes,fontsize=7,va='bottom',linespacing=1.2)
def mark(ax,x,y,lo,hi,c,marker='o',open=False):
 ax.errorbar(x,y,xerr=[[x-lo],[hi-x]],fmt=marker,color=c,mfc='white' if open else c,ms=4,capsize=2,lw=.85,zorder=3)
def panel_hash(ax):
 h=hashlib.sha256()
 for l in ax.lines:h.update(np.asarray(l.get_xydata(),float).tobytes())
 for im in ax.images:h.update(np.ma.asarray(im.get_array()).filled(np.nan).tobytes())
 for c in ax.collections:
  h.update(np.ma.asarray(c.get_offsets()).filled(np.nan).tobytes())
  if c.get_array() is not None:h.update(np.ma.asarray(c.get_array()).filled(np.nan).tobytes())
  for p in c.get_paths():h.update(np.asarray(p.vertices,float).tobytes())
 return h.hexdigest()
def save(f,a,n,topic):
 selected=os.environ.get('AKI_EXPORT_ONLY','')
 if selected and str(n) not in selected.split(','):plt.close(f);return
 f.canvas.draw()
 for axis_ax in f.axes:
  for axis,limits in [(axis_ax.xaxis,axis_ax.get_xlim()),(axis_ax.yaxis,axis_ax.get_ylim())]:
   for tick in axis.get_major_ticks()+axis.get_minor_ticks():
    if not min(limits)-1e-8<=tick.get_loc()<=max(limits)+1e-8:
     tick.label1.set_visible(False);tick.label2.set_visible(False)
 f.canvas.draw();ren=f.canvas.get_renderer();outside=[]
 for t in f.findobj(mpl.text.Text):
  if not t.get_visible() or not t.get_text().strip():continue
  bb=t.get_window_extent(ren)
  # Only visible tick labels inside axis limits are included below in PDF qualification.
  if bb.x0<-.5 or bb.x1>f.bbox.width+.5 or bb.y0<-.5 or bb.y1>f.bbox.height+.5:outside.append(t.get_text())
 assert not outside,(n,'text outside canvas',outside)
 base=O/f'Figure_{n}'
 for ext in ['pdf','svg']:f.savefig(str(base)+'.'+ext)
 f.savefig(str(base)+'.png',dpi=300);f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 d=O/'panels'/f'Figure_{n}';d.mkdir(parents=True,exist_ok=True)
 for i,ax in enumerate(a):
  fc=copy.deepcopy(f);target=fc.axes[f.axes.index(ax)]
  linked=[c for c in fc.axes if c.get_label()=='<colorbar>' and getattr(c,'_colorbar',None) is not None and c._colorbar.mappable.axes is target]
  for x in list(fc.axes):
   if x is not target and x not in linked:fc.delaxes(x)
  fc.canvas.draw();r=fc.canvas.get_renderer();boxes=[x.get_tightbbox(r) for x in [target]+linked]
  bb=mpl.transforms.Bbox.union(boxes).transformed(fc.dpi_scale_trans.inverted()).expanded(1.04,1.07)
  for ext in ['pdf','svg']:fc.savefig(d/f'Figure_{n}_{chr(65+i)}.{ext}',bbox_inches=bb)
  plt.close(fc)
 manifest.append(dict(figure=f'Figure_{n}',panels=4,topic=topic,width_mm=183,height_mm=210,numeric_artist_sha256={chr(65+i):panel_hash(ax) for i,ax in enumerate(a)}))
 plt.close(f);print('RENDERED',n,flush=True)
pts=src('Primary_model_points');ints=src('Primary_model_intervals');cap=load('aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv');bounds=load('aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv')
contexts=['geography_preop','temporal_preop']
rows=[]
for ctx in contexts:
 for kind in ['compact','full']:rows.append(pts[(pts.context==ctx)&pts.model.str.contains('preop_'+kind+'_champion')].iloc[0])
# Figure1: one clinical question from information availability to additional captured events.
f,a=newfig(1,[[.07,.58,.41,.32],[.64,.58,.32,.32],[.12,.12,.35,.30],[.63,.12,.33,.30]])
ax=a[0];ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off');title(ax,'A','Clinical cohort and information timeline')
blocks=[(.80,'Clinical cohort','3,710 operations · 205 recorded AKI events\n3,693 patient groups · 5 Chinese centers',SL),
(.48,'Preoperative decision','9 routine inputs  →  27 inputs\n18 additional fields',PU),
(.16,'End of operation','27 preoperative + 11 intraoperative inputs\nPaired cohort: 2,428 operations · 138 events',OR)]
for y,h,t,c in blocks:
 ax.add_patch(Rectangle((.02,y-.10),.94,.25,facecolor=LIGHT,edgecolor=c,lw=.8))
 ax.text(.055,y+.105,h,fontweight='bold',fontsize=8,va='top')
 ax.text(.055,y+.035,t,fontsize=7.3,va='top',linespacing=1.35)
 if y>.2:ax.annotate('',xy=(.49,y-.18),xytext=(.49,y-.105),arrowprops=dict(arrowstyle='->',lw=.9,color=SL))
ax.text(.02,-.07,'Geographic evaluation: 1,159 operations / 72 events\nTemporal evaluation: 1,683 operations / 66 events',fontsize=7.2,va='top')
ax=a[1];title(ax,'B','Discrimination and probability error')
for k,(r,c) in enumerate(zip(rows,[SL,SL,OR,OR])):
 ix=one(ints,context=r.context,model=r.model,metric='AUROC');iy=one(ints,context=r.context,model=r.model,metric='Brier')
 ax.errorbar(r.AUROC,r.Brier,xerr=[[r.AUROC-ix.lower95],[ix.upper95-r.AUROC]],yerr=[[r.Brier-iy.lower95],[iy.upper95-r.Brier]],fmt='o' if k%2==0 else 's',mfc=c if k%2==0 else 'white',color=c,ms=4.5,capsize=2,lw=.75,label=('Geo' if k<2 else 'Time')+(' · 9' if k%2==0 else ' · 27'))
 for metric,z in [('AUROC',ix),('Brier',iy)]:rec(1,'B',r.model,'Primary_model_intervals:'+r.context+':'+metric,z.estimate,z.lower95,z.upper95)
ax.set(xlim=(.50,.90),ylim=(.015,.085),xlabel='AUROC',ylabel='Brier score')
ax.legend(ncol=2,loc='upper center',bbox_to_anchor=(.5,.98),columnspacing=1,handlelength=1)

ax=a[2];title(ax,'C','Review capacity and event coverage','Empirical curves shown over 0–50% capacity')
for ctx,c in zip(contexts,[SL,OR]):
 d=src('Translation_'+ctx+'_CAPTURE_REVIEW_CURVE')
 for kind,ls in [('compact','-'),('full','--')]:
  z=d[d.model.str.contains('preop_'+kind+'_champion')].sort_values('reviewed_n')
  ax.plot(z.reviewed_per1000/10,z.sensitivity*100,color=c,ls=ls,lw=1.1,label=('Geo' if ctx.startswith('geo') else 'Time')+(' · 9' if kind=='compact' else ' · 27'))
  rec(1,'C',ctx+':'+kind,'empirical_curve_rows',len(z))
ax.axvline(20,color='#999999',ls=':',lw=.8);ax.set(xlim=(0,50),ylim=(0,100),xlabel='Records reviewed, %',ylabel='Recorded AKI events captured, %')
ax.legend(ncol=2,loc='upper left',bbox_to_anchor=(-.02,-.25),columnspacing=.7,handlelength=1.6)
ax=a[3];title(ax,'D','Added capture at 20% capacity','27 inputs minus 9 inputs; paired 95% intervals')
for j,(cid,c) in enumerate(zip(['geography_9v27_champ','temporal_9v27_champ'],[SL,OR])):
 r=one(cap,comparison_id=cid);y=3.0-2*j
 ax.text(-5.9,y+.72,('Geographic' if j==0 else 'Temporal')+f' · {int(r.base_reviews_n)} records reviewed',fontsize=7.7,fontweight='bold')
 ax.text(-5.9,y+.35,f'{int(r.base_captured_n)}/{int(r.events)} → {int(r.extra_captured_n)}/{int(r.events)} events captured',fontsize=7.3)
 mark(ax,r.delta_captured_per1000,y,r.delta_captured_per1000_lower95,r.delta_captured_per1000_upper95,c)
 ax.text(-5.9,y-.45,f'{r.delta_captured_per1000:.2f} ({r.delta_captured_per1000_lower95:.2f} to {r.delta_captured_per1000_upper95:.2f})',fontsize=7.3)
 rec(1,'D',cid,'PRIMARY_EQUAL_CAPACITY20:delta_captured_per1000',r.delta_captured_per1000,r.delta_captured_per1000_lower95,r.delta_captured_per1000_upper95)
ax.axvline(0,color='#999999',lw=.7);ax.set(xlim=(-6.2,9),ylim=(.25,4),xlabel='Additional events captured per 1,000');ax.set_yticks([]);ax.spines['left'].set_visible(False)
save(f,a,1,'Clinical information availability, predictive performance and review coverage')
# Figure2: original full grid with interpretable exact cell values and equal-capture allowance.
grid=load('aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv')
ids=['geography_9v27_champ','temporal_9v27_champ','geography_27v38_champ','temporal_27v38_champ']
names=['Geo 9→27','Time 9→27','Geo 27→38','Time 27→38']
vmax=max(abs(grid.delta_captured_per1000.dropna()));norm=TwoSlopeNorm(0,-vmax,vmax)
f,a=newfig(2,[[.12,.61,.32,.27],[.62,.61,.32,.27],[.12,.15,.32,.27],[.62,.15,.32,.27]])
for i,(cid,name) in enumerate(zip(ids,names)):
 ax=a[i];d=grid[(grid.comparison_id==cid)&(grid['mode']=='calibrated')].copy()
 d.loc[~d.feasible_at_point,'delta_captured_per1000']=np.nan
 mat=d.pivot(index='budget_percent',columns='extra_cost_per_person_review_equivalents',values='delta_captured_per1000')
 im=ax.pcolormesh(np.arange(32)*.01-.005,np.arange(7)*5+2.5,mat.to_numpy(),cmap=DIV,norm=norm,shading='flat',rasterized=False)
 b=one(bounds,comparison_id=cid,mode='calibrated',budget_percent=20)
 title(ax,chr(65+i),name+' · same total budget',f'20% equal-capture allowance: {b.signed_allowable_extra_cost_per1000/1000:.3f} per record')
 ax.set_facecolor('#EEEEEE');ax.set(xlim=(-.005,.305),ylim=(2.5,32.5),xlabel='Acquisition cost / review cost',ylabel='Total budget, %')
 ax.set_xticks([0,.1,.2,.3]);ax.set_yticks([5,10,15,20,25,30])
 for _,r in d[d.feasible_at_point].iterrows():
  cst=float(r.extra_cost_per_person_review_equivalents);v=r.delta_captured_per1000
  number=any(abs(cst-z)<1e-8 for z in [0,.1,.2,.3])
  sig=r.delta_captured_per1000_lower95>0 or r.delta_captured_per1000_upper95<0
  if number:
   ax.text(cst+(.003 if cst==0 else -.003 if abs(cst-.3)<1e-8 else 0),r.budget_percent,f'{v:.1f}'+('*' if sig else ''),ha='left' if cst==0 else 'right' if abs(cst-.3)<1e-8 else 'center',va='center',fontsize=7,color=contrast_color(DIV(norm(v))),bbox=dict(facecolor=DIV(norm(v)),edgecolor='none',pad=.2))
  elif sig and min(abs(cst-z) for z in [0,.1,.2,.3])>.025:ax.plot(cst,r.budget_percent,'o',ms=1.8,color=INK)
 ax.plot(b.signed_allowable_extra_cost_per1000/1000,20,marker='v',mfc='none',mec=PU,ms=8,mew=1.2)
 cb=f.colorbar(im,ax=ax,fraction=.035,pad=.025);cb.set_label('Δ captured events / 1,000',fontsize=7)
 rec(2,chr(65+i),cid,'BREAK_EVEN_BOUNDARIES:signed_allowable_extra_cost_per1000',b.signed_allowable_extra_cost_per1000,b.lower95,b.upper95)
f.text(.12,.035,'Numbers: selected exact cells. Dot or asterisk: pointwise 95% interval excludes zero.\nGrey: acquisition is unaffordable. Open triangle: 20% equal-capture allowance.',fontsize=7.5,linespacing=1.4)
save(f,a,2,'Acquisition and review resource trade-offs across the complete primary grids')
# Figure3: matched headroom evidence, review counts, and weighted effects with original intervals.
prob=load('probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv')
laws=list(prob.distribution.drop_duplicates())
f,a=newfig(3,[[.18,.60,.29,.30],[.68,.60,.29,.30],[.12,.14,.25,.29],[.54,.14,.40,.29]])
keys=['9v27_champ','27v38_champ','9v27_LR','27v38_LR','27v38_Voting','6v9_LR','INSPIRE6v9'];short=['9→27 selected','27→38 selected','9→27 LR','27→38 LR','27→38 Voting','6→9 LR','INSPIRE 6→9']
for j,(line,c) in enumerate(zip(['geography','temporal'],[SL,OR])):
 ax=a[j];title(ax,chr(65+j),('Geographic' if j==0 else 'Temporal')+' · acquisition allowance')
 for y,(k,lab) in enumerate(zip(keys,short)):
  r=one(bounds,comparison_id=line+'_'+k,mode='calibrated',budget_percent=20)
  mark(ax,r.signed_allowable_extra_cost_per1000,y,r.lower95,r.upper95,c)
  ax.text(-340,y+.31,f'{r.signed_allowable_extra_cost_per1000:.1f} ({r.lower95:.1f}, {r.upper95:.1f})',fontsize=7,va='center')
  rec(3,chr(65+j),line+'_'+k,'BREAK_EVEN_BOUNDARIES',r.signed_allowable_extra_cost_per1000,r.lower95,r.upper95)
 ax.axvline(0,color='#999999',lw=.8);ax.set_yticks(range(7),short);ax.set(xlim=(-350,200),ylim=(6.65,-.55),xlabel='Review equivalents per 1,000')
ax=a[2];title(ax,'C','Reviews for equal capture','At a 20% baseline budget')
rr=[one(bounds,comparison_id=cid,mode='calibrated',budget_percent=20) for cid in ids]
for i,(r,lab) in enumerate(zip(rr,names)):
 ax.barh(i-.17,r.reference_reviews_n,.3,color=GR,label='Baseline' if i==0 else None)
 ax.barh(i+.17,r.minimum_extra_path_reviews_for_same_capture,.3,color=PU,label='Additional path' if i==0 else None)
 ax.text(r.reference_reviews_n+4,i-.17,f'{r.reference_reviews_n:.0f}',fontsize=7,va='center')
 ax.text(r.minimum_extra_path_reviews_for_same_capture+4,i+.17,f'{r.minimum_extra_path_reviews_for_same_capture:.0f}',fontsize=7,va='center')
 rec(3,'C',lab,'reference_reviews_n',r.reference_reviews_n);rec(3,'C',lab,'minimum_extra_path_reviews_for_same_capture',r.minimum_extra_path_reviews_for_same_capture)
ax.set_yticks(range(4),names);ax.invert_yaxis();ax.set(xlim=(0,390),xlabel='Records reviewed')
ax.legend(loc='upper left',bbox_to_anchor=(-.12,-.13),fontsize=7)
ax=a[3];title(ax,'D','Cost-weighted capture difference','Additional path minus expanded baseline review / 1,000')
m=np.array([[one(prob,comparison=cid,distribution=l).mean_delta_per1000_fallback for l in laws] for cid in ids]);v=np.max(abs(m));im=ax.pcolormesh(np.arange(6)-.5,np.arange(5)-.5,m,cmap=DIV,norm=TwoSlopeNorm(0,-v,v),shading='flat',rasterized=False);ax.set(xlim=(-.5,4.5),ylim=(3.5,-.5))
for (i,j),value in np.ndenumerate(m):
 r=one(prob,comparison=ids[i],distribution=laws[j]);lo=r.mean_delta_per1000_fallback_patient_lower95;hi=r.mean_delta_per1000_fallback_patient_upper95
 ax.text(j,i,f'{value:.1f}\n({lo:.1f}, {hi:.1f})',ha='center',va='center',fontsize=7,color=contrast_color(DIV(TwoSlopeNorm(0,-v,v)(value))),linespacing=1.4)
 rec(3,'D',ids[i]+':'+laws[j],'PRIMARY_20_PERCENT_SUMMARY',value,lo,hi)
ax.set_yticks(range(4),names);ax.set_xticks(range(5),['Uniform','Low cost','Middle','High cost','Wide tail'],rotation=35,ha='right')
cb=f.colorbar(im,ax=ax,fraction=.035,pad=.025);cb.set_label('Events / 1,000',fontsize=7)
f.text(.12,.035,'All five cost laws are analyst-specified. Parentheses show original paired 95% intervals.\nUnaffordable acquisition reverts to baseline review before spending.',fontsize=7.4,linespacing=1.4)
save(f,a,3,'Equal-capture resource allowance and conditional cost-weighted effects')
# Figure4: representation, paired performance, target ranking and source-threshold burdens in INSPIRE.
pub=src('Coded9_POINT_ESTIMATES');pi=src('Coded9_INTERVALS');diff=src('Coded9_PAIRED_DIFFERENCES_VS_SIX_RF');hist=src('Coded9_HISTORY_COUNTS');cov=src('Coded9_SOURCE_THRESHOLD_COVERAGE')
cal=pub[pub.model.str.endswith('__calibrated')]
f,a=newfig(4,[[.18,.60,.29,.29],[.67,.60,.29,.29],[.13,.13,.34,.29],[.63,.13,.33,.29]])
ax=a[0];title(ax,'A','Released preoperative history','6,043 records; coded absence is not confirmed clinical absence')
for i,r in hist.iterrows():
 ax.barh(i-.17,r.coded_one,.3,color=SL,label='Prior coded match' if i==0 else None)
 ax.barh(i+.17,r.coded_zero_no_released_prior_match,.3,color=GR,label='No released match' if i==0 else None)
 ax.text(r.coded_one+50,i-.17,f'{r.coded_one:.0f}',fontsize=7,va='center')
 ax.text(r.coded_zero_no_released_prior_match-80,i+.17,f'{r.coded_zero_no_released_prior_match:.0f}',fontsize=7,va='center',ha='right')
ax.set_yticks(range(3),[x.replace('HeartDisease','Other heart disease') for x in hist.predictor]);ax.invert_yaxis();ax.set(xlim=(0,6500),xlabel='Records');ax.legend(loc='upper center',bbox_to_anchor=(.5,-.24),fontsize=7)
ax=a[1];title(ax,'B','Paired model performance','Positive: higher AUROC / AP or lower Brier with coded-nine')
labels=[];y=0
for line,c in zip(['geography','temporal'],[SL,OR]):
 model=diff[diff.model.str.startswith(line)&diff.model.str.contains('__calibrated')].model.iloc[0]
 for met,lab,sgn in [('AUROC','Δ AUROC',1),('AP','Δ AP',1),('Brier','Brier decrease',-1)]:
  r=one(diff,model=model,metric=met);v=r.estimate*sgn;lo=min(r.lower95*sgn,r.upper95*sgn);hi=max(r.lower95*sgn,r.upper95*sgn)
  mark(ax,v,y,lo,hi,c);labels.append(('Geo · ' if line=='geography' else 'Time · ')+lab)
  ax.text(-.018,y+.30,(f'{v:.2g} ({lo:.2g}, {hi:.2g})' if met=='Brier' else f'{v:.4f} ({lo:.4f}, {hi:.4f})'),fontsize=7,va='center')
  rec(4,'B',line+':'+met,'Coded9_PAIRED_DIFFERENCES_VS_SIX_RF;display sign='+str(sgn),v,lo,hi);y+=1
ax.set_yticks(range(6),labels);ax.set(xlim=(-.02,.055),ylim=(5.65,-.55),xlabel='Difference (unitless)');ax.axvline(0,color='#999999',lw=.8)
ax=a[2];title(ax,'C','Review capacity and event coverage','6,043 records · 253 SCr events; 0–50% capacity')
curves=src('Coded9_FULL_CAPTURE_REVIEW_CURVE')
models=list(cal.model)
for k,model in enumerate(models):
 r=one(cal,model=model);z=curves[curves.model==model].sort_values('reviewed_n');ax.plot(z.reviewed_per1000/10,z.sensitivity*100,c=COL[k],ls='-' if k%2==0 else '--',lw=1.2,label=['Geo · 6','Geo · 9','Time · 6','Time · 9'][k])
 ax.plot(r.capacity20_reviewed_per1000/10,r.capacity20_sensitivity*100,'o' if k%2==0 else 's',color=COL[k],ms=3)
 rec(4,'C',model,'Coded9_POINT_ESTIMATES:capacity20_captured_n',r.capacity20_captured_n)
ax.axvline(20,color='#999999',ls=':',lw=.8);ax.set(xlim=(0,50),ylim=(0,100),xlabel='Records reviewed, %',ylabel='Recorded SCr events captured, %');ax.legend(ncol=2,loc='upper left',bbox_to_anchor=(-.05,-.25),columnspacing=.8)
ax.text(.98,.03,'At 20%: Geo 121→123; Time 124→128 events',transform=ax.transAxes,fontsize=7,ha='right')
ax=a[3];title(ax,'D','Threshold transfer and review burden','Source sensitivity-80% cutoff versus target-ranked 20%')
for k,(model,c) in enumerate(zip(models,COL)):
 line='geography' if model.startswith('geography') else 'temporal';kind='six_RF' if '__six_RF__' in model else 'coded9_LR' if line=='geography' else 'coded9_Voting'
 r=one(cal,model=model);q=one(cov,source_line=line,model=kind)
 x0=r.capacity20_reviewed_per1000/10;y0=r.capacity20_sensitivity*100;x=q.reviewed_percent;y=q.target_sensitivity_percent
 ax.plot([x0,x],[y0,y],color=c,lw=.8,ls=':');ax.plot(x0,y0,'o',color=c,ms=3);ax.plot(x,y,'D',color=c,ms=4)
 tx,ty,align=[(39,65,'left'),(4,103,'left'),(123,109,'right'),(68,84,'left')][k]
 ax.annotate(['Geo · 6','Geo · 9','Time · 6','Time · 9'][k]+f'\n{q.reviewed_n:.0f} reviewed / {q.captured_n:.0f} events',(x,y),xytext=(tx,ty),textcoords='data',fontsize=7,ha=align,va='top',arrowprops=dict(arrowstyle='-',color=c,lw=.55))
 rec(4,'D',model,'Coded9_SOURCE_THRESHOLD_COVERAGE:reviewed_percent',x);rec(4,'D',model,'Coded9_SOURCE_THRESHOLD_COVERAGE:target_sensitivity_percent',y)
ax.set(xlim=(0,125),ylim=(0,110),xlabel='Records reviewed, %',ylabel='Recorded SCr events captured, %');ax.set_xticks([0,20,40,60,80,100]);ax.set_yticks([0,20,40,60,80,100]);ax.legend(handles=[Line2D([],[],marker='o',color=INK,ls='None',ms=3,label='Target ranking'),Line2D([],[],marker='D',color=INK,ls='None',ms=3,label='Transferred cutoff')],loc='lower right',fontsize=7)
save(f,a,4,'INSPIRE input representation, paired comparisons and threshold transport')
# Figure5: target cohort qualification, probabilistic accuracy, policy workload and measurement sensitivity.
mp=load('aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv');mi=load('aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv');cut=load('aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv')
deletion=load('clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv')
f,a=newfig(5,[[.12,.60,.35,.28],[.64,.60,.28,.28],[.12,.13,.35,.29],[.63,.13,.33,.29]])
ax=a[0];title(ax,'A','Clinical qualification and data availability')
levels=[1231,764,759,759];starts=[0,764,759,0];heights=[1231,467,5,759];cols=[SL,GR,GR,PU]
for i,(bottom,h,c) in enumerate(zip(starts,heights,cols)):
 ax.bar(i,h,bottom=bottom,width=.63,color=c,edgecolor='white',lw=.6)
 ax.text(i,bottom+h+30,['1,231','−467','−5','759'][i],ha='center',fontsize=8,fontweight='bold')
 if i<3:ax.plot([i+.315,i+.685],[levels[i],levels[i]],c='#888888',lw=.6)
ax.set_xticks(range(4),['Anatomic\ncandidates','No baseline\nSCr','No follow-up\nSCr','Eligible']);ax.set(ylim=(0,1500),ylabel='Patients',xlim=(-.6,3.6))
ax.text(.03,.96,'759 patients · 59 SCr events',transform=ax.transAxes,fontsize=7.5,va='top')
ax.text(0,-.18,'Observed / 759: creatinine 759; urea nitrogen 726;\nalbumin 294; hemoglobin 719.',transform=ax.transAxes,fontsize=7.2,va='top')
ax=a[1];title(ax,'B','Target probability error','Brier score: point estimates and original 95% intervals')
mat=np.array([[one(mp,model=line+'__'+mode).Brier for line in ['geography','temporal']] for mode in ['raw','calibrated']]+[[59/759*(1-59/759)]*2])
im=ax.pcolormesh(np.arange(3)-.5,np.arange(4)-.5,mat,cmap=SEQ,vmin=0,vmax=.10,shading='flat',rasterized=False);ax.set(xlim=(-.5,1.5),ylim=(2.5,-.5))
for i in range(3):
 for j,line in enumerate(['geography','temporal']):
  if i<2:
   r=one(mi,model=line+'__'+['raw','calibrated'][i],metric='Brier');text=f'{r.estimate:.4f}\n({r.lower95:.4f}, {r.upper95:.4f})'
   rec(5,'B',line+':'+['raw','calibrated'][i],'mimic_calendar_v2/INTERVALS:Brier',r.estimate,r.lower95,r.upper95)
  else:text=f'{mat[i,j]:.4f}\nPoint reference'
  ax.text(j,i,text,ha='center',va='center',fontsize=7.3,color=contrast_color(SEQ(mpl.colors.Normalize(0,.10)(mat[i,j]))),linespacing=1.5)
ax.set_xticks([0,1],['Geographic RF','Temporal RF']);ax.set_yticks(range(3),['Frozen raw','Source-calibrated','Observed-prevalence\nconstant'])
cb=f.colorbar(im,ax=ax,fraction=.035,pad=.025);cb.set_label('Brier score',fontsize=7)
ax.text(0,-.18,'AUROC: 0.614 (0.549–0.680); 0.621 (0.552–0.688).\nCalibrated Brier minus reference: +0.0088; +0.0027.',transform=ax.transAxes,fontsize=7.2,va='top')
ax=a[2];title(ax,'C','Workload and recorded-event coverage','Same patients; three threshold rules')
for j,(line,c) in enumerate(zip(['geography','temporal'],[SL,OR])):
 r=one(mp,model=line+'__calibrated')
 entries=[('Target 20%',r.capacity20_reviewed_n,r.capacity20_captured_n,r.capacity20_reviewed_per1000/10,r.capacity20_sensitivity*100)]
 for rule,lab in [('training_capacity20','Source 20%'),('training_sensitivity80','Source 80% sensitivity')]:
  z=cut[(cut.source_line==line)&(cut.rule==rule)]
  rn=one(z,metric='reviewed_n').estimate;cn=one(z,metric='captured_n').estimate
  entries.append((lab,rn,cn,rn/759*100,cn/59*100))
 for k,(lab,rn,cn,x,y) in enumerate(entries):
  ax.plot(x,y,marker=['o','D','^'][k],color=c,ms=4.5,mfc=c if j==0 else 'white',mew=1)
  tx,ty=([(3,12),(45,66),(5,94)] if j==0 else [(37,30),(45,45),(62,109)])[k]
  shortlab=['target 20%','source 20%','source sensitivity 80%'][k]
  ax.annotate(('Geo · ' if j==0 else 'Time · ')+shortlab+f'\n{rn:.0f} reviewed / {cn:.0f} events',(x,y),xytext=(tx,ty),textcoords='data',fontsize=7,ha='left',va='top',arrowprops=dict(arrowstyle='-',color=c,lw=.55))
  rec(5,'C',line+':'+lab,'saved threshold or target20 counts:reviewed_n',rn);rec(5,'C',line+':'+lab,'saved threshold or target20 counts:captured_n',cn)
ax.set(xlim=(0,110),ylim=(0,110),xlabel='Patients reviewed, %',ylabel='Recorded SCr events captured, %');ax.set_xticks([0,20,40,60,80,100]);ax.set_yticks([0,20,40,60,80,100])
ax=a[3];title(ax,'D','Measurement conditions and event detection','Saved measurement-thinning sensitivity; original intervals')
markers=['o','s','^','v','D'];modes=['first_per_calendar_day','odd_calendar_days','even_calendar_days','calendar_days1_2_only','calendar_day1_only'];short=['First/day','Odd days','Even days','Days 1–2','Day 1']
for pidx,(pop,c) in enumerate([('all_observed_records',SL),('geography_low_risk6',OR)]):
 for k,mode in enumerate(modes):
  r=one(deletion,population=pop,mode=mode);x=r.deleted_fraction*100;y=r.lost_known_fraction*100
  ax.errorbar(x,y,xerr=[[x-r.deleted_fraction_lo*100],[r.deleted_fraction_hi*100-x]],yerr=[[y-r.lost_known_fraction_lo*100],[r.lost_known_fraction_hi*100-y]],fmt=markers[k],color=c,ms=3.5,mfc=c if pidx==0 else 'white',capsize=0,lw=.75,label=('All records · 59 events' if pidx==0 else 'Source low-risk · 11 events') if k==0 else None)
  if pidx==0:
   dx,dy=[(5,-10),(4,-10),(-6,-17),(-12,12),(5,-8)][k]
   ax.annotate(short[k],(x,y),xytext=(dx,dy),textcoords='offset points',fontsize=7,ha='right' if dx<0 else 'left')
  rec(5,'D',pop+':'+mode,'MIMIC_DELETION_SENSITIVITY:lost_known_fraction',r.lost_known_fraction,r.lost_known_fraction_lo,r.lost_known_fraction_hi)
ax.set(xlim=(0,95),ylim=(-3,85),xlabel='Recorded SCr measurements removed, %',ylabel='Known recorded events no longer detected, %')
ax.legend(loc='upper left',fontsize=7)
f.text(.12,.027,'SCr endpoints follow the calendar-window definition. Thinning reuses observed tests;\nits lost-event fractions do not estimate the safety of stopping clinical monitoring.',fontsize=7.3,linespacing=1.4)
save(f,a,5,'MIMIC clinical transport, review burden and measurement-sensitive event ascertainment')
if os.environ.get('AKI_EXPORT_ONLY','') and (W/'review/COMPOSITE_MAIN_FIGURES.json').exists():
 old=json.loads((W/'review/COMPOSITE_MAIN_FIGURES.json').read_text())['figures'];updated={x['figure']:x for x in old};updated.update({x['figure']:x for x in manifest});manifest=[updated[f'Figure_{i}'] for i in range(1,6)]
(W/'review/COMPOSITE_MAIN_FIGURES.json').write_text(json.dumps(dict(figures=manifest,source_csvs=inputs,ledger=ledger,panels=20,new_fits=0,new_bootstrap=0,cost_law_order=laws),indent=2))
print('COMPLETED_5_MAIN_FIGURES_20_PANELS')

