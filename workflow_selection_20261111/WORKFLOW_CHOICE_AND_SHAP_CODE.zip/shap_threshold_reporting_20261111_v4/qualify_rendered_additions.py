
from pathlib import Path
import pymupdf as fitz,json
W=Path(__file__).resolve().parents[1];P=W/'package'
d=fitz.open(P/'01_Journal_files/SUPPLEMENT_1.pdf');pages=[]
for i,p in enumerate(d):
 text=p.get_text()
 if 'Mean absolute SHAP' in text or '38-input acquisition / review effort' in text:
  spans=[s for b in p.get_text('dict')['blocks'] for line in b.get('lines',[]) for s in line.get('spans',[]) if s['text'].strip()]
  # Plot geometry ends above700pt. The page-number footer is a separate document element.
  plot=[s for s in spans if s['bbox'][1]<700 and abs(s['size']-10)<.03]
  assert plot and all('Arial' in s['font'] for s in plot),(i+1,plot)
  output=W/'review'/f'NEW_SUPPLEMENT_PAGE_{i+1}.png'
  p.get_pixmap(matrix=fitz.Matrix(1,1)).save(output)
  pages.append(dict(page=i+1,Arial10_plot_spans=len(plot),preview=str(output)))
assert len(pages)==4,pages
result=dict(status='PASS_FINAL_WORD_RENDERED_SHAP_AND_RESOURCE_MAPS',supplement_total_pages=len(d),new_native_pages=pages)
(W/'review/NEW_GRAPHICS_PDF_QUALIFICATION.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result))

