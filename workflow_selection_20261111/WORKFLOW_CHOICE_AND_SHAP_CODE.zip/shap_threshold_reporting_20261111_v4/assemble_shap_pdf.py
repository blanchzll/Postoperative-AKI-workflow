from pathlib import Path
import json,hashlib
import pymupdf as fitz
W=Path(__file__).resolve().parents[1];P=W/'package';F=P/'05_Figure_assets'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
manifest=F/'JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json';meta=json.loads(manifest.read_text())
pages=[x for x in meta['pages'] if x['figure']=='eFigure_25']
combined=fitz.open()
for page in pages:
 d=fitz.open(F/'JNO_VECTOR_PAGES'/page['pdf'])
 spans=[s for b in d[0].get_text('dict')['blocks'] for l in b.get('lines',[]) for s in l.get('spans',[]) if s['text'].strip()]
 assert min(s['size'] for s in spans)>=9.98
 assert all('Arial' in s['font'] for s in spans)
 assert all(s['bbox'][0]>=0 and s['bbox'][2]<=d[0].rect.width+.5 for s in spans)
 combined.insert_pdf(d);d.close()
dest=F/'eFigure_25/eFigure_25.pdf';tmp=dest.with_suffix('.tmp.pdf');combined.save(tmp);combined.close();tmp.replace(dest)
entry=next(x for x in meta['figures'] if x['figure']=='eFigure_25');entry['composite_sha256']=sha(dest)
manifest.write_text(json.dumps(meta,indent=2))
idxfile=F/'FIGURE_SOURCE_INDEX.json';idx=json.loads(idxfile.read_text())
entry=next(x for x in idx if x['label']=='eFigure 25');entry['assets'][str(dest.relative_to(P))]=sha(dest)
idxfile.write_text(json.dumps(idx,indent=2))
print('SHAP_PDF_ASSEMBLED_AND_ARIAL10_VERIFIED')
