
from pathlib import Path
import json,re,csv,hashlib,zipfile,collections
from docx import Document
from docx.oxml.ns import qn
from pypdf import PdfReader
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';checks=[]
def ck(k,v,details=None):
 checks.append(dict(check=k,status='PASS' if v else 'FAIL',details=details));assert v,(k,details)
def flat(d):return '\n'.join(p.text for p in d.paragraphs)
def norm(t):
 t=re.sub(r'(?m)^\[(\d+)\]\s+',lambda m:m[1]+'. ',t)
 t=t.replace('https://doi.org/','doi:')
 t=re.sub(r'\[(\d+(?:,\d+)*)\]',lambda m:m[1],t)
 return re.sub(r'\s+','',t).replace('\u00ad','').replace('\xa0','')

# Current source to every corresponding final clean DOCX.
for source,out in [('MANUSCRIPT_EN.md','01_Journal_files/MANUSCRIPT.docx'),('COVER_LETTER.md','01_Journal_files/COVER_LETTER.docx'),('MANUSCRIPT_ZH.md','03_Author_review/MANUSCRIPT_ZH.docx')]:
 text=(S/source).read_text();d=Document(P/out);ss=flat(d)
 for i,para in enumerate(x for x in text.split('\n\n') if x.strip() and not x.strip().startswith('#') and not x.strip().startswith('|')):
  # Markdown emphasis is displayed as plain text.
  plain=para.replace('**','').strip()
  ck(source+' paragraph '+str(i)+' in Word',norm(plain) in norm(ss),None if norm(plain) in norm(ss) else plain[:100])
# Every current caption has one figure identity, one index entry and one paired Chinese counterpart.
en=(S/'FIGURE_LEGENDS.md').read_text();zh=(S/'FIGURE_LEGENDS_ZH.md').read_text()
pairs=json.loads((W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
index=json.loads((P/'05_Figure_assets/FIGURE_SOURCE_INDEX.json').read_text())
ld=flat(Document(P/'01_Journal_files/FIGURE_LEGENDS.docx'))
sd=Document(P/'01_Journal_files/SUPPLEMENT_1.docx');st=flat(sd)
entries=list(re.finditer(r'^## ((?:e)?Figure \d+)\. ([^\n]+)\n\n(.*?)(?=^## |\Z)',en,re.M|re.S))
ck('31 current English legends',len(entries)==31)
for m in entries:
 label,title,body=m[1],m[2],m[3].strip();idx=next(x for x in index if x['label']==label)
 ck(label+' source index caption matches current source',idx['caption'].strip()==body)
 ck(label+' source index title matches current source',idx['title']==label+'. '+title)
 pairkey='e'+label.split()[-1] if label.startswith('e') else int(label.split()[-1])
 ck(label+' bilingual English source matches',next(x for x in pairs if x['figure']==pairkey)['english'].strip()==body)
 # All legends are delivered in FIGURE_LEGENDS.docx; supplementary legends also reside in Supplement1.
 ck(label+' final standalone Word legend',norm(body.replace('**','')) in norm(ld))
 if label.startswith('e'):ck(label+' final supplement Word legend',norm(body.replace('**','')) in norm(st))
for m in re.finditer(r'^## (补?)图(\d+)\. ([^\n]+)\n\n(.*?)(?=^## |\Z)',zh,re.M|re.S):
 key='e'+m[2] if m[1] else int(m[2])
 ck('Chinese caption '+str(key),next(x for x in pairs if x['figure']==key)['chinese'].strip()==m[4].strip())
# Supplementary methods/results paragraphs and all their equations/values are represented in final Word.
for name in ['EMETHODS.md','ERESULTS.md']:
 for i,para in enumerate(x for x in (S/name).read_text().split('\n\n') if x.strip() and not x.strip().startswith('#')):
  ck(name+' paragraph '+str(i)+' in final supplement Word',norm(para.replace('**','')) in norm(st))
ck('source codebook reference now resolves actual CSV',(P/'02_Code_and_aggregate_data/aggregate_data/source_data/Coded9_HISTORY_CODEBOOK.csv').exists())
ck('eFigure6 scenario reference corrected','quantities are presented in eFigure 12.' in en)
ck('303 exclusions no false adult qualification','303 adult records' not in (S/'EMETHODS.md').read_text())
ck('five-decimal Brier rounding correct','0.00266 (−0.00013–0.00538)' in (S/'ERESULTS.md').read_text())
# Reference numbering is internal consistency; no new literature verification is claimed.
main=(S/'MANUSCRIPT_EN.md').read_text();front,refs=main.split('## References')
refids=list(map(int,re.findall(r'^\[(\d+)\]',refs,re.M)));ck('30 main references sequential',refids==list(range(1,31)))
cited=[]
for m in re.finditer(r'\[(\d+(?:,\d+)*)\]',front):
 for n in map(int,m[1].split(',')):
  if n not in cited:cited.append(n)
ck('first-appearance reference order',cited==refids)
# Actual Word borders, with top/bottom and header-underlining, remain editable.
for file in [P/'01_Journal_files/SUPPLEMENT_1.docx',*sorted((P/'01_Journal_files').glob('*TABLE*.docx')),P/'07_中文核对稿/两张三线表_中文核对稿.docx']:
 d=Document(file)
 for i,t in enumerate(d.tables):
  borders=t._tbl.tblPr.find(qn('w:tblBorders'))
  ck(str(file.relative_to(P))+f' table{i+1} no vertical/interior grid',
    borders is not None and all(borders.find(qn('w:'+k)) is not None and borders.find(qn('w:'+k)).get(qn('w:val'))=='nil' for k in ['left','right','insideH','insideV']))
# Read final PDFs and check corrected content survived rendering.
for path in [P/'01_Journal_files/MANUSCRIPT.pdf',P/'01_Journal_files/SUPPLEMENT_1.pdf',P/'01_Journal_files/FIGURE_LEGENDS.pdf',P/'01_Journal_files/COVER_LETTER.pdf',P/'07_中文核对稿/正文_中文核对稿.pdf']:
 r=PdfReader(path);text='\n'.join(p.extract_text() or '' for p in r.pages)
 ck(str(path.relative_to(P))+' readable final PDF',bool(text.strip()))
 if path.name=='SUPPLEMENT_1.pdf':
  ck('corrected Brier interval in final PDF',norm('0.00266 (−0.00013–0.00538)') in norm(text))
  ck('corrected record qualification in final PDF','303 adult records' not in text)
 if path.name=='COVER_LETTER.pdf':ck('current cover date in PDF','November 11, 2026' in text)
# All main figures2–4 and all supplement numeric graphic assets retain parent bytes.
B=W.parent/'targeted_panels_20261110_v3/package'
for n in [2,3,4]:
 for p in (B/f'05_Figure_assets/Figure_{n}').iterdir():
  if p.is_file():ck('unchanged '+str(p.relative_to(B)),p.read_bytes()==(P/p.relative_to(B)).read_bytes())
out=dict(status='PASS_CURRENT_TEXT_TABLE_FIGURE_AND_SUPPLEMENT_CONSISTENCY',checks=checks,count=len(checks),
scope='Current English and Chinese manuscript, abstract, key points, discussion/conclusion, all31 legends,5 main figures,26 supplementary figures,33 numbered eTables/54 physical tables,cover letter and graphical-abstract statements.',
methods='Current source-to-Word/PDF comparison, row-key source checks, table reconstruction, numerical inventories, source preservation and semantic review; no new model fits or bootstrap.',
literature_scope='Citation identity/order and unchanged existing verification records only; no new online literature audit in this task.',
source_md_hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in S.glob('*.md')},
current_document_hashes={str(p.relative_to(P)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (P/'01_Journal_files').glob('*') if p.suffix in ['.pdf','.docx']})
(W/'review/FULL_CONTENT_CONSISTENCY.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps(dict(status=out['status'],checks=len(checks))))

