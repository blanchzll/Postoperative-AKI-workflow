
from pathlib import Path
import csv,json,hashlib,re,math,zipfile,collections
from docx import Document
W=Path(__file__).resolve().parents[1];P=W/'package';B=W.parent/'targeted_panels_20261110_v3/package';S=P/'04_Editable_sources';checks=[]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def ck(label,passed):
 checks.append(dict(check=label,status='PASS' if passed else 'FAIL'));assert passed,label
# All existing statistical tables and data stay source-identical.
ck('original32 table sections unchanged',(S/'ETABLES.md').read_text().split('\n\n## eTable 33.')[0].strip()==(B/'04_Editable_sources/ETABLES.md').read_text().strip())
frozen=0
for folder in ['aggregate_data','analysis_sources','clinical_supplement_20261108_v1/results','probabilistic_resource_analysis_20261105_v1/aggregate_data']:
 for f in (B/'02_Code_and_aggregate_data'/folder).rglob('*'):
  if f.is_file():
   ck('frozen source '+str(f.relative_to(B)),(P/f.relative_to(B)).read_bytes()==f.read_bytes());frozen+=1
for i in range(1,6):
 for f in (B/f'05_Figure_assets/Figure_{i}').iterdir():
  if f.is_file():ck('main graphic '+str(f.relative_to(B)),(P/f.relative_to(B)).read_bytes()==f.read_bytes())
for i in range(1,25):
 for f in (B/f'05_Figure_assets/eFigure_{i}').rglob('*'):
  if f.is_file():ck('original supporting graphic '+str(f.relative_to(B)),(P/f.relative_to(B)).read_bytes()==f.read_bytes())
# All36SHAP bars come from the exact calibrated-probability field.
rows=list(csv.DictReader((P/'02_Code_and_aggregate_data/shap_threshold_reporting_20261111_v4/FOUR_WORKFLOW_SHAP.csv').open()))
ledger=json.loads((W/'review/SHAP_PLOT_LEDGER.json').read_text())
for bar in ledger['bars']:
 rr=[r for r in rows if r['route']==bar['route'] and r['feature']==bar['feature'] and r['scale']=='calibrated_probability']
 ck('SHAP exact key '+bar['panel']+bar['feature'],len(rr)==1 and abs(float(rr[0]['mean_absolute_SHAP'])*100-bar['percentage_points'])<1e-12)
# Verify the full resource grid's choice and interval classifications.
grid=list(csv.DictReader((W/'choice_9_27_38/STRATEGY_SELECTION_GRID.csv').open()))
for i,row in enumerate(grid):
 values={k:float(row['capture'+k]) for k in ['9','27','38'] if row['capture'+k]!=''}
 largest=max(values.values());best='+'.join(k for k,v in values.items() if v==largest)
 ck('cell point choice '+str(i),best==row['point_winner'])
 supported=[]
 for k in values:
  competitors=[c for c in values if c!=k]
  favorable=True
  for c in competitors:
   lower=row.get(k+'minus'+c+'_lo','')
   if lower=='':lower=-float(row[c+'minus'+k+'_hi'])
   else:lower=float(lower)
   favorable &= lower>0
  if competitors and favorable:supported.append(k)
 target='availability_only_9' if len(values)==1 else '+'.join(supported) if supported else 'uncertain'
 ck('cell interval classification '+str(i),target==row['supported_winner'])
# The four numeric example rows in eTable33 and Chinese table match exact stored scenarios.
table=(S/'ETABLES.md').read_text().split('## eTable 33.')[1]
for row in grid:
 if row['mode']=='calibrated' and row['budget_percent']=='20' and row['cost27']==row['cost38'] and row['cost27'] in ['0.0','0.15']:
  expected=f"| {row['line']} | {row['cost27']} | {row['cost38']} | {row['n']}/{row['events']} | {row['capture9']} | {row['capture27']} | {row['capture38']} |"
  ck('eTable33 exact scenario '+row['line']+row['cost27'],expected in table)
ck('paired workflow models distinguished from original stage systems','stage comparisons in eTable 4 use separately developed paired preoperative champions' in table)
ck('main body within3000 words',len((S/'MANUSCRIPT_EN.md').read_text().split('## Introduction\n')[1].split('## Acknowledgment')[0].split())<=3000)
ck('33 numbered eTables',re.findall(r'^## eTable (\d+)\.',(S/'ETABLES.md').read_text(),re.M)==list(map(str,range(1,34))))
ck('54 Word tables',len(Document(P/'01_Journal_files/SUPPLEMENT_1.docx').tables)==54)
ck('all41vector pages embedded',len(Document(P/'01_Journal_files/SUPPLEMENT_1.docx').inline_shapes)==41)
ck('all31bilingual legends',len(json.loads((W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text()))==31)
ck('original study code ZIP unchanged',sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip'))
# Provenance receipts describe actual recomputation from saved samples.
for folder,status in [('choice_9v38','PASS_EXISTING_DATA_DIRECT9V38_MATCHED_AND_LITERAL_REPLAY'),('choice_9_27_38','PASS_THREE_FROZEN_WORKFLOWS_MATCHED_RESOURCE_GRID')]:
 r=json.loads((W/folder/'ANALYSIS_ACCEPTANCE.json').read_text());ck(folder+' accepted',r['status']==status)
result=dict(status='PASS_CURRENT_SHAP_AND_THREE_WORKFLOW_CONTENT',checks=checks,count=len(checks),frozen_files=frozen,SHAP_bars=36,workflow_grid_rows=len(grid),new_models=0,new_bootstrap_draws=0,reused_samples_per_context=2000,original_main_and_supplement_graphics_unchanged=True)
(W/'review/SHAP_WORKFLOW_NUMERIC_VERIFICATION.json').write_text(json.dumps(result,indent=2))
print(json.dumps({k:v for k,v in result.items() if k!='checks'}))

