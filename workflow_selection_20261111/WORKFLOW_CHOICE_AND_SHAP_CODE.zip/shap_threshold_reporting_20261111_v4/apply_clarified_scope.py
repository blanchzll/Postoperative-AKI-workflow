
from pathlib import Path
import json,shutil
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources'
# The clarified user question concerns selecting information strategies by resource cost.
p=S/'ETABLES.md';s=p.read_text();assert '## eTable 33.' in s;p.write_text(s.split('\n\n## eTable 33.')[0].rstrip()+'\n')
p=S/'MANUSCRIPT_EN.md';s=p.read_text().replace('with fixed tie ordering (eTable 33).','with fixed tie ordering.');p.write_text(s)
p=S/'MANUSCRIPT_ZH.md';s=p.read_text().replace('既有复核规则、冻结风险切点及评价队列中的名单人数和事件覆盖见eTable 33。\n\n','');p.write_text(s)
p=S/'EMETHODS.md';s=p.read_text().replace('## 12. Presentation of frozen model explanations and review rules','## 12. Presentation of frozen model explanations')
a=s.index('The review-rule table combines existing operating counts');b=s.index('## eReferences',a);s=s[:a]+s[b:];p.write_text(s)
p=S/'ERESULTS.md';s=p.read_text().replace('## 20. Model contributions and existing review rules','## 20. Model contributions')
a=s.find('The twelve selected-workflow operating points in eTable 33')
assert a>=0;s=s[:a].rstrip()+'\n';p.write_text(s)
for n in ['COVER_LETTER.md','COVER_LETTER_ZH.md']:
 p=S/n;s=p.read_text().replace('33 numbered eTables','32 numbered eTables').replace('33个编号补充表','32个编号补充表');p.write_text(s)
archive=W/'review/superseded_patient_risk_table';archive.mkdir(exist_ok=True)
for p in [S/'ETABLE33_ZH.md',*list((P/'07_中文核对稿').glob('eTable33*'))]:
 if p.exists():shutil.move(str(p),archive/p.name)
# Preserve complete exploratory model-choice calculations without promoting an imprecise switching threshold.
dest=P/'02_Code_and_aggregate_data/shap_threshold_reporting_20261111_v4/direct9v38_resource_review';dest.mkdir(exist_ok=True)
for name in ['PROTOCOL_LOCK.json','BOUNDARIES.csv','COST_GRID.csv','ANALYSIS_ACCEPTANCE.json']:
 shutil.copy2(W/'choice_9v38'/name,dest/name)
disposition=dict(user_question='Resource-cost boundary for choosing9-input versus38-input workflows',
data_requirements='Existing saved predictions and original paired bootstrap weights were sufficient.',
analysis_completed=True,primary_budget=20,
geographic_equal_capture_cost_ratio=dict(estimate=.039723661485319514,lower95=-.04058721934369603,upper95=.12576962806432576),
temporal_equal_capture_cost_ratio=dict(estimate=-.02373887240356083,lower95=-.24433728981206726,upper95=.11102022940910626),
retained_article_change='SHAP presentation and descriptive model contribution results',
threshold_disposition='No universal switching cutoff stated in the manuscript. Complete exploratory calculations remain in the research archive under the user rule for wide or directionally unclear intervals.',
initial_patient_risk_cutoff_table='Superseded after clarification of the intended resource-selection question.',
new_model_fits=0,new_bootstrap_draws=0,reused_samples_per_context=2000)
(W/'review/MODEL_CHOICE_DISPOSITION.json').write_text(json.dumps(disposition,indent=2))
print('CLARIFIED_MODEL_CHOICE_SCOPE_APPLIED')

