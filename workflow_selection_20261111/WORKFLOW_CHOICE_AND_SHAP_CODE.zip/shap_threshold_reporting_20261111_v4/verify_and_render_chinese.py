from pathlib import Path
import json,re,collections,hashlib,subprocess,os,time
from docx import Document
R=Path(__file__).resolve().parents[1];P=R/'package';S=P/'04_Editable_sources';Z=P/'07_中文核对稿'
pairs=json.loads((R/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text())
def nums(s):
 # Compare every explicitly written numeric value. Translation can add digits for spelled-out English numbers.
 return collections.Counter(x.replace(',','').rstrip('.') for x in re.findall(r'\d[\d,]*(?:\.\d+)?',s))
missing=[]
for x in pairs:
 need=nums(x['english']);have=nums(x['chinese']);miss=need-have
 if miss:missing.append({'figure':x['figure'],'missing_numbers':dict(miss)})
print('NUMERIC_PARITY_MISSING',json.dumps(missing))
# Table numbers and order in each numerical cell are retained, including all intervals.
enrows=[l for l in (S/'MAIN_TABLES.md').read_text().splitlines() if l.startswith('|')]
zhrows=[l for l in (S/'MAIN_TABLES_ZH.md').read_text().splitlines() if l.startswith('|')]
assert len(enrows)==len(zhrows)
for a,b in zip(enrows,zhrows):assert nums(a)==nums(b),(a,b)
assert not missing,missing
out={'status':'PASS_CHINESE_LEGENDS_COVER_AND_EDITABLE_TABLES_SCOPE','skills':['medical-evidence-writing P19 P23 P24'],'legends':len(pairs),'all_explicit_legend_numbers_preserved':True,'all_table_row_numbers_preserved':True,'Chinese_DOCX_files':len(list(Z.glob('*.docx'))),'source_files_sha256':{n:hashlib.sha256((S/n).read_bytes()).hexdigest() for n in ['MANUSCRIPT_ZH.md','FIGURE_LEGENDS_ZH.md','COVER_LETTER_ZH.md','MAIN_TABLES_ZH.md']},'semantic_review':'Source-to-translation review of units, populations, bootstrap hierarchy, conditional analyses, null/adverse results and model identities; no patient-outcome benefit added','source_numbers_not_recomputed':True,'Chinese_companions_for_internal_author_revision':True}
(R/'review/CHINESE_COMPANIONS_VERIFICATION.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n')
files=sorted(Z.glob('*.docx'))+[P/'01_Journal_files/COVER_LETTER.docx',P/'03_Author_review/MANUSCRIPT_ZH.docx']
assert len({p.stem for p in files})==len(files)
outdir=R/'review/chinese_rendered_ascii';outdir.mkdir(exist_ok=True)
stage=R/'runtime/chinese_ascii_inputs';stage.mkdir(parents=True,exist_ok=True)
cache=R/'runtime/chinese_cache';cache.mkdir(exist_ok=True)
import shutil
mapping=[]
for i,p in enumerate(files):
 target=stage/f'CN_{i:03d}.docx';shutil.copy2(p,target);mapping.append((p,target))
(R/'review/CHINESE_RENDER_FILENAME_MAPPING.json').write_text(json.dumps([{'source':str(a),'ascii_input':str(b)} for a,b in mapping],ensure_ascii=False,indent=2))
mem=int(next(l.split()[1] for l in Path('/proc/meminfo').read_text().splitlines() if l.startswith('MemAvailable:')))*1024
assert mem>10*1024**3
args=['docker','run','--rm','--user',f'{os.getuid()}:{os.getgid()}','--memory','8g','-e','LC_ALL=C.UTF-8','-e','XDG_CACHE_HOME=/work/runtime/chinese_cache','-v',str(R)+':/work','-v',str(R/'fonts')+':/usr/share/fonts/truetype/aki_fonts:ro','--entrypoint','/usr/bin/libreoffice','codex-docx-render:20260823','-env:UserInstallation=file:///tmp/aki-chinese-final','--headless','--convert-to','pdf','--outdir','/work/review/chinese_rendered_ascii']+['/work/'+str(b.relative_to(R)) for a,b in mapping]
start=time.time();proc=subprocess.run(args,capture_output=True,text=True);(R/'review/CHINESE_RENDER.log').write_text(proc.stdout+'\nSTDERR\n'+proc.stderr);assert proc.returncode==0,(proc.returncode,proc.stderr[-1000:])
import shutil
for p,ascii_path in mapping:
 pdf=outdir/(ascii_path.stem+'.pdf');assert pdf.exists() and pdf.stat().st_size>5000,p;shutil.copy2(pdf,p.with_suffix('.pdf'))
(R/'review/CHINESE_DOCUMENT_RENDER.json').write_text(json.dumps({'status':'PASS_PDF_EXPORT','files':len(files),'MemAvailable_at_launch':mem,'seconds':time.time()-start,'container_removed_after_exit':True},indent=2)+'\n')
print(json.dumps({'status':'PASS','legend_pairs':len(pairs),'tables':2,'Chinese_Word_files':len(list(Z.glob('*.docx'))),'PDFs_rendered':len(files),'seconds':time.time()-start}))
