
from pathlib import Path
import json,csv,hashlib,re,shutil,os
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.font_manager import fontManager
from xml.etree import ElementTree as ET
W=Path(__file__).resolve().parents[1];P=W/'package';F=P/'05_Figure_assets';S=P/'04_Editable_sources'
for p in (W/'fonts').glob('Arial*.ttf'):fontManager.addfont(str(p))
mpl.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,'xtick.labelsize':10,'ytick.labelsize':10,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'xtick.direction':'out','ytick.direction':'out'})
rows=list(csv.DictReader((W/'choice_9_27_38/STRATEGY_SELECTION_GRID.csv').open()))
SL='#374E55';PU='#6A6599';OR='#DF8F44';TE='#79AF97'
dest=F/'eFigure_26';dest.mkdir(exist_ok=True);page_dir=F/'JNO_VECTOR_PAGES/pages'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pages=[]
for page_number,line in enumerate(['geography','temporal'],1):
 f=plt.figure(figsize=(170/25.4,180/25.4))
 for j,kind in enumerate(['point','support']):
  ax=f.add_axes([.14,.57-.46*j,.42,.34])
  rr=[r for r in rows if r['line']==line and r['mode']=='calibrated' and r['budget_percent']=='20']
  mat=np.full((31,31),np.nan)
  if kind=='point':
   cmap=ListedColormap([SL,PU,OR,TE]);labels=['9 inputs','27 inputs','38 inputs','Equal capture']
   for r in rr:mat[round(float(r['cost38'])*100),round(float(r['cost27'])*100)]={'9':0,'27':1,'38':2}.get(r['point_winner'],3)
  else:
   cmap=ListedColormap(['#D8DDDF',SL,'#9CA6AA']);labels=['Intervals overlap','9 favored by intervals','Only 9 affordable']
   for r in rr:mat[round(float(r['cost38'])*100),round(float(r['cost27'])*100)]={'uncertain':0,'9':1,'availability_only_9':2}[r['supported_winner']]
  ax.pcolormesh(np.arange(32)*.01-.005,np.arange(32)*.01-.005,np.ma.masked_invalid(mat),cmap=cmap,norm=BoundaryNorm(np.arange(len(labels)+1)-.5,len(labels)),shading='flat')
  ax.set(xlim=(-.005,.305),ylim=(-.005,.305),xlabel='27-input acquisition / review effort',ylabel='38-input acquisition / review effort')
  ax.set_xticks([0,.1,.2,.3]);ax.set_yticks([0,.1,.2,.3])
  ax.set_aspect('equal')
  ax.axvline(.205,color='white',ls=':',lw=.8);ax.axhline(.205,color='white',ls=':',lw=.8)
  title=('Highest observed coverage' if kind=='point' else 'Paired interval support')
  f.text(.035,.97-.46*j,chr(65+(page_number-1)*2+j)+'  '+line.title()+' · '+title,fontweight='bold',fontsize=11,va='top')
  ax.legend(handles=[Patch(facecolor=cmap(k),label=label) for k,label in enumerate(labels)],loc='upper left',bbox_to_anchor=(1.06,1.0),borderaxespad=0,frameon=False,fontsize=10,handlelength=1)
 base=page_dir/f'eFigure_26_page_{page_number:02}'
 for ext in ['pdf','svg']:f.savefig(str(base)+'.'+ext)
 f.savefig(str(base)+'.png',dpi=300);f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(f)
 namespace='http://www.w3.org/2000/svg';ET.register_namespace('',namespace);tree=ET.parse(str(base)+'.svg')
 for t in tree.findall('.//{'+namespace+'}text'):
  st=t.get('style','');m=re.search(r'(?:^|;)\s*font:\s*([^;]+)',st)
  if m:
   size=re.search(r'(\d+(?:\.\d+)?)px',m[1])[1];weight='700' if re.search(r'\b700\b|\bbold\b',m[1]) else '400'
   t.set('style',(st[:m.start()]+st[m.end():]).lstrip('; ')+'; font-family:Arial; font-size:'+size+'px; font-weight:'+weight)
 tree.write(str(base)+'.svg',encoding='utf-8',xml_declaration=True)
 pages.append(dict(figure='eFigure_26',page=page_number,svg=str(base.relative_to(page_dir.parent))+'.svg',pdf=str(base.relative_to(page_dir.parent))+'.pdf',png=str(base.relative_to(page_dir.parent))+'.png',width_mm=170,height_mm=180,panels=[chr(65+(page_number-1)*2),chr(66+(page_number-1)*2)],font_family='Arial',minimum_text_pt=10,pdf_sha256=sha(Path(str(base)+'.pdf')),svg_sha256=sha(Path(str(base)+'.svg')),png_sha256=sha(Path(str(base)+'.png'))))
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(str(base)+'.'+ext,dest/(base.name+'.'+ext))
mp=F/'JNO_VECTOR_PAGES/PAGE_AND_PANEL_MANIFEST.json';meta=json.loads(mp.read_text())
meta['pages']=[x for x in meta['pages'] if x['figure']!='eFigure_26']+pages
meta['figures']=[x for x in meta['figures'] if x['figure']!='eFigure_26']+[dict(figure='eFigure_26',panels=list('ABCD'),pages=pages,composite_pdf='../eFigure_26/eFigure_26.pdf',composite_sha256=None)]
meta.update(figures_count=26,pages_count=41,panels_count=73);mp.write_text(json.dumps(meta,indent=2))
en="""A and C, Workflow with the highest observed event coverage at each pair of acquisition-cost ratios in geographic and temporal evaluation. B and D, Paired interval support for the same cells. Costs are additional effort per eligible operation relative to available nine-input information, divided by one baseline review effort. The total budget equals ceil(0.20N) review equivalents. The nested acquisition grid has 0≤a27≤a38≤0.30 in 0.01 steps, with 496 cells per evaluation. Blank lower triangles lie outside that grid. Slate, purple, and orange identify nine-, 27-, and 38-input workflows, and green identifies equal capture in the observed-coverage panels. In the interval panels, slate identifies nine-input capture above every other affordable workflow with positive lower endpoints of paired pointwise 95% difference intervals. Light gray identifies overlapping intervals. Dark gray identifies cells where only nine-input review is affordable. The dotted budget boundary separates grid coordinates through 0.20 from unaffordable additional acquisition. Populations contain 1,158 operations/72 events and 1,011/36. The three models retain their original development populations and calibrated predictions, and lists are reranked on the common paired-eligible records. Intervals reuse 2,000 original hospital-stratified patient-group samples. eTable 33 defines the selection measure and gives illustrative counts."""
zh="""A和C为地理和时间评价中，每对采集成本比下观察事件覆盖最高的流程。B和D为相同单元格的配对区间支持。成本指相对已有九项信息、为每条合格记录追加采集的工作量，除以一次基础复核工作量。总预算为ceil(0.20N)个复核当量。嵌套采集网格满足0≤a27≤a38≤0.30，步长0.01，每项评价496格。空白下三角位于该网格之外。观察覆盖图中，深灰蓝、紫色、橙色分别表示九项、27项及38项流程，绿色表示相同捕获。区间图中，深灰蓝表示九项捕获相对每条其他可负担路径的配对逐点95%差值区间下限均大于零。浅灰表示区间重叠，深灰表示只有九项复核可负担。预算虚线区分截至0.20的网格坐标及追加采集不可负担区域。地理与时间人群分别包含1,158次手术/72例事件及1,011/36。三模型保留各自原开发人群和校准预测，在共同配对合格记录中重新排序名单。区间复用原始2,000次医院分层患者组样本。eTable 33给出选择指标定义及情景数量。"""
for name,header,body in [('FIGURE_LEGENDS.md','## eFigure 26. Resource-based selection of information workflows',en),('FIGURE_LEGENDS_ZH.md','## 补图26. 按资源成本选择信息流程',zh)]:
 p=S/name;s=p.read_text();s=s.split('\n\n'+header)[0];p.write_text(s+'\n\n'+header+'\n\n'+body+'\n')
pairs=json.loads((W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').read_text());pairs=[x for x in pairs if x['figure']!='e26'];pairs.append(dict(figure='e26',english=en,chinese=zh));(W/'review/BILINGUAL_FIGURE_LEGEND_PAIRS.json').write_text(json.dumps(pairs,ensure_ascii=False,indent=2))
idxfile=F/'FIGURE_SOURCE_INDEX.json';idx=json.loads(idxfile.read_text());idx=[x for x in idx if x['label']!='eFigure 26'];idx.append(dict(label='eFigure 26',title='eFigure 26. Resource-based selection of information workflows',caption=en,panels=4,assets={str(p.relative_to(P)):sha(p) for p in dest.iterdir() if p.is_file()}));idxfile.write_text(json.dumps(idx,indent=2))
(S/'Chapters/FIGURE_LEGENDS.md').write_text((S/'FIGURE_LEGENDS.md').read_text())
print('THREE_WORKFLOW_SELECTION_MAPS_SAVED')

