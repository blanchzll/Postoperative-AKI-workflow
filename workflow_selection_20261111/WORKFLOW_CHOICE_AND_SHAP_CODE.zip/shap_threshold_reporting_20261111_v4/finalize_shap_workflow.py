
from pathlib import Path
import json,csv,hashlib,shutil,zipfile,datetime,subprocess
W=Path(__file__).resolve().parents[1];P=W/'package';B=W.parent/'targeted_panels_20261110_v3/package';C=P/'02_Code_and_aggregate_data';A=P/'03_Author_review';R=A/'Current_revision_review';R.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for name in ['FINAL_DOCUMENT_NUMERIC_VERIFICATION.json','FULL_CONTENT_CONSISTENCY.json','SHAP_WORKFLOW_NUMERIC_VERIFICATION.json','NEW_GRAPHICS_PDF_QUALIFICATION.json']:
 x=json.loads((W/'review'/name).read_text());assert x['status'].startswith('PASS')
for f in (W/'review').glob('*.json'):shutil.copy2(f,R/f.name)
for f in (P/'04_Editable_sources/Chapters').glob('*_ZH.*'):
 if f.suffix in ['.md','.docx','.pdf']:shutil.copy2(f,P/'07_中文核对稿/分章节'/f.name)
# Add publication-ready explanation and selection code to the existing aggregate release.
release=C/'shap_threshold_reporting_20261111_v4'
for file in (W/'code').glob('*.py'):
 if file.name=='integrate_shap_threshold.py':continue
 shutil.copy2(file,release/file.name)
# Keep the superseded patient-risk-cutoff extract in the task's history, outside the active release.
p=release/'EXISTING_DECISION_RULES.csv'
if p.exists():shutil.move(str(p),W/'review/superseded_patient_risk_table'/p.name)
shutil.copy2(W/'review/SHAP_PLOT_LEDGER.json',release/'SHAP_PLOT_LEDGER.json')
shutil.copy2(W/'review/SHAP_WORKFLOW_NUMERIC_VERIFICATION.json',release/'NUMERIC_VERIFICATION.json')
(release/'README_ZH.md').write_text("""# SHAP与九/27/38信息流程选择（20261111 v4）

FOUR_WORKFLOW_SHAP.csv汇总四个展示流程的原始和校准SHAP贡献。完整十流程原始来源位于相邻aggregate_data/supplement/aggregate_tables/supplement_tables/S17_explanation。eFigure25显示36项贡献，使用相同横轴、Arial10号和既有排列结果。

three_workflow_choice/保存三流程选择协议、3968行完整网格、总结及验收。选择指标Gk是在相同总预算下，相对九项基础复核的每千例事件覆盖增量。成本参数a27和a38分别代表追加信息采集/基础复核工作量。九和27项采用主术前champion，38项采用配对术毕champion；共同评价记录为地理1158/72和时间1011/36。每条路线保留原模型开发人群。十/20%预算、原始和校准概率、嵌套成本0≤a27≤a38≤.30均保留。单独9v38探索边界在direct9v38_resource_review/保留。

可用标准Python直接查询已有网格

python select_workflow.py --evaluation geography --budget20 --cost27 .15 --cost38 .15

实际参数--budget与数值之间需有空格，即--budget 20。返回观察覆盖最高路径、配对差及区间和重采样选择份额。重采样份额分母为2000次患者组样本。

compare_three_strategies.py和compare_9v38.py重用冻结预测及原始配对权重，逐次用样本展开结果检查排序事件位置。它们依赖原服务器的受限源文件，运行路径为/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/shap_threshold_reporting_20261111_v4/。模型未重新拟合，未重新生成随机抽样。图形使用既有prediction_gpu环境，PDF检验使用已登记PyMuPDF环境，文档沿用document-rebuild环境。本包不分发受限患者文件或授权字体。

当前文档源位于04_Editable_sources。build_current_documents.py、build_chinese_companions.py、build_threshold_chinese.py与build_track_changes.py重建当前文章和中文核对稿，render_current_documents.py及verify_and_render_chinese.py生成PDF。图的代码为draw_shap.py和draw_workflow_maps.py，两个assemble脚本在PDF环境中组装。引用、完整参数和源哈希由验收文件保留。

本次代码和全部网格随投稿包交付。GitHub既有公开分析代码的提交记录及本次更新状态见相邻CODE_AVAILABILITY.md和GITHUB_UPDATE_STATUS.json。
""".replace('--budget20','--budget 20').replace('实际参数--budget与数值之间需有空格，即--budget 20。',''))
# Demonstrate the delivered entry point using its default relative data path.
query=subprocess.run(['python3',str(release/'select_workflow.py'),'--evaluation','geography','--budget','20','--cost27','.15','--cost38','.15'],capture_output=True,text=True,check=True)
assert json.loads(query.stdout)['supported_winner']=='9'
(W/'review/SELECTOR_ENTRYPOINT_VERIFICATION.json').write_text(json.dumps(dict(status='PASS',entrypoint=str(release/'select_workflow.py'),scenario=dict(evaluation='geography',budget=20,cost27=.15,cost38=.15),result=json.loads(query.stdout)),indent=2))
shutil.copy2(W/'review/SELECTOR_ENTRYPOINT_VERIFICATION.json',R/'SELECTOR_ENTRYPOINT_VERIFICATION.json')
archive=P/'01_Journal_files/WORKFLOW_CHOICE_AND_SHAP_CODE.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for f in sorted(release.rglob('*')):
  if f.is_file():z.write(f,str(f.relative_to(C)))
assert sha(P/'01_Journal_files/ANALYSIS_CODE.zip')==sha(B/'01_Journal_files/ANALYSIS_CODE.zip')
report="""# SHAP、三流程资源选择指标及结论修订

本轮完成已有SHAP的展示，并根据用户澄清，将选择问题落实为按资源成本选择九项、27项或38项信息流程。

## 当前可用结果

选择指标Gk表示相同总预算下，相对九项基础复核的每1000次手术事件覆盖增量。使用q、a27与a38三个规划参数，在可用且可负担的路径中比较Gk。eFigure26展示不同成本下观察覆盖最高的流程以及配对区间支持，eTable33给出定义和示例。三种完整流程在同一配对合格患者群比较，图中分别标记只有九项可负担的情景。

20%预算、a27=a38=.15时，地理评价九/27/38项分别捕获33/13/15例，时间评价捕获20/9/9例。两条评价均有配对区间支持九项覆盖高于其他两条路径的成本区域。低成本点估计在部分情景偏向27项或38项，其区间情况一并呈现。

单独九至38项的等捕获切换边界区间较宽，没有写入正文作为统一切点。完整计算保留于代码研究记录。原先按患者风险切点整理的表格在用户澄清后归入工作历史，当前eTable33是三流程资源选择。

## 已完成文件

- eFigure25为四个选定流程的SHAP贡献，九输入显示全部字段，38输入显示前九项。36条形按校准概率贡献换算为百分点，使用共同尺度。完整十流程结果保留。
- eFigure26为四面板三流程选择图，分别显示地理/时间的观察覆盖选择和配对区间支持。
- eTable33为选择参数、Gk及四项示例。地理9/27/38家族为LR/LR/LR，时间为Voting/Voting/Voting。这里的27输入采用原术前主模型，eTable4采用另行开发的配对术前主模型，两者已明确标注。
- 正文方法、结果、讨论、结论、图注、附件及中文版本同步。正文3000词，正文5图0表，附件33个编号eTables、26幅eFigures、31条图注。两张原可编辑三线表仍保留。
- 选择指标使用说明和中文eTable33位于07_中文核对稿。select_workflow.py可直接查询完整汇总网格。
- 最终Word/PDF正文与源文本、54个物理表和41页原尺寸矢量图对应检查通过。四个新增矢量页的实际绘图字体为Arial10。原825个冻结来源文件、原5幅主图和24幅补图数据图像保持封存父版本。
- 新计算只使用已保存预测、标签和原始2000次患者组权重。全部抽样排序事件位置与按权重展开的实现一致，3968个网格选择及区间分类复核通过。
- SHAP原始方法文献已从NeurIPS官方论文页核实，并加入第10条补充参考文献。

## 结论的当前表述

For AKI risk review after gastrointestinal cancer surgery, information acquisition and patient review should share a resource budget. Expanded nine-input review achieved greater mean coverage than acquiring 27 inputs under the examined cost distributions. Additional information and operation-end reassessment should reflect acquisition effort, assessment time, and review capacity.

结论先呈现临床发现，并落到复核服务的资源配置。抽样不确定性和适用范围在对应结果、图注及局限中说明。

当前发表定位保持围绕胃肠肿瘤手术后AKI风险复核的临床队列研究。原有作者、伦理及基金真实声明仍由作者核实。未正式投稿。GitHub新增内容已准备，当前连接器写入返回403，待恢复Contents写权限后发布。
"""
(R/'SHAP_WORKFLOW_REVISION_ZH.md').write_text(report)
(P/'README_ZH.md').write_text("""# 当前投稿包（20261111 v4）

本轮新增已有SHAP解释图eFigure25、九/27/38项信息流程资源选择图eFigure26和eTable33。选择指标为相同总预算下相对九项基础复核的每1000次手术事件覆盖增量Gk，采用两个追加成本比a27、a38及复核预算q。

查看00_ADDED_WORKFLOW_FIGURES_PREVIEW.pdf可浏览四个新增图页。07_中文核对稿/三流程选择指标与使用说明.md提供参数、示例及查询方式。当前修订与核对报告在03_Author_review/Current_revision_review/SHAP_WORKFLOW_REVISION_ZH.md。

正文3000词，正文5图0表，每幅主图4面板。附件33个编号eTables、26幅补图，54个物理Word表、41个原尺寸矢量页。全部31条图注及中英文稿已同步。两张原三线表仍位于附件，新eTable33另有中文核对文件。

英文投稿文件在01_Journal_files，图的PDF/SVG/PNG/TIFF在05_Figure_assets。完整原代码、SHAP和三流程选择代码及汇总数据在02_Code_and_aggregate_data。旧验收归于Historical目录。作者真实声明待核实，未正式投稿。
""")
(A/'README_ZH.md').write_text('当前核对入口为Current_revision_review/SHAP_WORKFLOW_REVISION_ZH.md。源数字、图文一致性和完整三流程网格的核对明细同目录提供。上一轮完整核对报告位于Historical_before_SHAP_threshold_20261111_v4/Prior_current_revision_review。\n')
p=C/'CODE_AVAILABILITY.md';s=p.read_text().split('\n\n## 20261111 SHAP and resource-based workflow selection')[0]+'\n\n## 20261111 SHAP and resource-based workflow selection\nThe new presentation and matched three-workflow resource calculations are in shap_threshold_reporting_20261111_v4/ and WORKFLOW_CHOICE_AND_SHAP_CODE.zip. All original development and accepted analysis code is retained. New functions reuse frozen predictions and the original2000 paired-context bootstrap weights. The publication attempt returned GitHub API403 Resource not accessible by integration. The prepared update and its verification record accompany this package.\n';p.write_text(s)
for file in ['SHAP_WORKFLOW_NUMERIC_VERIFICATION.json','FULL_CONTENT_CONSISTENCY.json','FINAL_DOCUMENT_NUMERIC_VERIFICATION.json','NEW_GRAPHICS_PDF_QUALIFICATION.json']:
 shutil.copy2(W/'review'/file,R/file)
accept=dict(status='PASS_SHAP_AND_THREE_WORKFLOW_SELECTION_REVISION',utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),parent=str(B),main_words=3000,main_figures=5,main_tables=0,supplement_figures=26,numbered_eTables=33,physical_Word_tables=54,native_supplement_pages=41,bilingual_legends=31,SHAP_bars=36,three_workflow_grid_rows=3968,new_model_fits=0,new_random_bootstrap_draws=0,reused_patient_group_samples_per_context=2000,frozen_sources_preserved=825,document_checks=95,content_checks=604,report='03_Author_review/Current_revision_review/SHAP_WORKFLOW_REVISION_ZH.md',authors_confirmed=False,formal_submission=False,
current_files={str(f.relative_to(P)):sha(f) for f in (P/'01_Journal_files').rglob('*') if f.is_file()})
(P/'FINAL_REVISION_ACCEPTANCE.json').write_text(json.dumps(accept,indent=2))
(P/'REVISION_STATUS.json').write_text(json.dumps(dict(status=accept['status'],author_review_required=True,formal_submission=False),indent=2))
# The final manifest and seal are generated after the added-figure preview is assembled.
print('FINAL_PACKAGE_CONTENT_READY')

