
from pathlib import Path
import json,csv,re,shutil
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources';C=P/'02_Code_and_aggregate_data'
D=W/'choice_9_27_38'
dest=C/'shap_threshold_reporting_20261111_v4/three_workflow_choice';dest.mkdir(exist_ok=True)
for n in ['PROTOCOL_LOCK.json','STRATEGY_SELECTION_GRID.csv','SUMMARY.json','ANALYSIS_ACCEPTANCE.json']:shutil.copy2(D/n,dest/n)
grid=list(csv.DictReader((D/'STRATEGY_SELECTION_GRID.csv').open()))
text="""\n\n## eTable 33. Resource-based selection among three information workflows

### Selection parameters and measure

| Quantity | Definition | Planning interpretation |
| --- | --- | --- |
| q | Total budget as a fraction of N baseline record reviews | K=ceil(qN) review equivalents |
| a27 | Incremental acquisition effort for 27 inputs relative to available nine inputs, divided by one baseline review effort | Resources spent on every eligible operation before reviewing records |
| a38 | Corresponding incremental effort for the 38-input operation-end workflow | Nested acquisition scenarios satisfy 0≤a27≤a38 |
| Gk | 1,000 times the difference between workflow k capture after acquisition spending and nine-input capture at K | Additional recorded events captured per 1,000 operations at the same total budget |

For k in {9,27,38}, a9=0 and Gk=1,000{Ck[floor(K−Nak)]−C9(K)}/N. An acquisition path is available when Nak≤K. The highest Gk identifies the observed-coverage choice among available paths, with ties retained. The maps also show where the paired pointwise 95% intervals favor a workflow over every other available path. This comparison supports service-level choice of information pathway and assessment time.

### Illustrative existing-data scenarios at a 20% budget

| Evaluation | a27 | a38 | N/events | Capture, nine inputs | Capture, 27 inputs | Capture, 38 inputs | Highest observed capture | Paired interval support |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
"""
for r in grid:
 if r['mode']=='calibrated' and r['budget_percent']=='20' and r['cost27']==r['cost38'] and r['cost27'] in ['0.0','0.15']:
  text+=f"| {r['line']} | {r['cost27']} | {r['cost38']} | {r['n']}/{r['events']} | {r['capture9']} | {r['capture27']} | {r['capture38']} | {r['point_winner']} inputs | "+('Nine inputs' if r['supported_winner']=='9' else 'Intervals overlap')+" |\n"
text+="\nAll three workflows use identical paired-eligible evaluation records within each source line. Nine- and 27-input predictions come from the primary preoperative champions, and 38-input predictions come from the paired operation-end champion. Rankings and capacity lists are reconstructed within this common population. Consequently, the geographic nine-input list captures 33 events here, compared with 32 in the complete 1,159-operation preoperative evaluation. Each input set retains its original development and calibration. Complete results cover two source lines, raw and calibrated views, 10% and 20% budgets, and 496 nested cost pairs per configuration. Cost ratios are scenario inputs. They have no measured conversion to minutes or currency in this study. Pointwise intervals reuse the original 2,000 hospital-stratified patient-group samples.\n"
p=S/'ETABLES.md';p.write_text(p.read_text().split('\n\n## eTable 33.')[0].rstrip()+'\n'+text)
method="""\n### Resource-based choice among three workflows

Following the November 11, 2026 clarification of the service-planning question, an exploratory protocol fixed a comparison of the original nine- and 27-input preoperative champions with the 38-input operation-end champion. The same paired-eligible evaluation records were used for all three workflows, with exact outcome and patient-group alignment. Preoperative workflows retained their original, larger development populations. The comparison evaluates the complete clinical pathways and their assessment times.

Let q be the review-equivalent budget fraction, K=ceil(qN), and ak the additional acquisition effort per eligible operation relative to available nine-input information, divided by baseline review effort. We set a9=0 and examine 0≤a27≤a38≤0.30 on the existing 0.01 grid. Each available path reviews floor(K−Nak) records. Gk=1,000{Ck[floor(K−Nak)]−C9(K)}/N measures additional captured recorded events per 1,000 operations relative to nine-input review. The highest observed Gk identifies the coverage choice, retaining ties. Assessment time determines whether each information pathway can be used.

Twenty-percent budget was primary and 10% supporting. Pairwise pointwise intervals reused the original 2,000 hospital-stratified patient-group weight arrays. A supported winner required positive lower limits against every other affordable workflow. Regions with only nine-input review affordable were marked separately. Every resampled ranked-event position was checked against literal expansion of the sampled operations. The source predictions, model locks, labels, and group identities were verified before computing these functions.

"""
p=S/'EMETHODS.md'
s=p.read_text()
a=s.find('\n### Resource-based choice among three workflows')
if a>=0:
 s=s[:a]+'\n\n'+s[s.index('## eReferences',a):]
s=s.replace('## eReferences',method+'## eReferences')
p.write_text(s)
p=S/'ERESULTS.md';s=p.read_text().split('\n\n## 21. Three-workflow resource selection')[0]
s+="""\n\n## 21. Three-workflow resource selection

The matched geographic population contained 1,158 operations and 72 recorded events, and the temporal population contained 1,011 operations and 36 events. At zero additional acquisition cost and 20% capacity, geographic capture was 33, 34, and 37 events with nine, 27, and 38 inputs. Corresponding temporal counts were 20, 24, and 19. At a27=a38=0.15 review equivalents per operation, the geographic counts were 33, 13, and 15, and temporal counts were 20, 9, and 9. In this latter scenario the paired pointwise intervals favored nine-input review over both alternatives.

The complete grid contained 3,968 rows. The maps identify observed-coverage choices and the corresponding interval-support regions (eFigure 26). Nine-input review had supported regions in both source lines. Low-cost point estimates also favored 27-input or 38-input pathways in some cells, with overlapping pairwise intervals. eTable 33 supplies the parameters, measure, and illustrative scenarios. All ties, infeasible paths, and interval-overlap regions remain in the full grid. Cell counts describe the chosen scenario grid. They do not assign a probability distribution to local costs.

"""
p.write_text(s)
# Focused main-text integration and concise, clinical conclusion.
p=S/'MANUSCRIPT_EN.md';s=p.read_text()
needle='### Public-source evaluation\n\n'
s=s.replace(needle,'The three-workflow extension ranked matched-population pathways by their event-capture gain over nine-input review at equal total budget, using separate incremental costs for 27 and 38 inputs (eTable 33).\n\n'+needle)
needle='### Public-source transport and threshold burden\n\n'
s=s.replace(needle,'Paired intervals favored nine-input review over both alternatives in parts of the three-workflow cost grid. Observed-coverage choices across costs are shown in eFigure 26 and eTable 33.\n\n'+needle)
start=s.index('Center 1 contributed');end=s.index('\n\n### Input reduction',start)
s=s[:start]+'Renal-data and paired-field eligibility varied by center (eTable 2). Body mass index, ASA category, and tumor-site detail were missing in 35.5%, 34.6%, and 53.0% of preoperative records, respectively (eTable 10).'+s[end:]
s=s.replace('Intervals were pointwise and conditional on fitted systems and observed populations; the grid provided no simultaneous guarantee.','Pointwise intervals conditioned on fitted systems and observed populations.')
start=s.index('## Conclusions\n\n');end=s.index('\n\n## Acknowledgment',start)
conclusion='For AKI risk review after gastrointestinal cancer surgery, information acquisition and patient review should share a resource budget. Expanded nine-input review achieved greater mean coverage under the examined cost distributions. Additional information and operation-end reassessment should reflect acquisition effort, assessment time, and review capacity.'
s=s[:start]+'## Conclusions\n\n'+conclusion+s[end:]
wc=len(s.split('## Introduction\n')[1].split('## Acknowledgment')[0].split())
if wc>3000:
 s=s.replace('Source Platt calibration used development cross-fitted predictions.','Source Platt calibration used cross-fitted development predictions.')
 s=s.replace('Twenty percent was principal; 10% and complete capture–review curves supported it.','Twenty percent was principal, supported by 10% capacity and capture–review curves.')
 wc=len(s.split('## Introduction\n')[1].split('## Acknowledgment')[0].split())
assert wc<=3000,wc
p.write_text(s)
p=S/'MANUSCRIPT_ZH.md';s=p.read_text()
s=s.replace('## 结果','三流程扩展在同一配对合格人群和相同总预算下，按相对九输入复核的事件捕获增量比较路径，分别考虑27项与38项输入的追加采集成本（eTable 33）。\n\n## 结果',1)
needle='### 公共来源迁移与阈值负担\n\n'
s=s.replace(needle,'三流程成本情景中，部分区域的配对区间支持九输入复核覆盖高于另外两条路径。不同成本下的观察覆盖选择见eFigure 26及eTable 33。\n\n'+needle)
start=s.index('中心1贡献');end=s.index('\n\n### 输入精简',start)
s=s[:start]+'肾脏资料与配对字段的入选覆盖随中心变化（eTable 2）。术前记录中，体质指数、ASA分级和肿瘤具体部位缺失比例分别为35.5%、34.6%和53.0%（eTable 10）。'+s[end:]
start=s.index('## 结论\n\n');end=s.index('\n\n## 致谢',start)
s=s[:start]+'## 结论\n\n胃肠肿瘤手术后的AKI风险复核，应把信息采集与患者复核纳入明确的共同资源预算。在所考察的成本分布下，扩大九项常规输入复核获得了更高平均事件覆盖。追加信息与术毕重估的选择，应结合采集负担、评估时点及复核容量。'+s[end:]
p.write_text(s)
for name in ['COVER_LETTER.md','COVER_LETTER_ZH.md']:
 p=S/name;s=p.read_text().replace('32 numbered eTables and 25 eFigures','33 numbered eTables and 26 eFigures').replace('All 30 figure legends','All 31 figure legends').replace('32个编号补充表及25幅补图','33个编号补充表及26幅补图').replace('全部30条图注','全部31条图注');p.write_text(s)
(W/'review/THREE_WORKFLOW_INTEGRATION.json').write_text(json.dumps(dict(main_words=wc,workflow_measure='Equal-total-budget additional captured events per1000 relative to9-input review',cost_coordinates=['a27','a38'],matched_zero_cost_capture=dict(geography=[33,34,37],temporal=[20,24,19]),standalone_uncertain_switch_cutoff_in_article=False,figure=26,table=33),indent=2))
print(json.dumps(dict(main_words=wc)))

