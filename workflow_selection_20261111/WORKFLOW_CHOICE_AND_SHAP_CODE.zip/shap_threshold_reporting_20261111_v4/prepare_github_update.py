
from pathlib import Path
import shutil, zipfile, json, hashlib, subprocess
W = Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/shap_threshold_reporting_20261111_v4')
P = W/'package'
C = P/'02_Code_and_aggregate_data'
U = W/'github_update'
U.mkdir(mode=0o700, exist_ok=True)
F = U/'workflow_selection_20261111'
F.mkdir(exist_ok=True)
shutil.copy2(P/'01_Journal_files/WORKFLOW_CHOICE_AND_SHAP_CODE.zip', F/'WORKFLOW_CHOICE_AND_SHAP_CODE.zip')
selector = (W/'code/select_workflow.py').read_text().replace('import json\n', 'import json\nimport io\nimport zipfile\n')
selector = selector.replace("default=Path(__file__).parent/'three_workflow_choice/STRATEGY_SELECTION_GRID.csv'", "default=Path(__file__).parent/'WORKFLOW_CHOICE_AND_SHAP_CODE.zip'")
selector = selector.replace("with args.grid.open() as source:\n    matches = [", "if args.grid.suffix == '.zip':\n    archive = zipfile.ZipFile(args.grid)\n    source = io.TextIOWrapper(archive.open('shap_threshold_reporting_20261111_v4/three_workflow_choice/STRATEGY_SELECTION_GRID.csv'), encoding='utf-8')\nelse:\n    archive = None\n    source = args.grid.open()\nwith source:\n    matches = [")
selector = selector.replace("if len(matches) != 1:", "if archive is not None:\n    archive.close()\nif len(matches) != 1:")
(F/'select_workflow.py').write_text(selector)
shutil.copy2(C/'shap_threshold_reporting_20261111_v4/FOUR_WORKFLOW_SHAP.csv', F/'FOUR_WORKFLOW_SHAP.csv')
shutil.copy2(W/'choice_9_27_38/SUMMARY.json', F/'STRATEGY_SELECTION_SUMMARY.json')
with zipfile.ZipFile(F/'PRESENTATION_CODE_20261108_10.zip', 'w', zipfile.ZIP_DEFLATED) as archive:
    for folder in ['reference_palette_revision_20261108_v1', 'numeric_consistency_audit_20261108_v1', 'figure_redesign_20261109_v1', 'composite_main_figures_20261109_v2', 'targeted_panels_and_full_audit_20261110_v3']:
        for path in sorted((C/folder).rglob('*')):
            if path.is_file() and path.suffix in ['.py', '.json', '.md'] and 'SFL_reference_records' not in str(path):
                archive.write(path, str(path.relative_to(C)))
(F/'README.md').write_text("""# Resource-based selection of AKI review workflows

This extension compares frozen nine-input and 27-input preoperative workflows with a 38-input operation-end workflow after gastrointestinal cancer surgery. All three paths are evaluated on the same paired-eligible records. Geographic evaluation contains 1158 operations/72 events and temporal evaluation 1011/36.

## Selection measure

At budget K=ceil(qN), acquisition path k reviews floor(K-Nak) operations. The additional acquisition effort ak is expressed per eligible operation relative to available nine-input information, divided by the effort of one baseline review. Gk is 1000 times the difference in captured recorded events from nine-input review at K. The nested cost region is 0<=a27<=a38<=.30 in .01 steps. The complete grid has 3968 rows across two source lines, two budgets and raw/calibrated predictions.

The query returns the highest observed coverage, paired difference intervals and interval-supported choices. Cells where only nine-input review is affordable have their own label. Cost coordinates are service-planning scenarios. Information availability depends on assessment time.

## Query an evaluated scenario

Python 3.10 or later and its standard library can query the bundled ZIP directly.

~~~sh
python workflow_selection_20261111/select_workflow.py --evaluation geography --budget 20 --cost27 .15 --cost38 .15
~~~

In this scenario, nine/27/38 inputs capture 33/13/15 geographic events at the common 20% budget. The paired intervals favor nine-input review. The corresponding temporal counts are 20/9/9.

## Files

- WORKFLOW_CHOICE_AND_SHAP_CODE.zip contains analysis, plot and document code, complete grids, protocols and numerical checks.
- PRESENTATION_CODE_20261108_10.zip supplies the preceding reference, composite-figure and numeric-alignment source updates.
- FOUR_WORKFLOW_SHAP.csv supplies full raw/calibrated importance summaries for the four displayed models.
- STRATEGY_SELECTION_SUMMARY.json gives complete observed and interval-supported region summaries.

SHAP displays reuse accepted whole-pipeline explanations. Resource functions reuse frozen predictions and the original 2000 hospital-stratified patient-group weight samples. Source-dependent analyses require authorized inputs at their documented server paths. Aggregate querying works from this public folder.

The original study code and baseline release remain at the repository root. This release follows the repository's existing copyright and access arrangements.
""")
def file_record(path):
    content = path.read_bytes()
    git_hash = hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
    return dict(path=str(path.relative_to(U)), bytes=len(content), sha256=hashlib.sha256(content).hexdigest(), git_blob_sha1=git_hash)
manifest = [file_record(path) for path in sorted(F.iterdir()) if path.is_file() and path.name != 'RELEASE_MANIFEST.json']
(F/'RELEASE_MANIFEST.json').write_text(json.dumps(dict(release='20261111_shap_and_three_workflow_choice', files=manifest), indent=2))
for line in ['geography', 'temporal']:
    result = subprocess.run(['python3', str(F/'select_workflow.py'), '--evaluation', line, '--cost27', '.15', '--cost38', '.15'], capture_output=True, text=True, check=True)
    assert json.loads(result.stdout)['supported_winner'] == '9'
for path in F.glob('*.zip'):
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None
        assert not any(Path(name).name.startswith('PRIVATE_') or Path(name).suffix in ['.npz', '.joblib', '.ttf'] for name in archive.namelist())
files = [file_record(path) for path in sorted(F.iterdir()) if path.is_file()]
(U/'UPLOAD_FILES.json').write_text(json.dumps(files, indent=2))
print(json.dumps(files))

