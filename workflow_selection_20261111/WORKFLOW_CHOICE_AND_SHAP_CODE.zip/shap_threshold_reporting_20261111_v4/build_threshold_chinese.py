
from pathlib import Path
import ast,csv,re
from docx.shared import Mm
from docx.enum.section import WD_ORIENT
W=Path(__file__).resolve().parents[1];P=W/'package';S=P/'04_Editable_sources'
helper=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/novelty_revision_20261101_v1/code/build_documents.py')
tree=ast.parse(helper.read_text());ns={};exec(compile(ast.Module(body=[x for x in tree.body if isinstance(x,(ast.Import,ast.ImportFrom,ast.FunctionDef))],type_ignores=[]),str(helper),'exec'),ns)
text="""# eTable 33. 三种信息流程的资源选择

选择参数为追加采集成本与一次基础复核成本之比。a27表示相对已有九项信息，采集27项信息的追加工作量，a38为38项术毕流程的对应工作量。总预算K=ceil(qN)，基础九项路径使用K次复核。追加路径使用floor(K−Nak)次复核。

选择指标Gk=1,000{Ck[floor(K−Nak)]−C9(K)}/N，表示相同总预算下相对九项流程的每1,000条记录事件捕获增量。取可用路径中Gk最高者并保留并列。评估时点决定信息路径是否可用。

## 20%预算的示例情景

| 评价 | a27 | a38 | 记录数/事件 | 九输入捕获 | 27输入捕获 | 38输入捕获 | 观察覆盖最高 | 配对区间支持 |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
"""
rr=list(csv.DictReader((W/'choice_9_27_38/STRATEGY_SELECTION_GRID.csv').open()))
for r in rr:
 if r['mode']=='calibrated' and r['budget_percent']=='20' and r['cost27']==r['cost38'] and r['cost27'] in ['0.0','0.15']:
  text+=f"| "+('地理' if r['line']=='geography' else '时间')+f" | {r['cost27']} | {r['cost38']} | {r['n']}/{r['events']} | {r['capture9']} | {r['capture27']} | {r['capture38']} | {r['point_winner']}项 | "+('九输入' if r['supported_winner']=='9' else '区间重叠')+" |\n"
text+="\n各评价在同一配对合格人群比较三种完整流程。地理模型家族为LR/LR/LR，时间为Voting/Voting/Voting。九项和27项采用原术前主模型，38项采用配对术毕主模型。eTable 4的阶段比较采用另行开发的配对术前模型。相同人群中重新排序后，地理九项20%名单捕获33例，完整术前1,159条记录评价中则为32例。完整网格包含两条源评价、原始和校准概率、10%及20%预算，各配置496对嵌套成本。区间复用2,000次原医院分层患者组样本。成本比对应情景参数。临床服务可依据当地信息可得性和复核资源使用该比较。\n"
(S/'ETABLE33_ZH.md').write_text(text)
Z=P/'07_中文核对稿';(Z/'eTable33_资源选择.md').write_text(text)
d=ns['style_doc']();sec=d.sections[0];sec.orientation=WD_ORIENT.LANDSCAPE;sec.page_width=Mm(297);sec.page_height=Mm(210);sec.left_margin=sec.right_margin=Mm(20)
ns['add_md'](d,text)
from jno_document_format import style_table_document
style_table_document(d);ns['write'](d,Z/'eTable33_资源选择.docx')
print('CHINESE_WORKFLOW_CHOICE_TABLE_CREATED')

