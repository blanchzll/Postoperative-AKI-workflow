
from pathlib import Path
import os,json,csv,hashlib,time,math
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd
W=Path(__file__).resolve().parents[1];D=W/'choice_9v38'
A=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/correction_runs/full_data_20261025_postslot/outputs/novelty_strengthening_20261101_v1')
protocol=json.loads((D/'PROTOCOL_LOCK.json').read_text());old=json.loads((A/'ANALYSIS_PROTOCOL_LOCK.json').read_text())
contexts=json.loads((A/'resource_comparison/CONTEXT_INPUT_AND_RESAMPLING_ACCEPTANCE.json').read_text())['contexts']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(path):
 z=pd.read_csv(path,dtype={'group_hash':str,'center':str},float_precision='round_trip')
 z['record']=z.excel_row.astype(str);assert not z.record.duplicated().any()
 return z.set_index('record',drop=False)
def event_positions(y,order,weights):
 wy=weights[order];ends=np.cumsum(wy)
 # Weighted ranked-list positions are exact expanded-record event positions.
 starts=ends-wy
 return np.concatenate([np.arange(start+1,start+w+1) for start,w,ev in zip(starts,wy,y[order]) if ev and w]) if np.any(wy*y[order]) else np.array([],int)
def quantities(y,border,xorder,w,q):
 n=int(w.sum());events=int(w@y);K=(q*n+99)//100
 bp=event_positions(y,border,w);xp=event_positions(y,xorder,w)
 captured=int(np.searchsorted(bp,K,side='right'))
 equal=int(xp[captured-1]) if captured else 0
 strict=int(xp[captured]) if captured<events else np.nan
 boundary=np.array([(K-equal)/n,(K-strict)/n if np.isfinite(strict) else np.nan])
 ks=(100*K-n*np.arange(31))//100;feasible=100*K>=n*np.arange(31)
 extra=np.searchsorted(xp,np.maximum(ks,0),side='right')
 delta=(extra-captured)*1000/n;delta[~feasible]=np.nan
 return boundary,delta,dict(n=n,events=events,baseline_reviews=K,baseline_capture=captured,extra_zero_cost_capture=int(np.searchsorted(xp,K,side='right')),extra_reviews_equal=equal,extra_reviews_strict=strict,trivial_zero_capture=captured==0)
def literal(y,order,w):
 return np.flatnonzero(np.repeat(y[order],w[order])==1)+1
rows=[];grid=[];sources=[];maxdiff=0;start=time.time()
for line in ['geography','temporal']:
 base=next(r['base'] for r in old['matrix'] if r['comparison_id']==line+'_9v27_champ')
 extra=next(r['extra_information'] for r in old['matrix'] if r['comparison_id']==line+'_27v38_champ')
 ctx=line+'_paired';weightfile=A/'resource_comparison'/(ctx+'_BOOTSTRAP_WEIGHTS_PRIVATE.npz')
 assert sha(weightfile)==contexts[ctx]['weight_file_sha256']
 z=np.load(weightfile,allow_pickle=False);weights=z['weights'].astype(int);records=z['records'].astype(str);groups=z['groups'].astype(str);y=z['y'].astype(int)
 assert len(weights)==2000
 bp=load(base['prediction']);xp=load(extra['prediction'])
 for side,pred,data in [('nine',base,bp),('38',extra,xp)]:
  assert sha(pred['prediction'])==pred['prediction_sha256']
  assert set(records).issubset(set(data.index))
  aligned=data.loc[records]
  assert np.array_equal(aligned.group_hash.to_numpy(str),groups)
  assert np.array_equal(aligned.y.to_numpy(int),y)
  sources.append(dict(line=line,side=side,prediction_sha256=sha(pred['prediction']),model_lock_sha256=sha(pred['model_lock']),source_records=len(data),matched_records=len(records)))
 bp=bp.loc[records];xp=xp.loc[records]
 for mode in ['raw','calibrated']:
  border=np.lexsort((records,groups,-bp['prob_'+mode].to_numpy(float)))
  xorder=np.lexsort((records,groups,-xp['prob_'+mode].to_numpy(float)))
  for q in [20,10]:
   point,pg,counts=quantities(y,border,xorder,np.ones(len(y),int),q)
   samples=[];gs=[]
   for w in weights:
    a,b,c=quantities(y,border,xorder,w,q);samples.append(a);gs.append(b)
    # A second implementation literally expands resampled operations and reconstructs both boundaries.
    bpos=literal(y,border,w);xpos=literal(y,xorder,w);n=int(w.sum());K=math.ceil(q*n/100);target=int(np.searchsorted(bpos,K,side='right'))
    eq=int(xpos[target-1]) if target else 0;strict=int(xpos[target]) if target<len(xpos) else np.nan
    independent=np.array([(K-eq)/n,(K-strict)/n if np.isfinite(strict) else np.nan])
    assert np.allclose(a,independent,atol=1e-14,equal_nan=True)
    for i in range(31):
     if 100*K<i*n:assert np.isnan(b[i]);continue
     k=(100*K-i*n)//100
     v=(np.searchsorted(xpos,k,side='right')-target)*1000/n
     assert abs(v-b[i])<1e-12
   samples=np.array(samples);gs=np.array(gs);lo,hi=np.nanpercentile(samples,[2.5,97.5],axis=0)
   for j,name in enumerate(['equal_capture_cost_ratio','strict_gain_cost_ratio']):
    rows.append(dict(line=line,mode=mode,budget_percent=q,boundary=name,estimate=point[j],lower95=lo[j],upper95=hi[j],valid_replicates=int(np.isfinite(samples[:,j]).sum()),**counts))
   for i in range(31):
    valid=gs[:,i][np.isfinite(gs[:,i])];low,high=np.percentile(valid,[2.5,97.5]) if len(valid) else [np.nan,np.nan]
    grid.append(dict(line=line,mode=mode,budget_percent=q,extra_cost_ratio=i/100,delta_captured_per1000=pg[i],lower95=low,upper95=high,valid_replicates=len(valid)))
for name,data in [('BOUNDARIES.csv',rows),('COST_GRID.csv',grid)]:
 with (D/name).open('w',newline='') as f:
  wr=csv.DictWriter(f,fieldnames=list(data[0]));wr.writeheader();wr.writerows(data)
receipt=dict(status='PASS_EXISTING_DATA_DIRECT9V38_MATCHED_AND_LITERAL_REPLAY',sources=sources,model_fits=0,new_bootstrap_draws=0,reused_bootstrap_samples_per_context=2000,matched_contexts=2,views=2,budgets=[20,10],grid_rows=len(grid),boundary_rows=len(rows),all_sample_boundaries_and_grid_cells_literal_reverified=True,elapsed_seconds=time.time()-start)
(D/'ANALYSIS_ACCEPTANCE.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
print('PRIMARY_BOUNDARIES',json.dumps([r for r in rows if r['mode']=='calibrated' and r['budget_percent']==20]))
print('PRIMARY_POSITIVE_GRID',json.dumps([r for r in grid if r['mode']=='calibrated' and r['budget_percent']==20 and r['lower95']>0]))

