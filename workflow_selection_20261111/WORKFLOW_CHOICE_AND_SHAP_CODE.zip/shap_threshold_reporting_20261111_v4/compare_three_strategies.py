
from pathlib import Path
import os,json,csv,hashlib,time
os.environ.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd
W=Path(__file__).resolve().parents[1];D=W/'choice_9_27_38'
A=Path('/home/lei/codex-workspaces/aki-prediction-manuscript/correction_runs/full_data_20261025_postslot/outputs/novelty_strengthening_20261101_v1')
protocol=json.loads((D/'PROTOCOL_LOCK.json').read_text())
matrix=json.loads((A/'ANALYSIS_PROTOCOL_LOCK.json').read_text())['matrix']
contexts=json.loads((A/'resource_comparison/CONTEXT_INPUT_AND_RESAMPLING_ACCEPTANCE.json').read_text())['contexts']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def load(path,records,groups,y):
 d=pd.read_csv(path,dtype={'group_hash':str},float_precision='round_trip')
 d['record']=d.excel_row.astype(str);assert not d.record.duplicated().any()
 d=d.set_index('record').loc[records]
 assert np.array_equal(d.group_hash.to_numpy(str),groups) and np.array_equal(d.y.to_numpy(int),y)
 return d
def positions(y,order,w):
 ws=w[order];end=np.cumsum(ws);start=end-ws
 p=np.concatenate([np.arange(a+1,b+1) for a,b,ev in zip(start,end,y[order]) if ev and b>a])
 expanded=np.flatnonzero(np.repeat(y[order],ws)==1)+1
 assert np.array_equal(p,expanded)
 return p
results=[];summaries=[];proof=[];start_time=time.time()
for line in ['geography','temporal']:
 item=next(r for r in matrix if r['comparison_id']==line+'_9v27_champ')
 choices=[item['base'],item['extra_information'],next(r['extra_information'] for r in matrix if r['comparison_id']==line+'_27v38_champ')]
 ctx=line+'_paired';file=A/'resource_comparison'/(ctx+'_BOOTSTRAP_WEIGHTS_PRIVATE.npz')
 assert sha(file)==contexts[ctx]['weight_file_sha256']
 z=np.load(file,allow_pickle=False);records=z['records'].astype(str);groups=z['groups'].astype(str);y=z['y'].astype(int);weights=z['weights'].astype(int)
 prediction=[]
 for k,c in zip([9,27,38],choices):
  assert sha(c['prediction'])==c['prediction_sha256']
  prediction.append(load(c['prediction'],records,groups,y))
  proof.append(dict(line=line,inputs=k,prediction_sha256=sha(c['prediction']),model_lock_sha256=sha(c['model_lock']),matched_operations=len(y),matched_events=int(y.sum())))
 for mode in ['calibrated','raw']:
  orders=[np.lexsort((records,groups,-p['prob_'+mode].to_numpy(float))) for p in prediction]
  captures={q:[] for q in [20,10]}
  for w in [np.ones(len(y),int),*weights]:
   n=int(w.sum());pos=[positions(y,o,w) for o in orders]
   for q in [20,10]:
    K=(q*n+99)//100;remaining=(100*K-n*np.arange(31))//100;valid=remaining>=0
    cell=np.array([np.full(31,np.searchsorted(pos[0],K,side='right'),float),
                   np.searchsorted(pos[1],np.maximum(remaining,0),side='right').astype(float),
                   np.searchsorted(pos[2],np.maximum(remaining,0),side='right').astype(float)])
    cell[1:,~valid]=np.nan
    captures[q].append(cell*1000/n)
  for q in [20,10]:
   data=np.array(captures[q]);point=data[0];boot=data[1:]
   n=len(y);K=(q*n+99)//100;pointcounts=np.rint(point*n/1000)
   for i in range(31):
    for j in range(i,31):
     p=point[[0,1,2],[0,i,j]]
     b=boot[:,[0,1,2],[0,i,j]]
     feasible=np.isfinite(p);best=np.nanmax(p);winners=np.flatnonzero(feasible & (abs(p-best)<1e-10))
     winner='+'.join(str([9,27,38][k]) for k in winners)
     row=dict(line=line,mode=mode,budget_percent=q,cost27=i/100,cost38=j/100,n=n,events=int(y.sum()),baseline_reviews=K,
              capture9=int(pointcounts[0,0]),capture27=int(pointcounts[1,i]) if feasible[1] else '',
              capture38=int(pointcounts[2,j]) if feasible[2] else '',point_winner=winner,feasible_models='+'.join(str([9,27,38][k]) for k in np.flatnonzero(feasible)))
     differences={}
     for a,c,label in [(1,0,'27minus9'),(2,0,'38minus9'),(2,1,'38minus27')]:
      valid=np.isfinite(b[:,a])&np.isfinite(b[:,c])
      if feasible[a] and feasible[c] and valid.any():
       v=b[valid,a]-b[valid,c];lo,hi=np.percentile(v,[2.5,97.5]);value=p[a]-p[c]
       differences[(a,c)]=(lo,hi);differences[(c,a)]=(-hi,-lo)
       row.update({label:value,label+'_lo':lo,label+'_hi':hi,label+'_valid':int(valid.sum())})
      else:row.update({label:'',label+'_lo':'',label+'_hi':'',label+'_valid':0})
     supported=[]
     for k in np.flatnonzero(feasible):
      competitors=[c for c in np.flatnonzero(feasible) if c!=k]
      if competitors and all(differences[(k,c)][0]>0 for c in competitors):supported.append(str([9,27,38][k]))
     row['supported_winner']='availability_only_9' if feasible.sum()==1 else '+'.join(supported) if supported else 'uncertain'
     maxima=np.nanmax(b,axis=1)
     for k in [0,1,2]:
      unique=np.isfinite(b[:,k]) & (abs(b[:,k]-maxima)<1e-10) & (np.sum(abs(b-maxima[:,None])<1e-10,axis=1)==1)
      row['bootstrap_unique_winner_'+str([9,27,38][k])]=float(unique.mean())
     results.append(row)
   selected=[r for r in results if r['line']==line and r['mode']==mode and r['budget_percent']==q]
   summaries.append(dict(line=line,mode=mode,budget_percent=q,cells=len(selected),point_winner_counts={k:sum(r['point_winner']==k for r in selected) for k in sorted({r['point_winner'] for r in selected})},
                         supported_counts={k:sum(r['supported_winner']==k for r in selected) for k in sorted({r['supported_winner'] for r in selected})},
                         zero_cost_captures={str(k):int(pointcounts[a,0]) for a,k in enumerate([9,27,38])}))
with (D/'STRATEGY_SELECTION_GRID.csv').open('w',newline='') as f:
 writer=csv.DictWriter(f,fieldnames=list(results[0]));writer.writeheader();writer.writerows(results)
(D/'SUMMARY.json').write_text(json.dumps(summaries,indent=2))
accept=dict(status='PASS_THREE_FROZEN_WORKFLOWS_MATCHED_RESOURCE_GRID',source_identity=proof,grid_rows=len(results),cells_per_comparison=496,paired_bootstrap_samples=2000,new_random_resamples=0,new_fits=0,
 literal_event_position_replay_for_all_samples=True,elapsed_seconds=time.time()-start_time,protocol_sha256=sha(D/'PROTOCOL_LOCK.json'))
(D/'ANALYSIS_ACCEPTANCE.json').write_text(json.dumps(accept,indent=2))
print(json.dumps(accept));print('PRIMARY',json.dumps([r for r in summaries if r['mode']=='calibrated' and r['budget_percent']==20]))

