from pathlib import Path
import argparse,json,hashlib
import pymupdf as fitz
root=Path(__file__).resolve().parents[1]
parser=argparse.ArgumentParser();parser.add_argument("--output",type=Path,default=root/"outputs")
out=parser.parse_args().output.resolve()
for item in json.loads((root/"verification/SOURCE_BINDINGS.json").read_text())["inputs"]:
 assert hashlib.sha256((root/item["path"]).read_bytes()).hexdigest()==item["sha256"]
for i in range(1,6):
 with fitz.open(out/f"main/Figure_{i}.pdf") as doc:
  page=doc[0];assert abs(page.rect.width*25.4/72-171)<.01
  spans=[s for b in page.get_text("dict")["blocks"] for l in b.get("lines",[]) for s in l.get("spans",[]) if s["text"].strip()]
  assert min(s["size"] for s in spans)>7.99
  assert all("Arial" in s["font"] for s in spans)
  assert all(s["bbox"][0]>=-.5 and s["bbox"][2]<=page.rect.width+.5 for s in spans)
assert len(list((out/"supplement").glob("eFigure_*.pdf")))==26
old=json.loads((root/"reference/PAGE_AND_PANEL_MANIFEST.json").read_text())
new=json.loads((out/"native/PANEL_MANIFEST.json").read_text())
before={(x["figure"],x["panel"]):x["numeric_artist_sha256"] for x in old["panels"] if x.get("numeric_artist_sha256")}
after={(x["figure"],x["panel"]):x["numeric_artist_sha256"] for x in new["panels"]}
assert before==after and len(after)==65
print("PASS: 94 frozen inputs, 5 main figures, 26 supplements, 65 retained numeric panels, Arial>=8pt, width171mm")
