
from pathlib import Path
import os
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
RUN = Path(os.environ.get("AKI_RUN_DIR", str(ROOT / "outputs"))).resolve()
DATA = ROOT / "data"

def register_arial():
    requested = os.environ.get("AKI_FONT_DIR", "")
    directories = [Path(requested)] if requested else []
    directories += [
        Path("/System/Library/Fonts/Supplemental"),
        Path("/Library/Fonts"),
        Path.home() / "Library/Fonts",
        Path("C:/Windows/Fonts"),
    ]
    for directory in directories:
        if directory.is_dir():
            for path in directory.glob("*"):
                if path.suffix.lower() in {".ttf", ".otf", ".ttc"} and "arial" in path.name.lower():
                    font_manager.fontManager.addfont(str(path))
    try:
        regular = font_manager.findfont(font_manager.FontProperties(family="Arial"), fallback_to_default=False)
    except ValueError as error:
        raise RuntimeError("Arial was not found. Supply --font-dir with your installed Arial font directory.") from error
    return regular
