
from pathlib import Path
import json,csv,hashlib,os,re,shutil
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.font_manager import fontManager
from xml.etree import ElementTree as ET
from PIL import Image
from common import ROOT, RUN, DATA, register_arial
W=RUN;F=W/'supplement';C=DATA
register_arial()
mpl.rcParams.update({'font.family':'Arial','font.size':10,'axes.titlesize':11,'axes.labelsize':10,'xtick.labelsize':10,'ytick.labelsize':10,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'xtick.direction':'out','ytick.direction':'out','axes.linewidth':.7})
SL='#374E55';OR='#DF8F44'
rows=list(csv.DictReader((C/'shap_threshold_reporting_20261111_v4/FOUR_WORKFLOW_SHAP.csv').open()))
routes=['geography_preop_preop_compact','temporal_preop_preop_compact','geography_paired_endop_full','temporal_paired_endop_full']
titles=['Geographic nine-input preoperative model','Temporal nine-input preoperative model','Geographic 38-input operation-end model','Temporal 38-input operation-end model']
labels={'Age':'Age','Sex':'Sex','Diabetes':'Diabetes','Hypertension':'Hypertension','HeartDisease':'Other heart disease','PreopCr':'Preoperative creatinine','PreopBUN':'Urea nitrogen','PreopAlb':'Albumin','PreopHb':'Hemoglobin','PreopHospitalDays':'Preoperative hospital stay','OperationTime':'Operation duration','IntraopBloodLoss':'Blood loss','IntraopPlasma':'Plasma administration','IntraopHES':'Hydroxyethyl starch','IntraopFluid':'Fluid volume','PreopGlucose':'Glucose','PreopALT':'ALT','ASA':'ASA category','Weight':'Weight','Height':'Height','BMI':'Body mass index'}
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
page_dir=F/'pages';dest=F/'eFigure_25';dest.mkdir(exist_ok=True)
ledger=[];pages=[]
for page_number in [1,2]:
 f=plt.figure(figsize=(170/25.4,180/25.4))
 axes=[f.add_axes([.42,.59,.54,.31]),f.add_axes([.42,.12,.54,.31])]
 for j,ax in enumerate(axes):
  k=(page_number-1)*2+j;route=routes[k]
  rr=[r for r in rows if r['route']==route and r['scale']=='calibrated_probability']
  rr=sorted(rr,key=lambda r:(-float(r['mean_absolute_SHAP']),r['feature']))[:9][::-1]
  values=[100*float(r['mean_absolute_SHAP']) for r in rr]
  color=SL if k in [0,2] else OR
  ax.barh(range(9),values,height=.65,color=color)
  ax.set_yticks(range(9),[labels.get(r['feature'],r['feature']) for r in rr])
  ax.set(xlim=(0,2),ylim=(-.65,8.65),xlabel='Mean absolute SHAP, percentage points')
  ax.set_xticks([0,.5,1,1.5,2])
  # A figure-coordinate title gives the model enough space without shrinking its font.
  y=.96 if j==0 else .49
  f.text(.035,y,chr(65+k)+'  '+titles[k],fontweight='bold',fontsize=11,va='top')
  for r,value in zip(rr,values):
   ledger.append(dict(panel=chr(65+k),route=route,feature=r['feature'],mean_absolute_SHAP=float(r['mean_absolute_SHAP']),percentage_points=value,reference_rows=int(r['reference_rows']),reference_patient_groups=int(r['reference_patient_groups'])))
 base=page_dir/f'eFigure_25_page_{page_number:02}'
 for ext in ['pdf','svg']:f.savefig(str(base)+'.'+ext)
 f.savefig(str(base)+'.png',dpi=300)
 f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 plt.close(f)
 # Explicit SVG CSS is required by the existing Word renderer.
 namespace='http://www.w3.org/2000/svg';ET.register_namespace('',namespace)
 tree=ET.parse(str(base)+'.svg')
 for t in tree.findall('.//{'+namespace+'}text'):
  style=t.get('style','');match=re.search(r'(?:^|;)\s*font:\s*([^;]+)',style)
  if match:
   size=re.search(r'(\d+(?:\.\d+)?)px',match[1])[1];weight='700' if re.search(r'\b700\b|\bbold\b',match[1]) else '400'
   style=(style[:match.start()]+style[match.end():]).lstrip('; ')+'; font-family:Arial; font-size:'+size+'px; font-weight:'+weight
   t.set('style',style);t.set('font-family','Arial');t.set('font-size',size);t.set('font-weight',weight)
 tree.write(str(base)+'.svg',encoding='utf-8',xml_declaration=True)
 spec=dict(figure='eFigure_25',page=page_number,svg=str(base.relative_to(page_dir.parent))+'.svg',pdf=str(base.relative_to(page_dir.parent))+'.pdf',png=str(base.relative_to(page_dir.parent))+'.png',width_mm=170,height_mm=180,panels=[chr(65+(page_number-1)*2+i) for i in range(2)],font_family='Arial',minimum_text_pt=10.0,pdf_sha256=sha(Path(str(base)+'.pdf')),svg_sha256=sha(Path(str(base)+'.svg')),png_sha256=sha(Path(str(base)+'.png')))
 pages.append(spec)
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(str(base)+'.'+ext,dest/(base.name+'.'+ext))
(W/'review/SHAP_PAGES.json').write_text(json.dumps(dict(pages=pages,bars=ledger),indent=2))
