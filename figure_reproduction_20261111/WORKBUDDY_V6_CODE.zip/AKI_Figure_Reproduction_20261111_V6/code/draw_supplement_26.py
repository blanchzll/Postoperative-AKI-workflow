
from pathlib import Path
import json,csv,hashlib,re,shutil,os
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
from matplotlib.patches import Patch
from matplotlib.font_manager import fontManager
from xml.etree import ElementTree as ET
from common import ROOT, RUN, DATA, register_arial
W=RUN;F=W/'supplement'
register_arial()
mpl.rcParams.update({'font.family':'Arial','font.size':10,'axes.labelsize':10,'xtick.labelsize':10,'ytick.labelsize':10,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'xtick.direction':'out','ytick.direction':'out'})
rows=list(csv.DictReader((DATA/'shap_threshold_reporting_20261111_v4/three_workflow_choice/STRATEGY_SELECTION_GRID.csv').open()))
SL='#374E55';PU='#6A6599';OR='#DF8F44';TE='#79AF97'
dest=F/'eFigure_26';dest.mkdir(exist_ok=True);page_dir=F/'pages'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pages=[]
for page_number,line in enumerate(['geography','temporal'],1):
 f=plt.figure(figsize=(170/25.4,180/25.4))
 for j,kind in enumerate(['point','support']):
  ax=f.add_axes([.14,.57-.46*j,.42,.34])
  rr=[r for r in rows if r['line']==line and r['mode']=='calibrated' and r['budget_percent']=='20']
  mat=np.full((31,31),np.nan)
  if kind=='point':
   cmap=ListedColormap([SL,PU,OR,TE]);labels=['9 inputs','27 inputs','38 inputs','Equal capture']
   for r in rr:mat[round(float(r['cost38'])*100),round(float(r['cost27'])*100)]={'9':0,'27':1,'38':2}.get(r['point_winner'],3)
  else:
   cmap=ListedColormap(['#D8DDDF',SL,'#9CA6AA']);labels=['Intervals overlap','9 favored by intervals','Only 9 affordable']
   for r in rr:mat[round(float(r['cost38'])*100),round(float(r['cost27'])*100)]={'uncertain':0,'9':1,'availability_only_9':2}[r['supported_winner']]
  ax.pcolormesh(np.arange(32)*.01-.005,np.arange(32)*.01-.005,np.ma.masked_invalid(mat),cmap=cmap,norm=BoundaryNorm(np.arange(len(labels)+1)-.5,len(labels)),shading='flat')
  ax.set(xlim=(-.005,.305),ylim=(-.005,.305),xlabel='27-input acquisition / review effort',ylabel='38-input acquisition / review effort')
  ax.set_xticks([0,.1,.2,.3]);ax.set_yticks([0,.1,.2,.3])
  ax.set_aspect('equal')
  ax.axvline(.205,color='white',ls=':',lw=.8);ax.axhline(.205,color='white',ls=':',lw=.8)
  title=('Highest observed coverage' if kind=='point' else 'Paired interval support')
  f.text(.035,.97-.46*j,chr(65+(page_number-1)*2+j)+'  '+line.title()+' · '+title,fontweight='bold',fontsize=11,va='top')
  ax.legend(handles=[Patch(facecolor=cmap(k),label=label) for k,label in enumerate(labels)],loc='upper left',bbox_to_anchor=(1.06,1.0),borderaxespad=0,frameon=False,fontsize=10,handlelength=1)
 base=page_dir/f'eFigure_26_page_{page_number:02}'
 for ext in ['pdf','svg']:f.savefig(str(base)+'.'+ext)
 f.savefig(str(base)+'.png',dpi=300);f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'});plt.close(f)
 namespace='http://www.w3.org/2000/svg';ET.register_namespace('',namespace);tree=ET.parse(str(base)+'.svg')
 for t in tree.findall('.//{'+namespace+'}text'):
  st=t.get('style','');m=re.search(r'(?:^|;)\s*font:\s*([^;]+)',st)
  if m:
   size=re.search(r'(\d+(?:\.\d+)?)px',m[1])[1];weight='700' if re.search(r'\b700\b|\bbold\b',m[1]) else '400'
   t.set('style',(st[:m.start()]+st[m.end():]).lstrip('; ')+'; font-family:Arial; font-size:'+size+'px; font-weight:'+weight)
 tree.write(str(base)+'.svg',encoding='utf-8',xml_declaration=True)
 pages.append(dict(figure='eFigure_26',page=page_number,svg=str(base.relative_to(page_dir.parent))+'.svg',pdf=str(base.relative_to(page_dir.parent))+'.pdf',png=str(base.relative_to(page_dir.parent))+'.png',width_mm=170,height_mm=180,panels=[chr(65+(page_number-1)*2),chr(66+(page_number-1)*2)],font_family='Arial',minimum_text_pt=10,pdf_sha256=sha(Path(str(base)+'.pdf')),svg_sha256=sha(Path(str(base)+'.svg')),png_sha256=sha(Path(str(base)+'.png'))))
 for ext in ['pdf','svg','png','tiff']:shutil.copy2(str(base)+'.'+ext,dest/(base.name+'.'+ext))
(W/'review/WORKFLOW_PAGES.json').write_text(json.dumps(dict(pages=pages),indent=2))
