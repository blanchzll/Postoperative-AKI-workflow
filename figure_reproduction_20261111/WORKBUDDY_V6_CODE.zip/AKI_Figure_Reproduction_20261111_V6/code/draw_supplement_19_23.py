# 1. 冻结数据与统一输出：仅重绘，不重新拟合。
from pathlib import Path
import os,json,hashlib
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.font_manager import fontManager
from matplotlib.patches import FancyBboxPatch
from common import ROOT, RUN, DATA, register_arial
W=RUN; D=DATA; OUT=W/'supporting_work';OUT.mkdir(exist_ok=True)
register_arial()
mpl.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'svg.fonttype':'none','pdf.fonttype':42,'xtick.direction':'out','ytick.direction':'out','axes.spines.top':False,'axes.spines.right':False,'axes.linewidth':.6,'savefig.facecolor':'white'})
SL='#374E55';OR='#DF8F44';PU='#6A6599';GR='#C9CED1';TE='#79AF97';COL=[SL,'#8E9EA4',OR,'#EBC8A7']
cmap=LinearSegmentedColormap.from_list('clinical_diverging',[OR,'#FFFFFF',SL]);inputs={};manifest=[]
def load(rel):
 p=D/rel;inputs[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return pd.read_csv(p)
def src(name):return load('aggregate_data/source_data/'+name+'.csv')
def one(df,**kw):
 for k,v in kw.items():df=df[df[k]==v]
 assert len(df)==1,(kw,len(df));return df.iloc[0]
def canvas():
 fig,axes=plt.subplots(3,2,figsize=(183/25.4,218/25.4));fig.subplots_adjust(left=.14,right=.92,bottom=.11,top=.95,hspace=.82,wspace=.68);return fig,axes.ravel()
def title(ax,i,s):ax.set_title(chr(65+i)+'  '+s,loc='left',fontweight='bold',pad=9)
def bars(ax,labels,values,lo=None,hi=None,colors=None,xlabel='',xlim=None):
 y=np.arange(len(values));colors=colors or SL
 for i,(yy,v) in enumerate(zip(y,values)):
  color=colors[i] if isinstance(colors,list) else colors
  ax.plot(v,yy,'o',color=color,ms=3.5)
  if lo is not None:
   l=list(lo)[i];h=list(hi)[i];ax.plot([l,h],[yy,yy],color=color,lw=.8);ax.plot([l,l],[yy-.08,yy+.08],color=color,lw=.8);ax.plot([h,h],[yy-.08,yy+.08],color=color,lw=.8)
 ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel(xlabel)
 if xlim:ax.set_xlim(*xlim)
 ax.axvline(0,color='#999999',lw=.5,zorder=0)
def heat(ax,array,rows,cols,label,div=False,fmt='.1f'):
 a=np.array(array,dtype=float);maxv=100 if label=='Cost-distribution mass, %' else float(prob[['expected_regret_base_per1000','expected_regret_extra_fallback_per1000']].max().max()) if label=='Expected shortfall / 1000' else max(abs(a[np.isfinite(a)]).max(),1e-8)
 im=ax.imshow(a,aspect='auto',cmap=cmap if div else LinearSegmentedColormap.from_list('clinical_seq',['#F3F5F6',SL]),norm=TwoSlopeNorm(0,-maxv,maxv) if div else mpl.colors.Normalize(0,maxv))
 ax.set_xticks(range(len(cols)),cols,rotation=25,ha='right');ax.set_yticks(range(len(rows)),rows)
 if a.size<100:
  for (i,j),v in np.ndenumerate(a):
   if np.isfinite(v):ax.text(j,i,format(v,fmt),ha='center',va='center',fontsize=7,color='white' if (not div and v>maxv*.65) or (div and abs(v)>maxv*.7) else '#222222')
 cb=plt.colorbar(im,ax=ax,fraction=.035,pad=.025);cb.set_label(label,fontsize=6,labelpad=2);return im
def stack(ax,labels,first,second,xlabel='Events',legend=('Captured','Missed')):
 y=np.arange(len(first));ax.barh(y-.16,first,height=.30,color=SL,label=legend[0]);ax.barh(y+.16,second,height=.30,color=GR,label=legend[1]);ax.set_yticks(y,labels);ax.invert_yaxis();ax.set_xlabel(xlabel);ax.set_xlim(left=0);ax.legend(loc='upper left',bbox_to_anchor=(0,-.24),ncol=2,frameon=False,fontsize=6)
from jno_native_panels import native_export
overflow_manifest=[]
def compose(fig,selected,key,description,main=True):
 import copy,re
 f=copy.deepcopy(fig);original_axes=list(f.axes);selected_axes=[original_axes[i] for i in selected]
 cbars=[x for x in original_axes if x.get_label()=='<colorbar>' and getattr(getattr(x,'_colorbar',None),'mappable',None) is not None and x._colorbar.mappable.axes in selected_axes]
 for ax in list(f.axes):
  if ax not in selected_axes and ax not in cbars:f.delaxes(ax)
 f.set_size_inches(183/25.4,(166 if main else 120)/25.4,forward=True)
 for i,ax in enumerate(selected_axes):
  old=ax.get_position().frozen();new=mpl.transforms.Bbox.from_bounds(.15+(.46 if i%2 else 0),(.60 if i<2 else .16) if main else .30,.29,.28 if main else .56)
  linked=[c for c in cbars if c._colorbar.mappable.axes is ax]
  for c in linked:
   pos=c.get_position().frozen();c.set_position([new.x0+(pos.x0-old.x0)*new.width/old.width,new.y0+(pos.y0-old.y0)*new.height/old.height,pos.width*new.width/old.width,pos.height*new.height/old.height])
  ax.set_position(new);ax.set_title(re.sub(r'^[A-F]  ',chr(65+i)+'  ',ax.get_title(loc='left')),loc='left',fontweight='bold')
 native_export(f,key)
 base=OUT/key;f.savefig(str(base)+'.pdf');f.savefig(str(base)+'.svg');f.savefig(str(base)+'.png',dpi=300);f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 f.canvas.draw();renderer=f.canvas.get_renderer();paneldir=OUT/'panels'/key;paneldir.mkdir(parents=True,exist_ok=True)
 for oldfile in paneldir.glob('*'):oldfile.unlink()
 for i,ax in enumerate(selected_axes):
  box=ax.get_tightbbox(renderer).transformed(f.dpi_scale_trans.inverted()).expanded(1.04,1.08)
  for ext in ['pdf','svg']:f.savefig(paneldir/(key+'_'+chr(65+i)+'.'+ext),bbox_inches=box)
 record=dict(figure=key,panels=len(selected),title=description,width_mm=183,height_mm=166 if main else 120)
 (manifest if main else overflow_manifest).append(record);plt.close(f)
def save(fig,n,desc):
 maps={1:([1,2,3,4],[0,5]),2:([0,1,2,3],[4,5]),3:([0,1,4,5],[2,3]),4:([0,1,2,3],[4,5]),5:([0,2,3,5],[1,4])}
 keep,extra=maps[n]
 selected=os.environ.get('AKI_NATIVE_ONLY','')
 key='eFigure_'+str(18+n)
 if not selected or key in selected.split(','):compose(fig,extra,key,desc+' · supporting views',False)
 plt.close(fig)
pts=src('Primary_model_points');ints=src('Primary_model_intervals')
contexts=['geography_preop','temporal_preop'];labels=['Geo · 9','Geo · 27','Time · 9','Time · 27'];rs=[];mi=[]
for context in contexts:
 for mode in ['compact','full']:
  r=pts[(pts.context==context)&pts.model.str.contains('preop_'+mode+'_champion')].iloc[0];rs.append(r)
# 2. Figure 1：输入负担、性能、事件构成与容量曲线
fig,a=canvas()
title(a[0],0,'Information to collect');stack(a[0],['9 inputs','27 inputs'],[9,9],[0,18],'Predictor fields',('Routine core','Additional fields'))
for j,metric in [(1,'AUROC'),(2,'Brier')]:
 rr=[one(ints,context=r.context,model=r.model,metric=metric) for r in rs];title(a[j],j,'Discrimination' if metric=='AUROC' else 'Probability error')
 bars(a[j],labels,[r[metric] for r in rs],[r.lower95 for r in rr],[r.upper95 for r in rr],colors=COL,xlabel=metric,xlim=(0,1) if metric=='AUROC' else (0,.115))
title(a[3],3,'Captured and missed at 20%');stack(a[3],labels,[r.capacity20_captured_n for r in rs],[r.capacity20_missed_n for r in rs])
g=load('aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv');b=load('aggregate_data/novelty_extension/resource_comparison/BREAK_EVEN_BOUNDARIES.csv')
z=g[g.comparison_id.str.contains('9v27')]
title(a[4],4,'Additional capture with 27 inputs');bars(a[4],['Geographic','Temporal'],z.delta_captured_per1000,z.delta_captured_per1000_lower95,z.delta_captured_per1000_upper95,[SL,OR],'Capture difference / 1000')
title(a[5],5,'Review capacity and coverage')
for ctx,col in zip(contexts,[SL,OR]):
 d=src('Translation_'+ctx+'_CAPTURE_REVIEW_CURVE');d=d[d.model.str.contains('compact_champion')]
 a[5].plot(d.reviewed_per1000/10,d.sensitivity*100,color=col,label='Geographic' if ctx.startswith('geo') else 'Temporal')
a[5].set(xlabel='Records reviewed, %',ylabel='Events captured, %',xlim=(0,100),ylim=(0,100));a[5].legend()
save(fig,1,'Preoperative information and achieved event coverage')
# 3. Figure 2：完整情景热图与成本概率构成
grid=load('aggregate_data/novelty_extension/resource_comparison/RESOURCE_BUDGET_GRID.csv');prob=load('probabilistic_resource_analysis_20261105_v1/aggregate_data/PRIMARY_20_PERCENT_SUMMARY.csv')
ids=['geography_9v27_champ','temporal_9v27_champ','geography_27v38_champ','temporal_27v38_champ'];names=['Geo 9→27','Time 9→27','Geo 27→38','Time 27→38'];fig,a=canvas()
vmax=max(abs(grid.delta_captured_per1000.dropna()));norm=TwoSlopeNorm(0,-vmax,vmax)
for i,(cid,nm) in enumerate(zip(ids,names)):
 d=grid[(grid.comparison_id==cid)&(grid['mode']=='calibrated')].copy();d.loc[~d.feasible_at_point,'delta_captured_per1000']=np.nan
 mat=d.pivot(index='budget_percent',columns='extra_cost_per_person_review_equivalents',values='delta_captured_per1000');im=a[i].imshow(mat,aspect='auto',origin='lower',extent=[-.005,.305,2.5,32.5],cmap=cmap,norm=norm)
 a[i].set_facecolor('#EEEEEE');a[i].set(xlabel='Acquisition cost / review cost',ylabel='Total budget, %');a[i].set_xticks([0,.1,.2,.3]);title(a[i],i,nm+' · equal budget')
 # Pointwise interval excludes zero: these cell markers do not imply simultaneous inference.
 sig=d[d.feasible_at_point&((d.delta_captured_per1000_lower95>0)|(d.delta_captured_per1000_upper95<0))]
 a[i].scatter(sig.extra_cost_per_person_review_equivalents,sig.budget_percent,s=3,c='#222222')
 cb=fig.colorbar(im,ax=a[i],fraction=.035,pad=.025);cb.set_label('Δ events / 1000',fontsize=6,labelpad=2)
laws=list(prob.distribution.drop_duplicates());lawlabels=['Uniform','Low cost','High cost','Law 4','Law 5']
for j,comp in [(4,'9v27'),(5,'27v38')]:
 d=prob[prob.comparison.str.contains(comp)];d=d.assign(law_index=d.distribution.map({x:i for i,x in enumerate(laws)})).sort_values(['comparison','law_index']);labs=[('Geo ' if r.comparison.startswith('geo') else 'Time ')+str(laws.index(r.distribution)+1) for _,r in d.iterrows()];left=np.zeros(len(d))
 mat=d[['p_win','p_tie','p_loss','p_infeasible']].to_numpy()*100
 title(a[j],j,comp.replace('v','→')+' · cost-weighted choices');heat(a[j],mat,labs,['More','Equal','Fewer','Infeasible'],'Cost-distribution mass, %',False,'.1f')
save(fig,2,'Joint acquisition and review budgets across cost settings')
# 4. Figure 3：等捕获余量、原始/校准视图及加权平均
fig,a=canvas();short=['9→27 selected','27→38 selected','9→27 LR','27→38 LR','27→38 Voting','6→9 LR','INSPIRE 6→9'];keys=['9v27_champ','27v38_champ','9v27_LR','27v38_LR','27v38_Voting','6v9_LR','INSPIRE6v9']
for i,line in enumerate(['geography','temporal']):
 rr=[one(b,comparison_id=line+'_'+k,mode='calibrated',budget_percent=20) for k in keys]
 title(a[i],i,line.capitalize()+' · acquisition headroom');bars(a[i],short,[r.signed_allowable_extra_cost_per1000 for r in rr],[r.lower95 for r in rr],[r.upper95 for r in rr],SL if i==0 else OR,'Review equivalents / 1000',(-350,200))
 z=prob[prob.comparison.str.startswith(line)].copy();z=z.assign(law_index=z.distribution.map({x:i for i,x in enumerate(laws)})).sort_values(['comparison','law_index']);labs=[('9→27' if '9v27' in r.comparison else '27→38')+' · '+str(laws.index(r.distribution)+1) for _,r in z.iterrows()]
 title(a[i+2],i+2,line.capitalize()+' · decision shortfall');heat(a[i+2],z[['expected_regret_base_per1000','expected_regret_extra_fallback_per1000']],labs,['Baseline','Additional'],'Expected shortfall / 1000',False,'.1f')
title(a[4],4,'Reviews needed for equal capture')
rr=[one(b,comparison_id=cid,mode='calibrated',budget_percent=20) for cid in ids];yy=np.arange(4)
a[4].barh(yy-.16,[r.reference_reviews_n for r in rr],.3,color=GR,label='Baseline');a[4].barh(yy+.16,[r.minimum_extra_path_reviews_for_same_capture for r in rr],.3,color=PU,label='Additional path');a[4].set_yticks(yy,names);a[4].invert_yaxis();a[4].set_xlabel('Record reviews');a[4].legend(loc='upper left',bbox_to_anchor=(0,-.25),ncol=2,fontsize=6)
title(a[5],5,'Cost-weighted mean capture difference');mat=[[one(prob,comparison=cid,distribution=law).mean_delta_per1000_fallback for law in laws] for cid in ids];heat(a[5],mat,names,[str(i+1) for i in range(len(laws))],'Events / 1000',True);a[5].set_xlabel('Assigned cost law')
save(fig,3,'Equal-capture acquisition headroom and cost-weighted coverage')
# 5. Figure 4：公共来源表现、覆盖与新增病史信息
pub=src('Coded9_POINT_ESTIMATES');pi=src('Coded9_INTERVALS');cov=src('Coded9_SOURCE_THRESHOLD_COVERAGE');hist=src('Coded9_HISTORY_COUNTS');pub=pub[pub.model.str.endswith('__calibrated')];fig,a=canvas();plabs=['Geo · 6','Geo · 9','Time · 6','Time · 9']
for j,metric in [(0,'AUROC'),(1,'Brier')]:
 rr=[one(pi,model=r.model,metric=metric) for _,r in pub.iterrows()];title(a[j],j,'INSPIRE · '+metric);bars(a[j],plabs,pub[metric],[r.lower95 for r in rr],[r.upper95 for r in rr],COL,metric,(0,1) if metric=='AUROC' else (0,.115))
title(a[2],2,'Events captured at 20%');stack(a[2],plabs,pub.capacity20_captured_n,pub.capacity20_missed_n)
title(a[3],3,'Transferred sensitivity-80% cutoffs');yy=np.arange(4)
a[3].barh(yy-.17,cov.reviewed_percent,.32,color=PU,label='Reviewed');a[3].barh(yy+.17,cov.target_sensitivity_percent,.32,color=TE,label='Event coverage');a[3].set_yticks(yy,plabs);a[3].invert_yaxis();a[3].set(xlabel='Target population or events, %',xlim=(0,100));a[3].legend(loc='upper left',bbox_to_anchor=(0,-.25),ncol=2,fontsize=6)
title(a[4],4,'Target ranking and review capacity');d=src('Coded9_FULL_CAPTURE_REVIEW_CURVE')
for (model,z),col,lab in zip(d[d.model.str.endswith('__calibrated')].groupby('model',sort=False),COL,plabs):a[4].plot(z.reviewed_per1000/10,z.sensitivity*100,color=col,label=lab)
a[4].set(xlabel='Records reviewed, %',ylabel='Events captured, %',xlim=(0,100),ylim=(0,100));a[4].legend(fontsize=6)
title(a[5],5,'Released preoperative history matches');stack(a[5],hist.predictor.str.replace('HeartDisease','Other heart disease'),hist.coded_one,hist.coded_zero_no_released_prior_match,'Records',('Prior coded match','No released match'))
save(fig,4,'Public-source discrimination, event coverage and coded-history inputs')
# 6. Figure 5：临床纳入与测量、概率质量及实际复核负担
mp=load('aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv');mi=load('aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv');cut=load('aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv');fig,a=canvas()
title(a[0],0,'MIMIC qualification');a[0].axis('off')
for y,txt in [(0.85,'1,231 anatomically matched candidates'),(.56,'467 without baseline SCr; 5 without follow-up'),(.27,'759 patients · 59 SCr events')]:
 a[0].text(.5,y,txt,ha='center',va='center',fontsize=7.3,bbox=dict(facecolor='#F0F3F4',edgecolor=SL,boxstyle='square,pad=.5'),transform=a[0].transAxes)
 if y>.3:a[0].annotate('',xy=(.5,y-.19),xytext=(.5,y-.07),xycoords='axes fraction',arrowprops=dict(arrowstyle='->',color=SL))
title(a[1],1,'Preoperative input availability');stack(a[1],['Creatinine','Urea nitrogen','Albumin','Hemoglobin'],[759,726,294,719],[0,33,465,40],'Patients',('Observed','Missing'))
cal=mp[mp.model.str.endswith('__calibrated')]
rr=[one(mi,model=r.model,metric='AUROC') for _,r in cal.iterrows()];title(a[2],2,'Frozen six-input discrimination');bars(a[2],['Geographic','Temporal'],cal.AUROC,[r.lower95 for r in rr],[r.upper95 for r in rr],[SL,OR],'AUROC',(0,1))
rr=[one(mi,model=r.model,metric='Brier') for _,r in mp.iterrows()];title(a[3],3,'Probability error');bars(a[3],['Geo raw','Geo calibrated','Time raw','Time calibrated'],mp.Brier,[r.lower95 for r in rr],[r.upper95 for r in rr],COL,'Brier score',(0,.115));a[3].axvline(59/759*(1-59/759),color='#444444',ls='--',lw=.8)
rr=[one(mi,model=r.model,metric='calibration_slope') for _,r in cal.iterrows()];title(a[4],4,'Target calibration diagnostic');bars(a[4],['Geographic','Temporal'],[r.calibration_slope for _,r in cal.iterrows()],[r.lower95 for r in rr],[r.upper95 for r in rr],[SL,OR],'Calibration slope');a[4].axvline(1,color='#444444',ls='--',lw=.8)
title(a[5],5,'Fixed capacity versus transferred cutoff');rev=[];sens=[]
for line in ['geography','temporal']:
 r=one(mp,model=line+'__calibrated');rev.append(r.capacity20_reviewed_n/759*100);sens.append(r.capacity20_sensitivity*100)
 z=cut[(cut.source_line==line)&(cut.rule=='training_capacity20')];rev.append(one(z,metric='reviewed_n').estimate/759*100);sens.append(one(z,metric='sensitivity').estimate*100)
yy=np.arange(4);a[5].barh(yy-.16,rev,.3,color=PU,label='Reviewed');a[5].barh(yy+.16,sens,.3,color=TE,label='Event coverage');a[5].set_yticks(yy,['Geo target 20%','Geo source cutoff','Time target 20%','Time source cutoff']);a[5].invert_yaxis();a[5].set(xlabel='Patients or events, %',xlim=(0,100));a[5].legend(loc='upper left',bbox_to_anchor=(0,-.25),ncol=2,fontsize=6)
save(fig,5,'MIMIC eligibility, measurement availability and transferred review burden')
(W/'review/NEW_MAIN_FIGURES.json').write_text(json.dumps(dict(figures=manifest,overflow_figures=overflow_manifest,source_csvs=inputs,cost_law_order=laws,new_fits=0,new_resamples=0),indent=2))
print('RENDERED_FIVE_MAIN_FIGURES_20_PANELS_AND_FIVE_SUPPORTING_FIGURES')

