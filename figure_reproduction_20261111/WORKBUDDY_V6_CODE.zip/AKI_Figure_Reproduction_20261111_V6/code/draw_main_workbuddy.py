"""Redraw the 20 main panels from frozen aggregate tables."""
from pathlib import Path
import os,json,hashlib,textwrap
import numpy as np
import pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.patches import Rectangle
from matplotlib.lines import Line2D
from common import ROOT,RUN,DATA,register_arial
register_arial()
mpl.rcParams.update({"font.family":"Arial","font.size":8,"axes.labelsize":9,"axes.titlesize":8,"xtick.labelsize":8,"ytick.labelsize":8,"legend.fontsize":8,"legend.frameon":False,"svg.fonttype":"none","pdf.fonttype":42,"axes.spines.top":False,"axes.spines.right":False,"axes.linewidth":.75,"xtick.direction":"out","ytick.direction":"out","xtick.major.size":2.5,"ytick.major.size":2.5,"savefig.facecolor":"white","text.color":"#333333"})
BLUE="#0072B2";RED="#D55E00";GREEN="#009E73";PURPLE="#CC79A7";GRAY="#BDBDBD"
DIV=LinearSegmentedColormap.from_list("clinical",[BLUE,"#F2F2F2",RED])
ledger=[];inputs={};figures=[]
def load(name):
    candidates=list(DATA.rglob(name+".csv"))
    assert len(candidates)==1,(name,candidates)
    path=candidates[0];inputs[str(path.relative_to(DATA))]=hashlib.sha256(path.read_bytes()).hexdigest()
    return pd.read_csv(path)
def one(df,**keys):
    for k,v in keys.items():df=df[df[k]==v]
    assert len(df)==1,keys
    return df.iloc[0]
def note(fig,panel,key,value,lo=None,hi=None):
    ledger.append(dict(figure=fig,panel=panel,source=key,value=float(value),lower=None if lo is None else float(lo),upper=None if hi is None else float(hi)))
def axes(f,position):return f.add_axes(position)
def label(ax,letter,title):
    ax.set_title(title,loc="left",fontweight="normal",pad=12)
    position=ax.get_position();ax.figure.text(.02 if position.x0<.5 else .54,position.y1+.018,letter,fontsize=10,fontweight="bold")
def zero(ax):ax.axvline(0,c="#999999",ls=(0,(3,2)),lw=.7,zorder=0)
def whisker(ax,value,y,lo,hi,color,marker="o",open=False):
    ax.errorbar(value,y,xerr=[[value-lo],[hi-value]],fmt=marker,color=color,mfc="white" if open else color,ms=4,capsize=2,lw=.8)
def canvas():return plt.figure(figsize=(171/25.4,220/25.4))
def save(f,number):
    selected=os.environ.get("AKI_EXPORT_ONLY","")
    if selected and str(number) not in selected.split(","):plt.close(f);return
    for text in f.findobj(mpl.text.Text):
        if text.get_text().strip():text.set_fontsize(max(8,text.get_fontsize()))
    for text in f.texts:
        text.set_text("\n".join(textwrap.fill(line,98) for line in text.get_text().splitlines()))
    f.canvas.draw()
    dest=RUN/"main"/("Figure_"+str(number));dest.parent.mkdir(exist_ok=True)
    for ext in ["pdf","svg"]:f.savefig(str(dest)+"."+ext)
    f.savefig(str(dest)+".png",dpi=300);f.savefig(str(dest)+".tiff",dpi=600,pil_kwargs={"compression":"tiff_lzw"})
    figures.append(dict(figure="Figure_"+str(number),width_mm=171,height_mm=220,lettered_panels=4))
    plt.close(f)
pts=load("Primary_model_points");ints=load("Primary_model_intervals")
cap=load("PRIMARY_EQUAL_CAPACITY20");bounds=load("BREAK_EVEN_BOUNDARIES");grid=load("RESOURCE_BUDGET_GRID")
ids=["geography_9v27_champ","temporal_9v27_champ","geography_27v38_champ","temporal_27v38_champ"]
names=["Geo 9→27","Time 9→27","Geo 27→38","Time 27→38"]
# Figure1. Absolute values and differences refer to the same matched comparisons.
f=canvas();a=axes(f,[.08,.34,.42,.56]);label(a,"A","Matched discrimination")
groups=[
 ("geography_preop","Geographic · preoperative",BLUE,["preop_compact_champion_LR","preop_full_champion_LR"]),
 ("temporal_preop","Temporal · preoperative",RED,["preop_compact_champion_Voting","preop_full_champion_Voting"]),
 ("geography_paired","Geographic · paired stage",BLUE,["preop_full_champion_Voting","endop_full_champion_LR"]),
 ("temporal_paired","Temporal · paired stage",RED,["preop_full_champion_SGBT","endop_full_champion_Voting"])]
for j,(context,title,color,models) in enumerate(groups):
    y=10-3*j;r=one(pts,context=context,model=models[0])
    a.text(0,y+1,title+"\n"+f"({int(r.n):,} / {int(r.events)})",fontsize=8,va="bottom")
    for i,model in enumerate(models):
        p=one(pts,context=context,model=model);ci=one(ints,context=context,model=model,metric="AUROC")
        count=38 if model.startswith("endop") else 9 if "compact" in model else 27
        whisker(a,p.AUROC,y-i,ci.lower95,ci.upper95,color,"^" if count==38 else "o",count==9)
        a.text(.02,y-i+.25,str(count)+" · "+model.split("_")[-1],fontsize=8)
        a.text(1.03,y-i,f"{p.AUROC:.3f}",va="center",fontsize=8,color=color)
        note(1,"A",context+":"+model,p.AUROC,ci.lower95,ci.upper95)
a.set(xlim=(0,1.24),ylim=(-.7,12.3),xlabel="AUROC");a.set_xticks([0,.25,.5,.75,1]);a.set_yticks([]);a.spines["left"].set_visible(False);a.spines["bottom"].set_bounds(0,1)
a=axes(f,[.64,.70,.31,.20]);label(a,"B","Paired AUROC differences")
contrasts=load("Table_3_stage_and_input_differences")
for i,(context,title,color,models) in enumerate(groups):
    r=one(contrasts,model=models[1]+" MINUS "+models[0],metric="AUROC")
    whisker(a,r.estimate,3-i,r.lower95,r.upper95,color,"s" if i>1 else "o")
    a.text(0,3-i+.23,names[i],transform=a.get_yaxis_transform(),fontsize=8,va="bottom")
    a.text(0,3-i-.27,f"{r.estimate:+.3f} ({r.lower95:.3f}, {r.upper95:.3f})",transform=a.get_yaxis_transform(),fontsize=8)
    note(1,"B",models[1]+" MINUS "+models[0],r.estimate,r.lower95,r.upper95)
zero(a);a.set(xlim=(-.09,.22),ylim=(-.5,3.8),xlabel="Difference in AUROC");a.set_yticks([])
a=axes(f,[.64,.38,.31,.20]);label(a,"C","Capture and review")
for context,color in [("geography_preop",BLUE),("temporal_preop",RED)]:
    d=load("Translation_"+context+"_CAPTURE_REVIEW_CURVE")
    for kind,style in [("compact","-"),("full","--")]:
        z=d[d.model.str.contains("preop_"+kind+"_champion")].sort_values("reviewed_n")
        a.plot(z.reviewed_per1000/10,z.sensitivity*100,c=color,ls=style,drawstyle="steps-post",label=("Geo" if color==BLUE else "Time")+(" 9" if kind=="compact" else " 27"))
a.axvline(20,c="#999999",ls=":",lw=.7);a.set(xlim=(0,50),ylim=(0,100),xlabel="Records reviewed, %",ylabel="AKI events captured, %")
a.legend(ncol=2,loc="upper center",bbox_to_anchor=(.5,-.29),columnspacing=.6,handlelength=1)
a=axes(f,[.15,.085,.32,.105]);label(a,"D","20% capacity capture")
b=axes(f,[.68,.085,.27,.105])
for j,(cid,color) in enumerate(zip(ids[:2],[BLUE,RED])):
    r=one(cap,comparison_id=cid);y=1-j
    x0=r.base_captured_per1000;x1=r.extra_captured_per1000
    a.annotate("",(x1,y),(x0,y),arrowprops={"arrowstyle":"->","color":color,"lw":.8})
    a.plot(x0,y,"o",mfc="white",mec=color);a.plot(x1,y,"o",c=color)
    a.text(x0,y+.20,f"{int(r.base_captured_n)}/{int(r.events)}",fontsize=8,ha="right")
    a.text(x1,y-.28,f"{int(r.extra_captured_n)}/{int(r.events)}",fontsize=8)
    whisker(b,r.delta_captured_per1000,y,r.delta_captured_per1000_lower95,r.delta_captured_per1000_upper95,color)
    b.text(.02,y+.24,f"{r.delta_captured_per1000:+.2f} ({r.delta_captured_per1000_lower95:.2f}, {r.delta_captured_per1000_upper95:.2f})",transform=b.get_yaxis_transform(),fontsize=8)
    note(1,"D",cid,r.delta_captured_per1000,r.delta_captured_per1000_lower95,r.delta_captured_per1000_upper95)
a.set(xlim=(0,80),ylim=(-.5,1.7),xlabel="Captured events / 1,000");a.set_yticks([1,0],["Geo","Time"])
b.set(xlim=(-6,8),ylim=(-.5,1.7),xlabel="Paired difference / 1,000");b.set_yticks([]);zero(b)
save(f,1)
# Figure2. One shared signed scale and a distinct infeasibility pattern.
f=canvas();vmax=float(grid.delta_captured_per1000.abs().max());norm=TwoSlopeNorm(0,-vmax,vmax)
for i,(cid,title) in enumerate(zip(ids,names)):
    a=axes(f,[.13+.43*(i%2),.64-.43*(i//2),.31,.23]);label(a,chr(65+i),title)
    d=grid[(grid.comparison_id==cid)&(grid["mode"]=="calibrated")].copy()
    d.loc[~d.feasible_at_point,"delta_captured_per1000"]=np.nan
    m=d.pivot(index="budget_percent",columns="extra_cost_per_person_review_equivalents",values="delta_captured_per1000")
    im=a.pcolormesh(np.arange(32)*.01-.005,np.arange(7)*5+2.5,np.ma.masked_invalid(m.to_numpy()),cmap=DIV,norm=norm,shading="flat")
    for _,r in d.iterrows():
        x=r.extra_cost_per_person_review_equivalents;y=r.budget_percent
        if not r.feasible_at_point:a.add_patch(Rectangle((x-.005,y-2.5),.01,5,fc=GRAY,ec="white",hatch="///",lw=.25))
        elif any(abs(x-z)<1e-8 for z in [0,.1,.2,.3]):
            sig=r.delta_captured_per1000_lower95>0 or r.delta_captured_per1000_upper95<0
            a.text(x,y,f"{r.delta_captured_per1000:.1f}"+("*" if sig else ""),ha="center",va="center",fontsize=8,color="#333333",bbox={"fc":"white","alpha":.75,"ec":"none","pad":.1})
        elif r.delta_captured_per1000_lower95>0 or r.delta_captured_per1000_upper95<0:a.plot(x,y,".",c="#333333",ms=1.8)
    r=one(bounds,comparison_id=cid,mode="calibrated",budget_percent=20)
    if 0<=r.signed_allowable_extra_cost_per1000/1000<=.3:a.plot(r.signed_allowable_extra_cost_per1000/1000,20,"v",mfc="white",mec=PURPLE,ms=7)
    a.set(xlim=(-.014,.314),ylim=(2.5,32.5),xlabel="Acquisition / review cost",ylabel="Total budget, %");a.set_xticks([0,.1,.2,.3])
    note(2,chr(65+i),cid,r.signed_allowable_extra_cost_per1000,r.lower95,r.upper95)
cb=f.colorbar(im,cax=axes(f,[.91,.24,.015,.62]));cb.set_label("Δ captured events / 1,000")
f.text(.12,.08,"Numbers identify selected exact cells. Dot or * marks a pointwise 95% interval excluding zero.\nHatched gray cells are infeasible. Open triangles mark the 20% equal-capture allowance.",fontsize=8)
save(f,2)
# Figure3. Keep signed resource quantities on their original scale.
prob=load("PRIMARY_20_PERCENT_SUMMARY");laws=list(prob.distribution.drop_duplicates())
keys=["9v27_champ","27v38_champ","9v27_LR","27v38_LR","27v38_Voting","6v9_LR","INSPIRE6v9"]
short=["9→27 selected","27→38 selected","9→27 LR","27→38 LR","27→38 Voting","6→9 LR","INSPIRE 6→9"]
f=canvas()
for j,(line,color) in enumerate([("geography",BLUE),("temporal",RED)]):
    a=axes(f,[.22+.43*j,.66,.18,.23]);label(a,chr(65+j),"Geographic" if j==0 else "Temporal")
    for y,key in enumerate(keys):
        r=one(bounds,comparison_id=line+"_"+key,mode="calibrated",budget_percent=20)
        whisker(a,r.signed_allowable_extra_cost_per1000,y,r.lower95,r.upper95,color)
        a.text(1.05,y,f"{r.signed_allowable_extra_cost_per1000:.1f}\n({r.lower95:.1f}, {r.upper95:.1f})",transform=a.get_yaxis_transform(),va="center",fontsize=8)
        note(3,chr(65+j),line+"_"+key,r.signed_allowable_extra_cost_per1000,r.lower95,r.upper95)
    a.set(xlim=(-350,200),ylim=(6.8,-.8),xlabel="Review equivalents\nper 1,000");a.set_yticks(range(7),short if j==0 else [""]*7);a.set_xticks([-300,0,150]);zero(a)
a=axes(f,[.16,.22,.23,.23]);label(a,"C","Equal-capture review")
for i,cid in enumerate(ids):
    r=one(bounds,comparison_id=cid,mode="calibrated",budget_percent=20)
    a.plot([r.reference_reviews_n,r.minimum_extra_path_reviews_for_same_capture],[i,i],c=GRAY,lw=.7)
    a.plot(r.reference_reviews_n,i,"o",c="#777777");a.plot(r.minimum_extra_path_reviews_for_same_capture,i,"o",c=PURPLE)
    a.text(r.reference_reviews_n,i-.22,f"{int(r.reference_reviews_n)}",fontsize=8,ha="center")
    a.text(r.minimum_extra_path_reviews_for_same_capture,i+.28,f"{int(r.minimum_extra_path_reviews_for_same_capture)}",fontsize=8,ha="center")
a.set(xlim=(0,390),ylim=(3.7,-.6),xlabel="Records reviewed");a.set_yticks(range(4),names)
a.legend(handles=[Line2D([],[],marker="o",ls="",c="#777777",label="Baseline"),Line2D([],[],marker="o",ls="",c=PURPLE,label="Additional")],loc="upper left",bbox_to_anchor=(-.2,-.22))
a=axes(f,[.59,.22,.27,.23]);label(a,"D","Cost-weighted capture")
m=np.array([[one(prob,comparison=cid,distribution=law).mean_delta_per1000_fallback for law in laws] for cid in ids]);vm=float(abs(m).max())
im=a.imshow(m,cmap=DIV,norm=TwoSlopeNorm(0,-vm,vm),aspect="auto")
for (i,j),v in np.ndenumerate(m):
    a.text(j,i,f"{v:.1f}",ha="center",va="center",fontsize=8,color="white" if abs(v)>vm*.65 else "#333333")
    r=one(prob,comparison=ids[i],distribution=laws[j]);note(3,"D",ids[i]+":"+laws[j],v,r.mean_delta_per1000_fallback_patient_lower95,r.mean_delta_per1000_fallback_patient_upper95)
a.set_yticks(range(4),names);a.set_xticks(range(5),["Uniform","Low","Middle","High","Wide tail"],rotation=45,ha="right")
f.colorbar(im,cax=axes(f,[.91,.22,.015,.23])).set_label("Events / 1,000")
f.text(.12,.07,"C uses the 20% baseline budget. D shows point estimates under five specified cost laws.\nThe original paired intervals are retained in the supplementary tables.",fontsize=8)
save(f,3)
# Figure4. Separate AUROC, AP and Brier differences into metric-specific axes.
pub=load("Coded9_POINT_ESTIMATES");diff=load("Coded9_PAIRED_DIFFERENCES_VS_SIX_RF");hist=load("Coded9_HISTORY_COUNTS");cov=load("Coded9_SOURCE_THRESHOLD_COVERAGE")
cal=pub[pub.model.str.endswith("__calibrated")];models=list(cal.model)
f=canvas();a=axes(f,[.22,.70,.25,.19]);label(a,"A","Released history matches")
for i,r in hist.iterrows():
    a.hlines(i,0,r.coded_one,color=BLUE,lw=.6);a.plot(r.coded_one,i,"o",c=BLUE)
    a.text(r.coded_one+150,i,str(int(r.coded_one)),va="center",fontsize=8)
    a.text(1.0,i,f"of {int(r.n):,}\n({100*r.coded_one/r.n:.1f}%)",transform=a.get_yaxis_transform(),ha="right",va="center",fontsize=8)
a.set(xlim=(0,6500),ylim=(2.7,-.7),xlabel="Records");a.set_yticks(range(3),["Diabetes","Hypertension","Other heart\ndisease"])
for k,(metric,title,sign) in enumerate([("AUROC","Δ AUROC",1),("AP","Δ AP",1),("Brier","Brier decrease\n(× 1,000)",-1)]):
    a=axes(f,[.60+.125*k,.72,.09,.15]);a.set_title(title,fontsize=8,pad=12)
    if k==0:f.text(.54,.90,"B",fontsize=10,fontweight="bold")
    values=[]
    for j,(line,color) in enumerate([("geography",BLUE),("temporal",RED)]):
        model=diff[diff.model.str.startswith(line)&diff.model.str.contains("__calibrated")].model.iloc[0]
        r=one(diff,model=model,metric=metric);lo=min(sign*r.lower95,sign*r.upper95);hi=max(sign*r.lower95,sign*r.upper95);v=sign*r.estimate
        scale=1000 if metric=="Brier" else 1
        whisker(a,v*scale,1-j,lo*scale,hi*scale,color);values.extend([lo*scale,hi*scale]);note(4,"B",line+":"+metric,v,lo,hi)
    low=min(0,min(values));high=max(values);margin=(high-low)*.15 or .001
    a.set(xlim=(low-margin,high+margin),ylim=(-.6,1.6));a.set_yticks([1,0],["Geo","Time"] if k==0 else ["",""]);a.set_xticks([low,high]);a.xaxis.set_major_formatter(mpl.ticker.FormatStrFormatter("%.2g"));zero(a)
f.text(.59,.65,"Positive values favor coded-nine.",fontsize=8)
a=axes(f,[.15,.23,.33,.23]);label(a,"C","Target-ranked capture")
curves=load("Coded9_FULL_CAPTURE_REVIEW_CURVE");colors=[BLUE,BLUE,RED,RED]
for k,(model,color) in enumerate(zip(models,colors)):
    r=one(cal,model=model);z=curves[curves.model==model].sort_values("reviewed_n")
    a.plot(z.reviewed_per1000/10,z.sensitivity*100,c=color,ls="-" if "__six_RF__" in model else "--",drawstyle="steps-post",label=["Geo 6","Geo 9","Time 6","Time 9"][k])
a.set(xlim=(0,50),ylim=(0,100),xlabel="Records reviewed, %",ylabel="SCr events captured, %");a.axvline(20,ls=":",lw=.7,c="#999999");a.legend(ncol=2,loc="upper center",bbox_to_anchor=(.5,-.27),handlelength=1)
a=axes(f,[.65,.23,.30,.23]);label(a,"D","Transferred thresholds")
for k,(model,color) in enumerate(zip(models,colors)):
    line="geography" if model.startswith("geography") else "temporal";kind="six_RF" if "__six_RF__" in model else "coded9_LR" if line=="geography" else "coded9_Voting"
    r=one(cal,model=model);q=one(cov,source_line=line,model=kind)
    a.plot([r.capacity20_reviewed_per1000/10,q.reviewed_percent],[r.capacity20_sensitivity*100,q.target_sensitivity_percent],ls=":",c=color)
    a.plot(r.capacity20_reviewed_per1000/10,r.capacity20_sensitivity*100,"o",mfc="white",mec=color)
    a.plot(q.reviewed_percent,q.target_sensitivity_percent,"D",c=color)
    tx,ty=[(36,61),(5,109),(121,105),(62,86)][k]
    a.annotate(["Geo 6","Geo 9","Time 6","Time 9"][k]+f"\n{int(q.reviewed_n)} / {int(q.captured_n)}",(q.reviewed_percent,q.target_sensitivity_percent),xytext=(tx,ty),fontsize=8,ha="right" if k==2 else "left",arrowprops={"arrowstyle":"-","lw":.55,"color":color})
a.set(xlim=(0,125),ylim=(0,115),xlabel="Records reviewed, %",ylabel="SCr events captured, %")
f.text(.12,.06,"INSPIRE: 6,043 records / 253 events. Released coded absence is not a confirmed clinical negative.\nD labels give reviewed records / captured events. Circles: target 20%. Diamonds: transferred cutoff.",fontsize=8)
save(f,4)
# Figure5. All intervals are read from saved tables; loss intervals use Wilson bounds.
p=DATA/"aggregate_data/novelty_extension/mimic_calendar_v2"
mp=pd.read_csv(p/"POINT_ESTIMATES.csv");mi=pd.read_csv(p/"INTERVALS.csv");cut=pd.read_csv(p/"SOURCE_THRESHOLD_BURDEN.csv")
deletion=load("MIMIC_DELETION_SENSITIVITY")
f=canvas();a=axes(f,[.13,.68,.30,.21]);label(a,"A","Clinical qualification")
for i,(bottom,height,color) in enumerate(zip([0,764,759,0],[1231,467,5,759],[BLUE,GRAY,GRAY,PURPLE])):
    a.bar(i,height,bottom=bottom,color=color,width=.63)
    a.text(i,bottom+height+30,["1,231","−467","−5","759"][i],ha="center",fontsize=8)
a.set(ylim=(0,1500),ylabel="Patients");a.set_xticks(range(4),["Anatomic\ncandidates","No\nbaseline SCr","No\nfollow-up SCr","Eligible"],rotation=0,ha="center")
a.text(0,1.03,"759 patients / 59 SCr events",transform=a.transAxes,fontsize=8)
f.text(.10,.57,"Observed / 759: creatinine 759; urea nitrogen 726;\nalbumin 294; hemoglobin 719.",fontsize=8)
a=axes(f,[.64,.68,.18,.21]);label(a,"B","Probability error")
for j,(line,color) in enumerate([("geography",BLUE),("temporal",RED)]):
    for i,mode in enumerate(["raw","calibrated"]):
        r=one(mp,model=line+"__"+mode);ci=one(mi,model=line+"__"+mode,metric="Brier");y=2-i+(.23 if j==0 else -.23)
        whisker(a,r.Brier,y,ci.lower95,ci.upper95,color)
        a.text(1.04,y,f"{r.Brier:.4f}\n({ci.lower95:.4f}, {ci.upper95:.4f})",transform=a.get_yaxis_transform(),va="center",fontsize=8,color=color)
        note(5,"B",r.model,r.Brier,ci.lower95,ci.upper95)
ref=59/759*(1-59/759);a.plot(ref,0,"D",c="#777777");a.text(1.04,0,f"{ref:.4f}",transform=a.get_yaxis_transform(),fontsize=8,va="center")
a.set(xlim=(0,.115),ylim=(-.5,2.65),xlabel="Brier score");a.set_yticks([2,1,0],["Frozen raw","Source-\ncalibrated","Prevalence\nconstant"]);a.set_xticks([0,.05,.1])
for j,(line,color) in enumerate([("geography",BLUE),("temporal",RED)]):
    a=axes(f,[.12+.19*j,.24,.15,.23]);a.set_title("Geographic" if j==0 else "Temporal",fontsize=8,pad=12)
    if j==0:f.text(.02,.49,"C",fontsize=10,fontweight="bold")
    for k,(rule,marker) in enumerate([("target","o"),("training_capacity20","D"),("training_sensitivity80","^")]):
        if rule=="target":
            r=one(mp,model=line+"__calibrated");rn=r.capacity20_reviewed_n;cn=r.capacity20_captured_n
        else:
            rn=one(cut,source_line=line,rule=rule,metric="reviewed_n").estimate
            cn=one(cut,source_line=line,rule=rule,metric="captured_n").estimate
        a.plot(rn/759*100,cn/59*100,marker,c=color,mfc="white" if k==0 else color)
        a.annotate(f"{int(rn)} / {int(cn)}",(rn/759*100,cn/59*100),xytext=(3,-13 if k==0 else 7 if k==1 else -15),textcoords="offset points",fontsize=8)
        note(5,"C",line+":"+rule+":reviewed",rn);note(5,"C",line+":"+rule+":captured",cn)
    a.set(xlim=(0,110),ylim=(0,110),xlabel="Reviewed, %");a.set_xticks([0,50,100]);a.set_yticks([0,50,100])
    if j==0:a.set_ylabel("SCr events captured, %")
    else:a.set_yticklabels([])
a=axes(f,[.66,.24,.18,.23]);label(a,"D","Measurement thinning")
modes=["first_per_calendar_day","odd_calendar_days","even_calendar_days","calendar_days1_2_only","calendar_day1_only"]
for j,(population,color) in enumerate([("all_observed_records",BLUE),("geography_low_risk6",RED)]):
    for i,mode in enumerate(modes):
        r=one(deletion,population=population,mode=mode);y=4-i+(.14 if j==0 else -.14)
        whisker(a,r.lost_known_fraction*100,y,r.lost_event_Wilson_lo*100,r.lost_event_Wilson_hi*100,color,"o" if j==0 else "s",j==1)
        a.text(1.05,y,f"{int(r.lost_known_events_lower_bound)}/{int(r.original_known_events)}",transform=a.get_yaxis_transform(),va="center",fontsize=8)
        a.text(1.49,y,f"{r.deleted_fraction*100:.1f}%",transform=a.get_yaxis_transform(),va="center",fontsize=8)
        note(5,"D",population+":"+mode,r.lost_known_fraction,r.lost_event_Wilson_lo,r.lost_event_Wilson_hi)
a.set(xlim=(0,80),ylim=(-.6,4.8),xlabel="Known-event loss, %");a.set_xticks([0,20,40,60,80]);a.set_yticks(range(5),["Day 1","Days 1–2","Even days","Odd days","First/day"])
a.text(1.05,4.8,"Lost /\nknown",transform=a.get_yaxis_transform(),fontsize=8)
a.text(1.49,4.8,"Tests\nremoved",transform=a.get_yaxis_transform(),fontsize=8)
f.text(.10,.08,"C markers: circle, target 20%; diamond, source 20%; triangle, source 80% sensitivity. Labels: reviewed / captured.\nD: blue, all 759 / 59 events; red, geographic low-risk 258 / 11. Whiskers are Wilson 95% intervals.",fontsize=8)
save(f,5)
(RUN/"review/WORKBUDDY_MAIN_FIGURES.json").write_text(json.dumps(dict(figures=figures,ledger=ledger,source_hashes=inputs,new_fits=0,new_bootstrap=0),indent=2))
print("RENDERED_WORKBUDDY_MAIN_FIGURES",len(figures))
