# 1. 复用冻结数据到图形对象的映射，重构图形编码；不执行任何模型分析。
from pathlib import Path
import os,ast,json,hashlib,re,sys
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.container import ErrorbarContainer
from matplotlib.font_manager import fontManager
mpl.rcParams.update({'svg.fonttype':'none','pdf.fonttype':42})
from common import ROOT, RUN, DATA, register_arial
W=RUN;C=DATA;OUT=W/'supporting_work';OUT.mkdir(exist_ok=True);manifest=[]
register_arial()
SL='#374E55';OR='#DF8F44';PU='#6A6599'
mapping={'Figure_1_Cohorts_and_information':1,'Figure_3_Stage_gain_and_consistency':15,'Figure_4_Capture_review_capacity':6,'Figure_5_Public_threshold_transport':7,'Supplementary_Figure_1_Calibration':13,'Supplementary_Figure_2_Local_calibration':5,'Supplementary_Figure_3_POD1':9,'Supplementary_Figure_4_LLM_all24':11,'Supplementary_Figure_5_Stability':10,'Supplementary_Figure_6_Recorded_intervals':8,'Supplementary_Figure_7_ALT':3,'Supplementary_Figure_8_Allocation':4,'Supplementary_Figure_9_Loss_margin':2,'Supplementary_Figure_10_Virtual_clinical_use':12,'Supplementary_Figure_11_LR_input_bridge':14}
def theme(fig):
 for tx in fig.findobj(mpl.text.Text):
  tx.set_fontfamily('Arial')
  if tx.get_fontsize()<7.5:tx.set_fontsize(7.5)
 for ax in fig.axes:
  ax.spines['top'].set_visible(False);ax.spines['right'].set_visible(False)
def interval_bars(fig):
 evidence=[]
 for ax in fig.axes:
  if ax.get_xlabel().strip()=='AUROC':ax.set_xlim(0,1)
  if ax.get_xlabel().startswith('Brier'):ax.set_xlim(0,ax.get_xlim()[1])
  yy=[float(y) for c in ax.containers if isinstance(c,ErrorbarContainer) and c.lines[0] is not None for y in c.lines[0].get_ydata()]
  dy=np.diff(sorted(set(yy)));height=min(.35,float(dy[dy>1e-6].min())*.75) if len(dy[dy>1e-6]) else .35
  for container in list(ax.containers):
   if not isinstance(container,ErrorbarContainer) or not container.has_xerr:continue
   line=container.lines[0]
   if line is None:continue
   xs=np.asarray(line.get_xdata(),float);ys=np.asarray(line.get_ydata(),float)
   if not len(xs):continue
   col=line.get_color()
   for x,y in zip(xs,ys):
    # JNO: summary estimates remain discrete markers and uncertainty intervals.
    evidence.append(dict(x=float(x),y=float(y)))
   # Retain original marker identity at each bar endpoint.
 return evidence
from jno_native_panels import native_export
def save(fig,n,sources,convert=True):
 selected=os.environ.get('AKI_NATIVE_ONLY','')
 if selected and 'eFigure_'+str(n) not in selected.split(','):plt.close(fig);return
 theme(fig);evidence=interval_bars(fig) if convert else []
 fig.set_size_inches(183/25.4,fig.get_figheight()/fig.get_figwidth()*183/25.4,forward=True)
 if fig.get_figheight()>235/25.4:fig.set_figheight(235/25.4)
 fig.canvas.draw();key='eFigure_'+str(n);native_export(fig,key);base=OUT/key
 fig.savefig(str(base)+'.pdf');fig.savefig(str(base)+'.svg')
 fig.savefig(str(base)+'.png',dpi=300);fig.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 panels=[];renderer=fig.canvas.get_renderer()
 for i,ax in enumerate([x for x in fig.axes if x.get_label()!='<colorbar>']):
  box=ax.get_tightbbox(renderer).transformed(fig.dpi_scale_trans.inverted()).expanded(1.05,1.09)
  pp=OUT/'panels'/key;pp.mkdir(parents=True,exist_ok=True)
  for ext in ['pdf','svg']:fig.savefig(pp/(key+'_'+chr(65+i)+'.'+ext),bbox_inches=box)
  panels.append(chr(65+i))
 manifest.append(dict(figure=key,panels=panels,source_data=sources,interval_bar_estimates=evidence,width_mm=183,height_mm=fig.get_figheight()*25.4,minimum_text_pt=min(t.get_fontsize() for t in fig.findobj(mpl.text.Text) if t.get_text())))
 plt.close(fig)
def capture(fig,name,height,sources,title):
 if name not in mapping:plt.close(fig);return
 if mapping[name]==11:plt.close(fig);return # Replaced below by a complete24-condition metric matrix.
 save(fig,mapping[name],sources)
base=ROOT
s=(ROOT/'code/base_supplement_mappings.py').read_text().split('\nmanifest.sort',1)[0]
s=s.replace("'#0072B2'","'#374E55'").replace("'#D55E00'","'#DF8F44'").replace("'Adults'","'Screened source'").replace('Blue circles: geographic source; vermilion squares: temporal source.','Slate circles: geographic source; orange squares: temporal source.').replace('Blue circles: geographic; vermilion squares: temporal','Slate circles: geographic; orange squares: temporal').replace("'font.sans-serif':['Liberation Sans','DejaVu Sans']","'font.sans-serif':['Arial']")
tree=ast.parse(s)
for node in tree.body:
 if isinstance(node,ast.FunctionDef) and node.name=='record':node.body=ast.parse('return capture(fig,name,height,sources,title)').body
ns={'__file__':str(base/'code/build_figures.py'),'capture':capture};sys.argv=['draw_supplement.py']
exec(compile(tree,'<existing frozen figure mappings; output intercepted>','exec'),ns)
# 2. LLM全24条件：两个评价×三个指标，保留全部条件，不排序挑选赢家。
df=pd.read_csv(C/'aggregate_data/source_data/S4_LLM_all24_calibrated_points.csv')
fig,axes=plt.subplots(3,2,figsize=(183/25.4,205/25.4));fig.subplots_adjust(left=.18,right=.90,bottom=.13,top=.94,hspace=.78,wspace=.75)
models=['biomedlm_2_7b','llama3_8b_instruct_ngc_v1','medgemma_4b_it'];cols=['before_preop','after_preop','before_endop','after_endop']
for i,metric in enumerate(['AUROC','AP','Brier']):
 for j,line in enumerate(['geography','temporal']):
  a=axes[i,j];mat=[]
  for model in models:
   mat.append([float(df[(df.line==line)&(df.model=='llm_'+model+'_'+cond+'_cal')][metric].iloc[0]) for cond in cols])
  im=a.imshow(mat,aspect='auto',cmap=mpl.colors.LinearSegmentedColormap.from_list('clinical_seq',['#F2F5F5',SL]),vmin=0,vmax=1 if metric=='AUROC' else float(df[metric].max()))
  for (r,c),v in np.ndenumerate(mat):a.text(c,r,f'{v:.4f}' if metric=='Brier' else f'{v:.3f}',ha='center',va='center',fontsize=8,color='white' if v>(.6 if metric=='AUROC' else float(df[metric].max())*.6) else '#222222')
  a.set_yticks(range(3),['BioMedLM','Llama 3','MedGemma']);a.set_xticks(range(4),['Preop\nbefore','Preop\nafter','Endop\nbefore','Endop\nafter'],fontsize=7)
  a.set_title(chr(65+i*2+j)+'  '+line.capitalize()+' · '+metric,loc='left',fontsize=8.5,fontweight='bold');fig.colorbar(im,ax=a,fraction=.04,pad=.03)
import copy
def llm_subset(original,selected,n):
 ff=copy.deepcopy(original);axes0=list(ff.axes);keep=[axes0[i] for i in selected];cbs=[x for x in axes0 if x.get_label()=='<colorbar>' and x._colorbar.mappable.axes in keep]
 for x in list(ff.axes):
  if x not in keep and x not in cbs:ff.delaxes(x)
 ff.set_size_inches(183/25.4,(166 if len(keep)==4 else 120)/25.4)
 for i,x in enumerate(keep):
  old=x.get_position().frozen();pos=mpl.transforms.Bbox.from_bounds(.17+.44*(i%2),(.61 if i<2 else .17) if len(keep)==4 else .30,.27,.26 if len(keep)==4 else .55)
  for cb in cbs:
   if cb._colorbar.mappable.axes is x:
    oldc=cb.get_position().frozen();cb.set_position([pos.x0+(oldc.x0-old.x0)*pos.width/old.width,pos.y0,pos.width*.10,pos.height])
  x.set_position(pos);x.set_title(re.sub(r'^[A-F]  ',chr(65+i)+'  ',x.get_title(loc='left')),loc='left',fontweight='bold')
 save(ff,n,['S4_LLM_all24_calibrated_points.csv'],False)
llm_subset(fig,[0,1,2,3],11);llm_subset(fig,[4,5],24);plt.close(fig)
# 3. 已接受的补充临床结果：仅执行读取及绘图函数，替换原有导出逻辑。
p=ROOT/'code/clinical_supplement_mappings.py';source=p.read_text().replace('#0072B2',SL).replace('#D55E00',OR);tree=ast.parse(source)
defs=[x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name!='export']
env=dict(np=np,pd=pd,plt=plt,colors={'geography':SL,'temporal':OR},styles=['existing_selective25','highest_base_risk25','near_training_cutoff25','random25','all_collection'],labels=['Existing selective gate','Highest base risk','Nearest training cutoff','Seeded random acquisition','Collect all additional fields'],contexts=['geography_preop','temporal_preop','geography_paired','temporal_paired'])
env['titles']=['Geographic: 9 to 27','Temporal: 9 to 27','Geographic: 27 to 38','Temporal: 27 to 38']
for key,file in [('D','POLICY_PAIRED_DIFFERENCES'),('L','LOW_RISK_EVENTS'),('M','MIMIC_DELETION_SENSITIVITY'),('W','DAILY_SUMMARY')]:env[key]=pd.read_csv(C/'clinical_supplement_20261108_v1/results'/(file+'.csv'))
exec(compile(ast.Module(body=defs,type_ignores=[]),'<frozen clinical plotting functions>','exec'),env)
for n,funs,shape,h in [(16,[lambda ax,i=i:env['policy'](ax,i) for i in range(4)],(2,2),200),(17,[env['low'],env['deletion']],(2,1),220),(18,[lambda ax:env['demand'](ax,'geography','A'),lambda ax:env['demand'](ax,'temporal','B')],(2,1),200)]:
 fig,axes=plt.subplots(*shape,figsize=(183/25.4,h/25.4),squeeze=False);fig.subplots_adjust(left=.34,right=.97,bottom=.13,top=.94,hspace=.8,wspace=.75)
 for ax,fun in zip(axes.ravel(),funs):
  fun(ax)
  for tx in list(ax.texts):
   if tx.get_transform() is ax.transAxes and tx.get_position()[1]<0:tx.remove()
  ax.title.set_fontsize(8.5)
 save(fig,n,['clinical_supplement_20261108_v1/results'],True)
assert len(manifest)==len(os.environ['AKI_NATIVE_ONLY'].split(',')), (len(manifest),[x['figure'] for x in manifest])
(W/'review/NEW_SUPPLEMENT_FIGURES.json').write_text(json.dumps(dict(figures=manifest,source_mapping='Existing frozen aggregate-to-artist mappings; no statistical computation repeated',new_fits=0,new_bootstrap=0),indent=2))
print('RENDERED_19_BASE_SUPPLEMENT_FIGURES_JNO_MAX4')

