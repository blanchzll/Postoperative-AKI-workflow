
from pathlib import Path
import argparse, hashlib, json, re, shutil, xml.etree.ElementTree as ET
import pymupdf as fitz
from PIL import Image
parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, required=True)
parser.add_argument("--only", nargs="+")
args = parser.parse_args()
output = args.output
selected = args.only or [f"Figure_{i}" for i in range(1,6)] + [f"eFigure_{i}" for i in range(1,27)]
supplement = output / "supplement"
supplement.mkdir(exist_ok=True)
pages = supplement / "pages"
pages.mkdir(exist_ok=True)
native = output / "native"
if native.exists():
    for source in (native / "composites").glob("*.pdf"):
        if source.stem in selected:
            shutil.copy2(source, supplement / source.name)
    for source in (native / "pages").glob("*"):
        if source.is_file() and source.stem.split("_page_")[0] in selected:
            shutil.copy2(source, pages / source.name)
for number in [25, 26]:
    page_files = sorted(pages.glob(f"eFigure_{number}_page_*.pdf"))
    if page_files and f"eFigure_{number}" in selected:
        combined = fitz.open()
        for path in page_files:
            with fitz.open(path) as document:
                combined.insert_pdf(document)
        combined.save(supplement / f"eFigure_{number}.pdf", garbage=4, deflate=True)
        combined.close()
# Export full-size page TIFFs and explicit editable SVG font properties.
for file in pages.glob("*.pdf"):
    if file.stem.split("_page_")[0] not in selected:
        continue
    with fitz.open(file) as document:
        page = document[0]
        pixmap = page.get_pixmap(matrix=fitz.Matrix(600/72, 600/72), alpha=False)
        image = Image.frombytes("RGB", (pixmap.width, pixmap.height), pixmap.samples)
        image.save(file.with_suffix(".tiff"), dpi=(600, 600), compression="tiff_lzw")
        image.close()
namespace = "http://www.w3.org/2000/svg"
ET.register_namespace("", namespace)
for file in list((output / "main").rglob("*.svg")) + list(supplement.rglob("*.svg")):
    tree = ET.parse(file)
    for element in tree.findall(".//{" + namespace + "}text"):
        style = element.get("style", "")
        match = re.search(r"(?:^|;)\s*font:\s*([^;]+)", style)
        if not match:
            continue
        size = re.search(r"(\d+(?:\.\d+)?)px", match[1])[1]
        weight = "700" if re.search(r"\b700\b|\bbold\b", match[1]) else "400"
        style = (style[:match.start()] + style[match.end():]).lstrip("; ")
        element.set("style", style + "; font-family:Arial; font-size:" + size + "px; font-weight:" + weight)
        element.set("font-family", "Arial")
        element.set("font-size", size)
        element.set("font-weight", weight)
    tree.write(file, encoding="utf-8", xml_declaration=True)
records = []
for path in sorted(output.rglob("*")):
    if path.is_file() and ".work" not in path.parts and path.suffix in [".pdf", ".svg", ".png", ".tiff"]:
        records.append(dict(path=str(path.relative_to(output)), bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
(output / "OUTPUT_FILES.json").write_text(json.dumps(records, indent=2))
print("Exported", len(list(pages.glob("*.pdf"))), "supplement pages")
