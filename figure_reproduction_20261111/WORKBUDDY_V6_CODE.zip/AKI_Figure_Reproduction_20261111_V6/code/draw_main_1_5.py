from pathlib import Path
import os,json,hashlib,re,copy,textwrap
os.environ.update(MPLBACKEND='Agg',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
from matplotlib.font_manager import fontManager
from matplotlib.patches import Rectangle,FancyArrowPatch
from matplotlib.lines import Line2D
from common import ROOT, RUN, DATA, register_arial
W=RUN; C=DATA; O=RUN/'main'
register_arial()
mpl.rcParams.update({'font.family':'Arial','font.size':8,'axes.titlesize':8.5,'axes.labelsize':8,'xtick.labelsize':7,'ytick.labelsize':7,'legend.fontsize':7,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False,'xtick.direction':'out','ytick.direction':'out','axes.linewidth':.65,'savefig.facecolor':'white','text.color':'#222222','axes.labelcolor':'#222222'})
SL='#374E55';OR='#DF8F44';PU='#6A6599';GR='#C9CED1';TE='#79AF97';LIGHT='#F1F4F5';INK='#222222'
COL=[SL,'#8E9EA4',OR,'#EBC8A7']
DIV=LinearSegmentedColormap.from_list('clinical_diverging',[OR,'white',SL])
SEQ=LinearSegmentedColormap.from_list('clinical_seq',['#F5F6F7',SL])
inputs={};ledger=[];manifest=[]
def contrast_color(rgba):
 rgb=np.asarray(rgba[:3],float);linear=np.where(rgb<=.04045,rgb/12.92,((rgb+.055)/1.055)**2.4);lum=float(np.dot(linear,[.2126,.7152,.0722]))
 return 'white' if 1.05/(lum+.05)>(lum+.05)/.05 else INK
def load(rel):
 p=C/rel;inputs[rel]=hashlib.sha256(p.read_bytes()).hexdigest();return pd.read_csv(p)
def src(name):return load('aggregate_data/source_data/'+name+'.csv')
def one(d,**kw):
 for k,v in kw.items():d=d[d[k]==v]
 assert len(d)==1,(kw,len(d));return d.iloc[0]
def rec(fig,panel,label,source_key,value,lo=None,hi=None):
 ledger.append(dict(figure=fig,panel=panel,label=label,source_key=source_key,value=float(value),lower95=None if lo is None else float(lo),upper95=None if hi is None else float(hi)))
def newfig(n,positions=None):
 f=plt.figure(figsize=(183/25.4,210/25.4),facecolor='white')
 positions=positions or [[.14,.59,.33,.29],[.63,.59,.33,.29],[.14,.13,.33,.29],[.63,.13,.33,.29]]
 return f,[f.add_axes(x) for x in positions]
def title(ax,letter,text,sub=None):
 width=max(28,int(ax.get_position().width*183/25.4*72/3.45))
 wrapped=textwrap.fill(sub,width) if sub else None
 ax.set_title(textwrap.fill(letter+'  '+text,max(28,int(ax.get_position().width*183/25.4*72/4.0))),loc='left',fontweight='bold',pad=32 if wrapped and '\\n' in wrapped else 23 if sub else 12)
 if wrapped:ax.text(0,1.025,wrapped,transform=ax.transAxes,fontsize=7,va='bottom',linespacing=1.2)
def mark(ax,x,y,lo,hi,c,marker='o',open=False):
 ax.errorbar(x,y,xerr=[[x-lo],[hi-x]],fmt=marker,color=c,mfc='white' if open else c,ms=4,capsize=2,lw=.85,zorder=3)
def panel_hash(ax):
 h=hashlib.sha256()
 for l in ax.lines:h.update(np.asarray(l.get_xydata(),float).tobytes())
 for im in ax.images:h.update(np.ma.asarray(im.get_array()).filled(np.nan).tobytes())
 for c in ax.collections:
  h.update(np.ma.asarray(c.get_offsets()).filled(np.nan).tobytes())
  if c.get_array() is not None:h.update(np.ma.asarray(c.get_array()).filled(np.nan).tobytes())
  for p in c.get_paths():h.update(np.asarray(p.vertices,float).tobytes())
 return h.hexdigest()
def save(f,a,n,topic):
 selected=os.environ.get('AKI_EXPORT_ONLY','')
 if selected and str(n) not in selected.split(','):plt.close(f);return
 f.canvas.draw()
 for axis_ax in f.axes:
  for axis,limits in [(axis_ax.xaxis,axis_ax.get_xlim()),(axis_ax.yaxis,axis_ax.get_ylim())]:
   for tick in axis.get_major_ticks()+axis.get_minor_ticks():
    if not min(limits)-1e-8<=tick.get_loc()<=max(limits)+1e-8:
     tick.label1.set_visible(False);tick.label2.set_visible(False)
 f.canvas.draw();ren=f.canvas.get_renderer();outside=[]
 for t in f.findobj(mpl.text.Text):
  if not t.get_visible() or not t.get_text().strip():continue
  bb=t.get_window_extent(ren)
  # Only visible tick labels inside axis limits are included below in PDF qualification.
  if bb.x0<-.5 or bb.x1>f.bbox.width+.5 or bb.y0<-.5 or bb.y1>f.bbox.height+.5:outside.append(t.get_text())
 assert not outside,(n,'text outside canvas',outside)
 base=O/f'Figure_{n}'
 for ext in ['pdf','svg']:f.savefig(str(base)+'.'+ext)
 f.savefig(str(base)+'.png',dpi=300);f.savefig(str(base)+'.tiff',dpi=600,pil_kwargs={'compression':'tiff_lzw'})
 d=O/'panels'/f'Figure_{n}';d.mkdir(parents=True,exist_ok=True)
 for i,ax in enumerate(a):
  fc=copy.deepcopy(f);target=fc.axes[f.axes.index(ax)]
  linked=[c for c in fc.axes if c.get_label()=='<colorbar>' and getattr(c,'_colorbar',None) is not None and c._colorbar.mappable.axes is target]
  for x in list(fc.axes):
   if x is not target and x not in linked:fc.delaxes(x)
  fc.canvas.draw();r=fc.canvas.get_renderer();boxes=[x.get_tightbbox(r) for x in [target]+linked]
  bb=mpl.transforms.Bbox.union(boxes).transformed(fc.dpi_scale_trans.inverted()).expanded(1.04,1.07)
  for ext in ['pdf','svg']:fc.savefig(d/f'Figure_{n}_{chr(65+i)}.{ext}',bbox_inches=bb)
  plt.close(fc)
 manifest.append(dict(figure=f'Figure_{n}',panels=4,topic=topic,width_mm=183,height_mm=210,numeric_artist_sha256={chr(65+i):panel_hash(ax) for i,ax in enumerate(a)}))
 plt.close(f);print('RENDERED',n,flush=True)

pts=src('Primary_model_points');ints=src('Primary_model_intervals')
cap=load('aggregate_data/novelty_extension/tables/PRIMARY_EQUAL_CAPACITY20.csv')
contrasts=src('Table_3_stage_and_input_differences')
contexts=['geography_preop','temporal_preop']
f,a=newfig(1,[[.06,.275,.43,.655],[.66,.645,.30,.265],[.66,.285,.30,.225],[.06,.055,.90,.105]])
ax=a[0]
title(ax,'A','Discrimination in matched comparisons',
      'Selected workflows; original 95% intervals')
rows=[
 ('geography_preop','preop_compact_champion_LR','9 inputs · LR',10,SL),
 ('geography_preop','preop_full_champion_LR','27 inputs · LR',9,PU),
 ('temporal_preop','preop_compact_champion_Voting','9 inputs · Voting',7,SL),
 ('temporal_preop','preop_full_champion_Voting','27 inputs · Voting',6,PU),
 ('geography_paired','preop_full_champion_Voting','27 inputs · Voting',4,PU),
 ('geography_paired','endop_full_champion_LR','38 inputs · LR',3,OR),
 ('temporal_paired','preop_full_champion_SGBT','27 inputs · SGBT',1,PU),
 ('temporal_paired','endop_full_champion_Voting','38 inputs · Voting',0,OR),
]
for context,model,label,y,color in rows:
 point=one(pts,context=context,model=model)
 interval=one(ints,context=context,model=model,metric='AUROC')
 ax.barh(y,point.AUROC,height=.18,color=color,alpha=.85)
 ax.errorbar(point.AUROC,y,xerr=[[point.AUROC-interval.lower95],[interval.upper95-point.AUROC]],
             fmt='none',ecolor=INK,elinewidth=.8,capsize=2)
 ax.text(0,y+.23,label,fontsize=7,va='bottom')
 ax.text(1.045,y,f'{point.AUROC:.3f}',fontsize=8,ha='left',va='center',color=color)
 rec(1,'A',context+':'+model,'Primary_model_points_and_intervals:AUROC',
     point.AUROC,interval.lower95,interval.upper95)
for context,heading,y in [
 ('geography_preop','Geographic · preoperative',11),
 ('temporal_preop','Temporal · preoperative',8),
 ('geography_paired','Geographic · paired stage',5),
 ('temporal_paired','Temporal · paired stage',2),
]:
 point=pts[pts.context==context].iloc[0]
 ax.text(0,y,heading+f' ({int(point.n):,} / {int(point.events)})',
         fontsize=7.4,fontweight='bold',va='bottom')
ax.set(xlim=(0,1.26),ylim=(-.7,11.9),xlabel='AUROC')
ax.set_xticks([0,.25,.50,.75,1.0]);ax.set_yticks([])
ax.spines['left'].set_visible(False);ax.spines['bottom'].set_bounds(0,1)
ax=a[1];title(ax,'B','Paired discrimination differences',
 'Additional-information workflow minus baseline')
keys=[
 ('Geographic · 9→27','Geography preop','preop_full_champion_LR MINUS preop_compact_champion_LR',SL),
 ('Temporal · 9→27','Temporal preop','preop_full_champion_Voting MINUS preop_compact_champion_Voting',OR),
 ('Geographic · 27→38','Geography paired','endop_full_champion_LR MINUS preop_full_champion_Voting',SL),
 ('Temporal · 27→38','Temporal paired','endop_full_champion_Voting MINUS preop_full_champion_SGBT',OR)]
# Evaluation labels are read from the saved exact comparison identifiers.
for i,(lab,ctx,key,c) in enumerate(keys):
 z=contrasts[(contrasts.model==key)&(contrasts.metric=='AUROC')]
 assert len(z)==1,(key,len(z));r=z.iloc[0]
 y=3-i
 mark(ax,r.estimate,y,r.lower95,r.upper95,c,marker='o' if i<2 else 's')
 ax.text(-.085,y+.25,lab,fontsize=7.2,va='bottom')
 ax.text(-.085,y-.25,f'{r.estimate:+.3f} ({r.lower95:.3f} to {r.upper95:.3f})',fontsize=7,va='top')
 rec(1,'B',key,'Table_3_stage_and_input_differences:AUROC',r.estimate,r.lower95,r.upper95)
ax.axvline(0,color='#999999',lw=.7)
ax.set(xlim=(-.09,.22),ylim=(-.65,3.65),xlabel='Difference in AUROC')
ax.set_xticks([-.05,0,.1,.2]);ax.set_yticks([]);ax.spines['left'].set_visible(False)
ax=a[2];title(ax,'C','Review capacity and event coverage','Empirical curves over 0–50% capacity')
for ctx,c in zip(contexts,[SL,OR]):
 d=src('Translation_'+ctx+'_CAPTURE_REVIEW_CURVE')
 for kind,ls in [('compact','-'),('full','--')]:
  z=d[d.model.str.contains('preop_'+kind+'_champion')].sort_values('reviewed_n')
  ax.plot(z.reviewed_per1000/10,z.sensitivity*100,color=c,ls=ls,lw=1.1,label=('Geo' if ctx.startswith('geo') else 'Time')+(' · 9' if kind=='compact' else ' · 27'))
  rec(1,'C',ctx+':'+kind,'empirical_curve_rows',len(z))
ax.axvline(20,color='#999999',ls=':',lw=.8)
ax.set(xlim=(0,50),ylim=(0,100),xlabel='Records reviewed, %',ylabel='Recorded AKI events captured, %')
ax.legend(ncol=2,loc='upper left',fontsize=7,columnspacing=.8,handlelength=1.4)
ax=a[3];ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
title(ax,'D','Event capture at 20% capacity · 27 versus 9 preoperative inputs')
for x,txt in [(0,'Evaluation'),(.20,'Records reviewed'),(.43,'Events captured: 9 → 27'),(.73,'Paired difference / 1,000 (95% CI)')]:
 ax.text(x,.97,txt,fontsize=7,fontweight='bold',va='top')
for j,(cid,c) in enumerate(zip(['geography_9v27_champ','temporal_9v27_champ'],[SL,OR])):
 r=one(cap,comparison_id=cid);y=.55-.40*j
 for x,txt in [(0,'Geographic' if j==0 else 'Temporal'),(.20,f'{int(r.base_reviews_n)}'),(.43,f'{int(r.base_captured_n)}/{int(r.events)} → {int(r.extra_captured_n)}/{int(r.events)}'),
               (.73,f'{r.delta_captured_per1000:+.2f} ({r.delta_captured_per1000_lower95:.2f} to {r.delta_captured_per1000_upper95:.2f})')]:
  ax.text(x,y,txt,fontsize=7.5,va='center',color=c)
 rec(1,'D',cid,'PRIMARY_EQUAL_CAPACITY20:delta_captured_per1000',r.delta_captured_per1000,r.delta_captured_per1000_lower95,r.delta_captured_per1000_upper95)
ax.plot([0,1],[.73,.73],color=GR,lw=.6)
save(f,a,1,'Selected-workflow discrimination, paired contrasts and review coverage')
# Figure5: target cohort qualification, probabilistic accuracy, policy workload and measurement sensitivity.
mp=load('aggregate_data/novelty_extension/mimic_calendar_v2/POINT_ESTIMATES.csv');mi=load('aggregate_data/novelty_extension/mimic_calendar_v2/INTERVALS.csv');cut=load('aggregate_data/novelty_extension/mimic_calendar_v2/SOURCE_THRESHOLD_BURDEN.csv')
deletion=load('clinical_supplement_20261108_v1/results/MIMIC_DELETION_SENSITIVITY.csv')
f,a=newfig(5,[[.12,.60,.35,.28],[.64,.60,.28,.28],[.12,.13,.35,.29],[.63,.13,.33,.29]])
ax=a[0];title(ax,'A','Clinical qualification and data availability')
levels=[1231,764,759,759];starts=[0,764,759,0];heights=[1231,467,5,759];cols=[SL,GR,GR,PU]
for i,(bottom,h,c) in enumerate(zip(starts,heights,cols)):
 ax.bar(i,h,bottom=bottom,width=.63,color=c,edgecolor='white',lw=.6)
 ax.text(i,bottom+h+30,['1,231','−467','−5','759'][i],ha='center',fontsize=8,fontweight='bold')
 if i<3:ax.plot([i+.315,i+.685],[levels[i],levels[i]],c='#888888',lw=.6)
ax.set_xticks(range(4),['Anatomic\ncandidates','No baseline\nSCr','No follow-up\nSCr','Eligible']);ax.set(ylim=(0,1500),ylabel='Patients',xlim=(-.6,3.6))
ax.text(.03,.96,'759 patients · 59 SCr events',transform=ax.transAxes,fontsize=7.5,va='top')
ax.text(0,-.18,'Observed / 759: creatinine 759; urea nitrogen 726;\nalbumin 294; hemoglobin 719.',transform=ax.transAxes,fontsize=7.2,va='top')
ax=a[1];title(ax,'B','Target probability error','Brier score: point estimates and original 95% intervals')
mat=np.array([[one(mp,model=line+'__'+mode).Brier for line in ['geography','temporal']] for mode in ['raw','calibrated']]+[[59/759*(1-59/759)]*2])
im=ax.pcolormesh(np.arange(3)-.5,np.arange(4)-.5,mat,cmap=SEQ,vmin=0,vmax=.10,shading='flat',rasterized=False);ax.set(xlim=(-.5,1.5),ylim=(2.5,-.5))
for i in range(3):
 for j,line in enumerate(['geography','temporal']):
  if i<2:
   r=one(mi,model=line+'__'+['raw','calibrated'][i],metric='Brier');text=f'{r.estimate:.4f}\n({r.lower95:.4f}, {r.upper95:.4f})'
   rec(5,'B',line+':'+['raw','calibrated'][i],'mimic_calendar_v2/INTERVALS:Brier',r.estimate,r.lower95,r.upper95)
  else:text=f'{mat[i,j]:.4f}\nPoint reference'
  ax.text(j,i,text,ha='center',va='center',fontsize=7.3,color=contrast_color(SEQ(mpl.colors.Normalize(0,.10)(mat[i,j]))),linespacing=1.5)
ax.set_xticks([0,1],['Geographic RF','Temporal RF']);ax.set_yticks(range(3),['Frozen raw','Source-calibrated','Observed-prevalence\nconstant'])
cb=f.colorbar(im,ax=ax,fraction=.035,pad=.025);cb.set_label('Brier score',fontsize=7)
ax.text(0,-.18,'AUROC: 0.614 (0.549–0.680); 0.621 (0.552–0.688).\nCalibrated Brier minus reference: +0.0088; +0.0027.',transform=ax.transAxes,fontsize=7.2,va='top')
ax=a[2];title(ax,'C','Workload and recorded-event coverage','Same patients; three threshold rules')
for j,(line,c) in enumerate(zip(['geography','temporal'],[SL,OR])):
 r=one(mp,model=line+'__calibrated')
 entries=[('Target 20%',r.capacity20_reviewed_n,r.capacity20_captured_n,r.capacity20_reviewed_per1000/10,r.capacity20_sensitivity*100)]
 for rule,lab in [('training_capacity20','Source 20%'),('training_sensitivity80','Source 80% sensitivity')]:
  z=cut[(cut.source_line==line)&(cut.rule==rule)]
  rn=one(z,metric='reviewed_n').estimate;cn=one(z,metric='captured_n').estimate
  entries.append((lab,rn,cn,rn/759*100,cn/59*100))
 for k,(lab,rn,cn,x,y) in enumerate(entries):
  ax.plot(x,y,marker=['o','D','^'][k],color=c,ms=4.5,mfc=c if j==0 else 'white',mew=1)
  tx,ty=([(3,12),(45,66),(5,94)] if j==0 else [(37,30),(45,45),(62,109)])[k]
  shortlab=['target 20%','source 20%','source sensitivity 80%'][k]
  ax.annotate(('Geo · ' if j==0 else 'Time · ')+shortlab+f'\n{rn:.0f} reviewed / {cn:.0f} events',(x,y),xytext=(tx,ty),textcoords='data',fontsize=7,ha='left',va='top',arrowprops=dict(arrowstyle='-',color=c,lw=.55))
  rec(5,'C',line+':'+lab,'saved threshold or target20 counts:reviewed_n',rn);rec(5,'C',line+':'+lab,'saved threshold or target20 counts:captured_n',cn)
ax.set(xlim=(0,110),ylim=(0,110),xlabel='Patients reviewed, %',ylabel='Recorded SCr events captured, %');ax.set_xticks([0,20,40,60,80,100]);ax.set_yticks([0,20,40,60,80,100])

ax=a[3];title(ax,'D','Known-event loss by measurement rule','Observed loss with Wilson 95% CIs')
modes=['first_per_calendar_day','odd_calendar_days','even_calendar_days','calendar_days1_2_only','calendar_day1_only']
short=['First/day','Odd days','Even days','Days 1–2','Day 1']
for pidx,(pop,c) in enumerate([('all_observed_records',SL),('geography_low_risk6',OR)]):
 for k,mode in enumerate(modes):
  r=one(deletion,population=pop,mode=mode);x=r.lost_known_fraction*100
  lo=r.lost_event_Wilson_lo*100;hi=r.lost_event_Wilson_hi*100
  y=4-k+(.14 if pidx==0 else -.14)
  mark(ax,x,y,lo,hi,c,marker='o' if pidx==0 else 's',open=pidx==1)
  ax.text(104,y,f'{int(r.lost_known_events_lower_bound)}/{int(r.original_known_events)}',ha='center',va='center',fontsize=7,color=c)
  ax.text(143,y,f'{100*r.deleted_fraction:.1f}%',ha='center',va='center',fontsize=7,color=c)
  rec(5,'D',pop+':'+mode,'MIMIC_DELETION_SENSITIVITY:lost_known_fraction;Wilson',r.lost_known_fraction,r.lost_event_Wilson_lo,r.lost_event_Wilson_hi)
  rec(5,'D',pop+':'+mode,'MIMIC_DELETION_SENSITIVITY:deleted_fraction',r.deleted_fraction)
 for k in range(4):ax.axhline(3.5-k,color='#EEEEEE',lw=.55,zorder=0)
ax.set(xlim=(-2,162),ylim=(-.65,4.8),xlabel='Known-event loss, %')
ax.xaxis.set_label_coords(.25,-.11)
ax.set_xticks([0,20,40,60,80]);ax.set_yticks(range(4,-1,-1),short)
ax.spines['left'].set_visible(False);ax.spines['bottom'].set_bounds(0,80)
ax.text(104,4.63,'Lost /\nknown',fontsize=7,ha='center',va='bottom')
ax.text(143,4.63,'Tests\nremoved',fontsize=7,ha='center',va='bottom')
ax.axvline(91,color=GR,lw=.6)
handles=[Line2D([],[],marker='o',ls='',color=SL,ms=4,label='All 759 patients / 59 events'),
         Line2D([],[],marker='s',ls='',color=OR,mfc='white',ms=4,label='Geo low-risk: 258 / 11 (subset)')]
ax.legend(handles=handles,loc='upper left',bbox_to_anchor=(-.03,-.20),fontsize=7,handlelength=1)
f.text(.12,.027,'Calendar-window SCr endpoint; rule-specific comparisons reuse observed tests.\nLoss of known events does not estimate the clinical effect of reducing monitoring.',fontsize=7.3,linespacing=1.4)
save(f,a,5,'MIMIC clinical transport, workload and policy-aligned measurement sensitivity')
(W/'review/TARGETED_FIGURE_BINDINGS.json').write_text(json.dumps(dict(figures=manifest,source_csvs=inputs,ledger=ledger,new_fits=0,new_bootstrap=0),indent=2))
print('COMPLETED_TARGETED_FIGURES_1_AND_5')
