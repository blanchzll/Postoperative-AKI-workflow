# JAMA Network Open 主图面板设计规格书（Figure 1–5，共 20 面板）

版本：v1 / 2026-11-11
依据：`AKI_JNO_20261111_SHAP_WORKFLOW_V4` 最终版图注（Figure 1 已按"弃流程图、改 8 条 AUROC 条形"更新）+ `AKI_Figure_Reproduction_20261111` 绘图代码与聚合数据
目标期刊：JAMA Network Open（Original Investigation，5 个图文条目上限，每幅 4 面板）

---

## 0 先说结论：6 处必须改，3 处建议改

| 优先级 | 位置 | 问题 | 处置 |
|---|---|---|---|
| 必改 P1 | 全部 5 幅 | 画布 183 mm = 7.20 in，超过 JAMA 双栏上限 **6.75 in（171 mm）** | 版心改 171 mm，右侧留白重排 |
| 必改 P1 | 全部 5 幅 | 正文/刻度字号 7 pt，低于 JAMA **8 pt** 下限 | 正文 8 pt、轴标题 9 pt、面板字母 10 pt bold |
| 必改 P1 | **Figure 4B** | AUROC、AP、Brier 三种不同尺度的差值共用一根 x 轴（"Difference (unitless)"） | 拆成 3 个小面板，或统一换算为相对基线变化率 |
| 必改 P2 | **Figure 5B** | 6 个 Brier 数值做成 3×2 热图，色块不承载额外信息 | 改点-须图（dot-whisker），色只编码 geo/temp |
| 必改 P2 | **Figure 2A–D** | 发散色图零点=纯白，与"灰=不可行"、白底共存，出现"双零歧义" | 零点改中性 `#F2F2F2`，不可行格加 45° 斜线纹理 |
| 必改 P2 | **Figure 1D** | 纯文字表格做成面板，JAMA 会重绘或并回正文，且与 1C 信息重复 | 改成"9→27 成对点+箭头图"，计数作标注 |
| 建议 P3 | Figure 1C/4C | 累积捕获曲线用直线内插，真实是阶梯函数（整份列表逐条递进） | `drawstyle='steps-post'` |
| 建议 P3 | Figure 4A | 有/无编码匹配量级悬殊（387 vs 5 656），条形对比被压扁 | 改棒棒糖图 + 右侧注分母；**不可**改 100% 堆叠（JAMA 明令禁止堆叠柱） |
| 建议 P3 | Figure 3A/3B | 数值标签固定在 x=−340，与最长须线（INSPIRE 6→9）易撞 | 数值移到右侧固定列，或并入图注表 |

---

## 1 全局设计系统（五图统一）

### 1.1 版面与字体

| 项 | 取值 | 说明 |
|---|---|---|
| 画布 | 双栏 171 mm × ≤ 220 mm；单栏 82 mm | 现在 183×210 mm，需收窄 12 mm |
| 字体 | Arial（备选 Helvetica） | 全图统一，禁止混排宋体/Calibri |
| 面板字母 | 10 pt **加粗**，左上角，figure 坐标统一 `x=0.005, y=1.02` | 四个面板同一 x 起点，不用 `ax.text` 手摆 |
| 面板小标题 | 8 pt 常规（可选） | 若保留，必须与图注措辞不重复；建议只留字母+极短标签 |
| 轴标题 | 9 pt，含**变量名 + 单位** | 例："Records reviewed, %"、"Events captured per 1 000 operations" |
| 刻度标签 | 8 pt | 45° 旋转仅在标签长度 >8 字符时使用 |
| 图内注释 | 8 pt | 引线 0.55 pt |
| 轴框 | 只留左+下（L 型），0.75 pt；上/右脊隐藏 | 与 JAMA 排版一致 |
| 刻度线 | 朝外，长 2.5 pt，宽 0.6 pt | |
| 参考线 | 零线/阈值线 0.7 pt，`#999999`，虚线 `(0,(3,2))` | |

### 1.2 配色（色盲安全，Okabe–Ito 派生）

| 语义 | 颜色 | 冗余编码 |
|---|---|---|
| 地理评估 Geographic | `#0072B2` 蓝 | 实线 / 实心 |
| 时间评估 Temporal | `#D55E00` 朱红 | 虚线 / 空心 |
| 9 输入（基线术前） | 同语境色 | ○ 空心圆 + 实线 |
| 27 输入 | 同语境色 | ● 实心圆 + 虚线 |
| 38 输入（术毕） | 同语境色 | ▲ 三角 + 点划线 |
| 6 输入 RF（公共源） | `#009E73` 青绿 | ○ 空心 + 实线 |
| 编码九输入（coded-9） | `#CC79A7` 洋红 | ● 实心 + 虚线 |
| 中性文字 | `#333333` | |
| 不可行 / 缺失 | `#BDBDBD` + 45° 斜线 | 图注注明"grey = infeasible" |
| 浅底 | `#F0F0F0` | |

**色图**
- 发散（Δ 事件、Δ 捕获）：`#0072B2 → #F2F2F2 → #D55E00`，中点为**近白灰而非纯白**，`TwoSlopeNorm(0)`，四面板共用同一 vmax。
- 顺序（Brier、捕获率）：`#F7F7F7 → #0072B2` 单色，或 `viridis`；**不用 jet/rainbow**。

**为何弃用现有 `#374E55 / #DF8F44 / #6A6599`**：橙 `#DF8F44` 与紫 `#6A6599` 明度接近，小尺寸标记在绿/红色盲与灰度打印下难以区分；蓝-朱红对在三种常见色盲型与灰度下都可分。

### 1.3 统计要素（图注必须交代）

- 全部区间：2 000 次**医院分层、患者组整群** bootstrap 的成对百分位 95% 区间；写清 n（手术数/记录数）与事件数。
- Figure 5D 的区间为 **Wilson 95%**（含零丢失），与 bootstrap 区间分开表述。
- 不使用双 Y 轴、饼图、3D、堆叠柱（JAMA 明令禁止）；OR/RR/HR 类比值必须对数轴（本组图无此量）。
- 频率/百分比轴一律从 0 起，不截断。

### 1.4 输出

PDF（`pdf.fonttype=42` 嵌入 TrueType）+ EPS/SVG 矢量；位图 TIFF LZW 600 ppi（线条图）/300 ppi（照片）。RGB。**不用 JPEG**。

---

## 2 Figure 1 — 选择性工作流的判别力、成对比较与事件覆盖

**论证目标**：信息从 9→27→38 项递增，判别力只小幅提升；在没有额外成本假设时，多出的信息带来的额外捕获也很有限。

**版式**：2 列 × 2 行，A 占左上大格（约 0.47 宽 × 0.62 高），B 右上（0.40 × 0.30），C 右下（0.40 × 0.28），D 底部通栏（0.94 × 0.12）。

| 面板 | 图型 | 坐标轴 | 编码与配色 | 误差 / n | 标注 | 建议尺寸 |
|---|---|---|---|---|---|---|
| **1A** 判别力 | **横向条形图 + 误差棒**（8 条，分 4 组）→ 建议改 **点-须图** | x = AUROC，0–1，刻度 0/0.25/0.50/0.75/1.00；y 无刻度（组内行距 1） | 颜色=语境（geo 蓝 / temp 朱红）；填充=阶段（9 空心 / 27 实心 / 38 三角） | 原始患者组 bootstrap 95% CI，横向须 | 组标题两行：`Geographic · preoperative` + `(1 159 / 72)`；条形右端 3 位小数，**右对齐固定列**（x=1.02，左对齐文字） | 80 × 130 mm |
| **1B** 成对差值 | **点-须图**（4 行） | x = ΔAUROC，−0.09…0.22，零线必画；y = 4 个比较 | geo=蓝圆、temp=朱红圆（9→27）；27→38 用方框 | 成对 bootstrap 95% CI | 左侧 `+0.030 (0.012 to 0.048)`；数值列移到左侧**轴外固定列**，不压数据区 | 70 × 62 mm |
| **1C** 捕获-复核曲线 | **阶梯累积曲线**（4 条，`steps-post`） | x = Records reviewed, %，0–50，刻度每 10；y = Recorded AKI events captured, %，0–100 | 蓝=geo、朱红=temp；实线=9、虚线=27 | 无区间（经验曲线） | 20% 处竖虚线 `(0,(2,2))`；图例 2×2 移至轴下方外侧 | 70 × 58 mm |
| **1D** 20% 容量捕获 | **成对点+箭头图**（2 行 × 2 端）【替代现文字表】 | x = Events captured per 1 000 operations，0–80；y 两行=geo/temp | 同上 | 差值 ± 95% CI 以横须表示 | 端点旁注 `32/72`、`34/72`、`35/66`、`38/66`；右侧 `+1.73 (−3.45 to 6.91)`、`+1.78 (−2.38 to 4.76)`；左上注"232 / 337 records reviewed" | 160 × 26 mm |

**若坚持保留 1D 表格形态**：三列表头（Evaluation / Records reviewed / Events captured 9→27 / Paired difference per 1 000 with 95% CI），仅用 0.6 pt 横线分隔，不用底色块；并接受期刊重绘风险。

---

## 3 Figure 2 — 采集成本 × 复核预算 × 捕获事件（4 个完整网格）

**论证目标**：在"总预算不变"的约束下，只有当追加信息的采集成本足够低时，它才比扩大基线复核捕获更多事件；成本一旦升高，最优选择退回基线。

**版式**：2×2 等格，每格 72 × 58 mm + 共享色条（右侧通列一条，替代现在 4 条重复色条）。

| 面板 | 图型 | 坐标轴 | 编码与配色 | 标注 | 备注 |
|---|---|---|---|---|---|
| **2A** Geo 9→27 | **热图**（`pcolormesh`，31 列 × 6 行，`shading='flat'`） | x = Acquisition cost / review cost，0–0.30，刻度 0/0.1/0.2/0.3；y = Total budget, %，2.5–32.5，刻度 5…30 | color = Δ captured events / 1 000（发散，共用 vmax，建议 ±40） | 仅 0/0.1/0.2/0.3 四列标数值（1 位小数）；95% CI 不含 0 的格在数值后加 `*`，未标数值的显著格加 1.8 pt 实心点 | 20% 行叠开三角（允许成本 D/1000） |
| **2B** Temp 9→27 | 同上 | 同上 | 同上 | 同上 | 不可行格 `#BDBDBD` + 45° 斜线（`hatch='///'`，0.4 pt，白线） |
| **2C** Geo 27→38 | 同上 | 同上 | 同上 | 同上 | 四格共用一条色条，标"Δ captured events per 1 000" |
| **2D** Temp 27→38 | 同上 | 同上 | 同上 | 同上 | 脚注：`Numbers: selected exact cells. Dot or asterisk: pointwise 95% CI excludes zero.` |

**决策要点**：热图是本图唯一正确选择（6×31 的二维网格，且要同时看"行/列方向的最优边界"）；但必须解决白=0 与灰=不可行的歧义——把零点移到 `#F2F2F2`，灰格加纹理，两者在灰度下也可分。

---

## 4 Figure 3 — 等捕获资源与成本加权事件覆盖

**论证目标**：为了达到"同样的捕获事件数"，追加信息路径最多能承担多少额外采集成本（D）；以及在不同成本律下，追加路径的期望收益方向。

**版式**：上排 A、B 两列等宽（各 68 × 62 mm）；下排 C（窄，50 mm）与 D（宽，78 mm）。

| 面板 | 图型 | 坐标轴 | 编码与配色 | 误差 | 标注 |
|---|---|---|---|---|---|
| **3A** 地理 D 值 | **横向点-须图**（7 行） | x = Review equivalents per 1 000，−350…200，零线必画；y = 7 个比较（9→27 selected、27→38 selected、9→27 LR、27→38 LR、27→38 Voting、6→9 LR、INSPIRE 6→9） | 蓝 | 原始 95% CI 横须 | 数值 `−12.3 (−45.1, 20.4)` 放**右侧轴外固定列**（现放 x=−340 会撞最长须） |
| **3B** 时间 D 值 | 同上 | 同上 | 朱红 | 同上 | 同上；y 轴标签仅 A 显示，B 共享 |
| **3C** 等捕获复核量 | **哑铃图**（4 行，两点+连线）【替代分组条形】 | x = Records reviewed，0–390；y = 4 个比较 | 灰点=基线、紫点=追加路径；连线 0.7 pt `#BDBDBD` | 无（点估计） | 端点旁标数值；图例置轴下；说明"20% 基线预算下" |
| **3D** 成本加权效应 | **点-须矩阵**（5 列成本律 × 4 行比较）【替代带 CI 的 4×5 热图】 | x = 5 个成本律（Uniform / Low / Middle / High / Wide tail，45° 旋转）；y = 4 个比较 | 点色按 Δ 大小映射发散色图；零线竖虚线 | 成对 95% CI 横须 | 8 pt 下每格两行数字（值+CI）过密，故改点-须；精确值移入 eTable |

**说明**：3C 由"分组条形"改"哑铃图"，是因为要读的是**两点之间的差距**而不是各自绝对值；哑铃图的墨水比 ~1/3 条形，且不与 JAMA 的反堆叠柱倾向冲突。3D 若期刊坚持矩阵形态，保留热图但只放点估计，CI 进 eTable。

---

## 5 Figure 4 — INSPIRE 的信息表示与临床复核

**论证目标**：在公共数据里，把"自由文本/编码病史"压成 6 个输入，与保留九项编码信息的流程相比，判别力与平均精度略低、概率误差略大；阈值从源队列迁移到目标队列会显著改变复核负担。

**版式**：A（58 × 58 mm）、B（72 × 58 mm）上排；C（72 × 62 mm）、D（72 × 58 mm）下排。

| 面板 | 图型 | 坐标轴 | 编码与配色 | 误差 | 标注 |
|---|---|---|---|---|---|
| **4A** 病史匹配 | **棒棒糖图**（3 行，单系列）【替代成对条形】 | x = Records，0–6 500；y = Diabetes / Hypertension / Other heart disease | 蓝点 `#0072B2`，stem 0.6 pt | 无（计数） | 点旁标 `387`，右侧固定列标 `of 6 043 (6.4%)`、`439 (7.3%)`、`354 (5.9%)`；图注保留"无发布匹配≠临床阴性" |
| **4B** 成对性能差 | **三分面点-须图**（3 列指标 × 2 行语境）【**必改**】 | 每个分面各自 x 轴：ΔAUROC（−0.02…0.06）、ΔAP（0…0.10）、Brier 降低（0…0.04） | 蓝=geo、朱红=temp | 成对 95% CI | 分面标题 8 pt：`Δ AUROC`、`Δ AP`、`Brier decrease`；统一注"positive favours coded-nine"；Brier 的限已反向，图注说明 |
| **4C** 目标排序曲线 | **阶梯累积曲线**（4 条） | x = Records reviewed, %，0–50；y = Recorded SCr events captured, %，0–100 | 6 输入=空心+实线（青绿 `#009E73`）；coded-9=实心+虚线（洋红 `#CC79A7`）；geo/temp 用蓝/朱红×阶段叠加 | 无 | 20% 竖虚线 + 4 个点；右下注 `At 20%: Geo 121→123; Time 124→128 events`；刻度 0/20/40/60/80/100 |
| **4D** 阈值迁移负担 | **散点 + 引线**（4 组，各 2 点连线） | x = Records reviewed, %，0–125；y = Recorded SCr events captured, %，0–115 | 同上四色 | 无（观测操作点） | ○=目标排序 20%、◇=迁移阈值；引线 0.55 pt，标注 `Geo · 6` + `1 209 reviewed / 121 events`；引线锚点需固定，避免 4 条交叉 |

**4B 的两种合法改法**（择一）：
1. **三分面**（推荐）：三列小轴，各自量纲，读者不再被"unitless"困惑；
2. **统一换算**：全部改为"相对六输入基线的百分比变化"，共用一根 x 轴，并在轴标题写明 `% change vs six-input RF`。

---

## 6 Figure 5 — MIMIC 外部转运、 workload 与测量条件

**论证目标**：把模型搬到外部医院，判别力明显衰减、概率误差并不优于"人人同患病率"的常数；而事件的"检出"高度依赖肌酐测量频率——这是数据层面的敏感性，不等于停监测是安全的。

**版式**：A（78 × 62 mm）、B（62 × 62 mm）上排；C（78 × 62 mm）、D（72 × 62 mm）下排；底部通栏脚注两行。

| 面板 | 图型 | 坐标轴 | 编码与配色 | 误差 | 标注 |
|---|---|---|---|---|---|
| **5A** 入组资格 | **瀑布/漏斗**（4 段：1 231 → −467 → −5 → 759） | x = 4 个阶段（Anatomic candidates / No baseline SCr / No follow-up SCr / Eligible），类目轴；y = Patients，0–1 500 | 首段蓝、中间段灰 `#BDBDBD`、末段紫 `#CC79A7`；段间连接线 0.6 pt `#888888` | 无 | 柱顶 `1 231`、`−467`、`−5`、`759`（8 pt bold）；左上 `759 patients · 59 SCr events`；轴下注观测可得数 `creatinine 759; urea nitrogen 726; albumin 294; hemoglobin 719` |
| **5B** 目标概率误差 | **点-须图**（3 行 × 2 列）【**必改**，弃热图】 | x = Brier score，0–0.10，刻度 0/0.025/0.05/0.075/0.10；y = 3 行（Frozen raw / Source-calibrated / Observed-prevalence constant） | 蓝=geo RF、朱红=temp RF；第三行用灰菱形（点参考，无区间） | 前两行为 bootstrap 95% CI 横须；第三行为单点 | 每点右侧注值+区间（geo 标定 `0.0805 (0.0644, 0.0976)`；temp 标定 `0.0744 (0.0584, 0.0906)`；患病率常数 `0.0717`）；轴下注 `AUROC 0.614 (0.549–0.680); 0.621 (0.552–0.688)` 与 `Calibrated Brier minus reference: +0.0088; +0.0027` |
| **5C** 复核负担与覆盖 | **散点 + 引线**（2 组 × 3 规则） | x = Patients reviewed, %，0–110，刻度每 20；y = Recorded SCr events captured, %，0–110 | 蓝=geo、朱红=temp；形状=规则（○目标 20%、◇源 20%、△源敏感度 80%） | 无（观测） | 每点注 `Geo · target 20%` + `152 reviewed / 13 events`（temp 同 152 复核 / 16 事件）；6 条引线需人工定锚（建议改用 2 列小多图避免交叉） |
| **5D** 测量删减敏感性 | **点-须图**（5 行 × 2 人群，错位 ±0.14） | x = Known-event loss, %，0–80，刻度 0/20/40/60/80；y = 5 条删减规则（First/day、Odd days、Even days、Days 1–2、Day 1） | ● = 全部 759 例/59 事件（蓝）；□ 空心 = 地理源低危亚组 258 例/11 事件（朱红） | **Wilson 95%**（含零丢失） | 右侧两列固定表头 `Lost / known`（`11/59`）与 `Tests removed`（`48.7%`），列间 0.6 pt 分隔线；图例置轴下 |

**5D 版面注意**：现在靠 `xlim=(−2,162)` 把文字列推进画布，再用 `set_label_coords` 把 x 轴标题挪回，属于脆弱布局——放大字号到 8 pt 后极易错位。建议：数据轴只到 85，文字列用 `fig.text` 在 figure 坐标里独立排布。

---

## 7 图注写法（每幅控制在 120–150 词）

模板四段：**①一句总论点 → ②每面板一句描述（含图型与坐标含义）→ ③统计要素（区间类型、n、事件数、重抽样层级）→ ④限定语（回溯性/条件性/不外推）**。

示例（Figure 3）：
> **Figure 3. Equal-capture resources and cost-weighted event coverage.**
> A and B, Signed acquisition allowance D with 95% intervals in review equivalents per 1 000 operations for geographic (A) and temporal (B) evaluation; values right of zero favour paying for additional information. C, Dumbbell plot of baseline review-list size versus the shortest additional-information list matching its captured-event count at a 20% baseline budget. D, Mean capture differences under five analyst-specified cost laws, shown as a dot-and-whisker matrix. Intervals are paired percentile 95% intervals from 2 000 hospital-stratified patient-group bootstrap samples. Results are conditional on the cost laws and frozen systems.

---

## 8 投稿前自检清单（渲图后逐条过）

1. 画布 ≤171 mm；所有文字 ≥8 pt；无文字越界/被裁。
2. 无乱码方框（负号用 U+2212 或 `axes.unicode_minus` 正确设置；本组图为英文，仅需确认 Arial 嵌入）。
3. 面板字母 A–D 四点共线、同字号、同字体。
4. 图例全部在数据区外，无遮挡；引线不交叉、不压点。
5. 灰度打印后仍可区分（蓝↔朱红→深灰↔中灰）。
6. 零线/阈值线显式可见；频率轴从 0 起。
7. 同一变量跨 5 图同色、同形状、同量纲（如 geo 恒为蓝圆）。
8. PDF 为矢量、字体已嵌入（fonttype 42）；无 JPEG；TIFF ≥600 ppi。

---

## 附录 A：26 幅 eFigure 的面板级图型速查

| eFigure | 面板 | 图型 | 主坐标 | 配色 |
|---|---|---|---|---|
| 1 | A–D | 漏斗/流失条形 + 计数表 | y = 记录数 | 蓝/灰/洋红 |
| 2 | A；B | 条形+CI；0.5 步长判定矩阵 | x = δ（0–10） | 蓝/朱红；实心=U<δ |
| 3 | A,B | 点-须（difference-in-differences） | x = Δ per 1 000 | 蓝/朱红 |
| 4 | a–d | 点+95% 范围（随机分配带） | x = Δ per 1 000 | 圆=25% 预算、方=50% |
| 5 | A；B | 三系列点-须；差值点-须 | x = Brier；x = Δ Brier | ○原/□offset/△logistic |
| 6 | A,B；C | 阶梯捕获曲线；条形+CI | x = % reviewed | 实线=9、虚线=27 |
| 7 | A；C,D | 条形；操作点散点 | x = AUROC；x = % reviewed | 蓝/朱红 |
| 8 | A；B | 条形+CI | x = 比例 % | 蓝/朱红 |
| 9 | A,B | 成对差值点-须 | x = ΔAUROC / ΔBrier | 蓝/朱红 |
| 10 | A；B | 条形；点+2.5–97.5% 范围 | x = 重叠率 % | 蓝/朱红 |
| 11 | A/B；C/D | 3×4 热图（AUROC；AP） | 行=模型、列=阶段 | viridis 系（非 rainbow） |
| 12 | a；b,c；d | 条形+CI；点+范围；点+CI | x = 每 1 000 工作量/事件 | 蓝/朱红 |
| 13 | a–d | 校准曲线（10 分位点+identity） | x = 预测概率 | 灰+对角虚线 |
| 14 | A；B | 点-须（差值与捕获） | x = Δ | 蓝/朱红 |
| 15 | A,B；C,D | 成对点-须 | x = AUROC/Brier；x = 捕获 % | 实心=完整系统、空心=同族 |
| 16 | A–D | 点-须（等总预算） | x = Δ per 1 000 | 蓝/朱红 |
| 17 | A；B | 条形+CI；点+Wilson | x = 事件率 % | 蓝/朱红 |
| 18 | A,B | 点+7 日区块 bootstrap 区间 + 95 分位刻度 | x = 每活跃手术日复核数 | 蓝/朱红 |
| 19 | A；B | 并行计数条形；阶梯曲线 | x = 输入数；x = % reviewed | 蓝/灰 |
| 20 | A,B | 带注释的 2×4 矩阵（0–100%） | 行=评估×成本律 | 单色顺序 |
| 21 | A,B | 2×4 热图（短缺量） | 同上 | 发散，共用尺度 |
| 22 | A；B | 阶梯曲线；并行计数 | x = % reviewed | 四色（同 Fig 4C） |
| 23 | A；B | 观测/缺失条形；点+CI（斜率=1 参考） | x = 缺失数；x = 校准斜率 | 蓝/灰 |
| 24 | A,B | 3×4 热图（Brier） | 同 eFigure 11 | 单色顺序，两panel共用 |
| 25 | A–D | 横向 SHAP 条形（平均\|SHAP\|×100 pp） | x = 百分点贡献 | 蓝（9 输入）/紫（38 输入） |
| 26 | A,C；B,D | 三角网格选择图；区间支持图 | x = a27、y = a38（0–0.30） | 蓝=9、紫=27、朱红=38、绿=等捕获 |

> eFigure 统一按 JAMA 在线补充材料规范：矢量入 Word/PDF，Arial 10 pt 正文、12 pt 粗体页标题、8 pt 图注，不重绘。

---

## 附录 B：实现对照（现代码 → 建议改法）

| 面板 | 现实现 | 改法 |
|---|---|---|
| 1A | `ax.barh` + `errorbar` | 保留或换 `errorbar(fmt='o')`；配色改为语境色，去掉四色 |
| 1B | `mark()` 横向须 + 左侧文字 | 数值改右侧固定列；`xlim` 收窄 |
| 1C/4C | `ax.plot` | 加 `drawstyle='steps-post'` |
| 1D | `ax.axis('off')` 文字表 | 改双端 `errorbar` + `annotate(arrowprops)` |
| 2A–D | `pcolormesh(DIV)` + 4 条 colorbar | 共用 1 条；`DIV` 中点改 `#F2F2F2`；不可行格 `hatch='///'` |
| 3C | `ax.barh` 两组 | 改 `hlines` + 两点 `plot` |
| 3D | `pcolormesh` + 双行数字 | 改点-须矩阵 |
| 4A | 两组 `barh` | 改 `stem`/单点 + 右侧分母列 |
| 4B | 单轴 6 行 | `fig.subplots(2,3)` 三分面 |
| 5B | `pcolormesh(SEQ)` | 改 `errorbar` 3×2 |
| 5D | `xlim` 拉伸 + `set_label_coords` | 数据轴 0–85，文字列用 `fig.text` |

---

*本规格书只描述"每个面板该用什么图、坐标怎么设、颜色怎么分配"，不改变任何已冻结的数值结果；所有区间与计数沿用 `AKI_Figure_Reproduction_20261111` 的聚合表。*
