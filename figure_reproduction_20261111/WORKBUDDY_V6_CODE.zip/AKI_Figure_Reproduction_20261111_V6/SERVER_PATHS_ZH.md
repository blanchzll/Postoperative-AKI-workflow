# 服务器路径

代码与Notebook

/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/workbuddy_main_redesign_20261111_v6/AKI_Figure_Reproduction_20261111_V6/

Python解释器

/home/lei/codex-workspaces/shared-python-envs/envs/aki-figures-py312-cpu-20261111-v1/bin/python

图片输出

/home/lei/codex-workspaces/aki-prediction-manuscript/outputs/workbuddy_figures_20261111_v6/

Notebook网址路径为http://127.0.0.1:8896/lab/tree/WorkBuddy_V6/notebooks/01_Reproduce_All_Figures.ipynb，使用本次对话提供的登录链接。当前电脑使用SSH端口转发连接t630。需要恢复转发时运行ssh -N -L 127.0.0.1:8896:127.0.0.1:8896 t630。
