
from pathlib import Path
import argparse, concurrent.futures, hashlib, json, os, shutil, subprocess, sys, time
ROOT = Path(__file__).resolve().parent
ALL = [f"Figure_{i}" for i in range(1, 6)] + [f"eFigure_{i}" for i in range(1, 27)]

def main():
    parser = argparse.ArgumentParser(description="Reproduce all current AKI manuscript figures from bundled aggregates.")
    parser.add_argument("--only", nargs="+", choices=ALL)
    parser.add_argument("--output", type=Path, default=ROOT / "outputs")
    parser.add_argument("--font-dir", type=Path)
    parser.add_argument("--workers", type=int, default=0)
    args = parser.parse_args()
    selected = args.only or ALL
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    lock = output / ".render.lock"
    try:
        descriptor = os.open(lock, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    except FileExistsError as error:
        raise RuntimeError(f"A render lock exists at {lock}. Check the running render before removing a stale lock.") from error
    os.write(descriptor, str(os.getpid()).encode())
    os.close(descriptor)
    try:
        render(selected, output, args)
    finally:
        lock.unlink(missing_ok=True)

def render(selected, output, args):
    jobs = []
    for label, script, names, variable in [
        ("main_workbuddy", "draw_main_workbuddy.py", [f"Figure_{i}" for i in range(1, 6)], "AKI_EXPORT_ONLY"),
        ("supplement_19_23", "draw_supplement_19_23.py", [f"eFigure_{i}" for i in range(19, 24)], "AKI_NATIVE_ONLY"),
        ("supplement_1_18_24", "draw_supplement_1_18_24.py", [f"eFigure_{i}" for i in list(range(1, 19)) + [24]], "AKI_NATIVE_ONLY"),
        ("supplement_25", "draw_supplement_25.py", ["eFigure_25"], ""),
        ("supplement_26", "draw_supplement_26.py", ["eFigure_26"], ""),
    ]:
        chosen = [name for name in names if name in selected]
        if chosen:
            jobs.append((label, script, chosen, variable))
    affinity = len(os.sched_getaffinity(0)) if hasattr(os, "sched_getaffinity") else os.cpu_count() or 1
    available = 8 * 1024**3
    meminfo = Path("/proc/meminfo")
    if meminfo.exists():
        available = int(next(line.split()[1] for line in meminfo.read_text().splitlines() if line.startswith("MemAvailable:"))) * 1024
    safe_workers = max(1, int(max(available - 4 * 1024**3, 2 * 1024**3) // (2 * 1024**3)))
    workers = min(len(jobs), affinity, safe_workers)
    if args.workers:
        if args.workers < 1:
            raise ValueError("--workers must be positive")
        workers = min(workers, args.workers)
    logs = output / "logs"
    logs.mkdir(exist_ok=True)
    started = time.time()
    def execute(job):
        label, script, chosen, variable = job
        work = output / ".work" / label
        if work.exists():
            shutil.rmtree(work)
        for name in ["main", "review", "supplement/pages", "runtime"]:
            (work / name).mkdir(parents=True, exist_ok=True)
        environment = os.environ.copy()
        environment.update(AKI_RUN_DIR=str(work), MPLCONFIGDIR=str(work / "runtime/mpl"), MPLBACKEND="Agg")
        for variable_name in ["OMP_NUM_THREADS", "OPENBLAS_NUM_THREADS", "MKL_NUM_THREADS"]:
            environment[variable_name] = "1"
        if args.font_dir:
            environment["AKI_FONT_DIR"] = str(args.font_dir.resolve())
        if variable:
            environment[variable] = ",".join(name.split("_")[-1] if variable == "AKI_EXPORT_ONLY" else name for name in chosen)
        with (logs / (label + ".log")).open("w") as stream:
            result = subprocess.run([sys.executable, str(ROOT / "code" / script)], cwd=ROOT, env=environment, stdout=stream, stderr=subprocess.STDOUT)
        if result.returncode:
            raise RuntimeError(f"{label} failed. See {logs / (label + '.log')}")
        print("Rendered", ", ".join(chosen), flush=True)
        return work
    with concurrent.futures.ThreadPoolExecutor(max_workers=workers) as executor:
        works = list(executor.map(execute, jobs))
    native = output / "native"
    reviews = output / "review"
    reviews.mkdir(exist_ok=True)
    for work in works:
        for name in ["main", "supplement"]:
            if (work / name).exists():
                shutil.copytree(work / name, output / name, dirs_exist_ok=True)
        for item in (work / "review").glob("*.json"):
            shutil.copy2(item, reviews / item.name)
    # Merge isolated panel exports after every plotting process has exited.
    old_panels = {}
    if (native / "PANEL_MANIFEST.json").exists():
        old_panels = json.loads((native / "PANEL_MANIFEST.json").read_text())
    panels = [x for x in old_panels.get("panels", []) if x["figure"] not in selected]
    figures = [x for x in old_panels.get("figures", []) if x["figure"] not in selected]
    for work in works:
        file = work / "native/PANEL_MANIFEST.json"
        if not file.exists():
            continue
        metadata = json.loads(file.read_text())
        panels.extend(metadata["panels"])
        figures.extend(metadata["figures"])
        shutil.copytree(work / "native", native, dirs_exist_ok=True)
    new_native = any((work / "native/PANEL_MANIFEST.json").exists() for work in works)
    if panels and new_native:
        metadata = dict(figures_count=len(figures), panels_count=len(panels), panels=panels, figures=figures, source_scripts={}, source_csvs={}, export_script_sha256=hashlib.sha256((ROOT / "code/jno_native_panels.py").read_bytes()).hexdigest(), source_hashes_unchanged=True)
        (native / "PANEL_MANIFEST.json").write_text(json.dumps(metadata, indent=2))
        with (logs / "compose.log").open("w") as stream:
            subprocess.run([sys.executable, str(ROOT / "code/compose_supplement_pages.py"), "--root", str(native)], check=True, stdout=stream, stderr=subprocess.STDOUT)
    subprocess.run([sys.executable, str(ROOT / "code/finalize_outputs.py"), "--output", str(output), "--only", *selected], check=True)
    result = dict(status="PASS_RENDERED", figures=selected, figure_count=len(selected), workers=workers, MemAvailable_at_launch=available, seconds=time.time()-started, python=sys.executable)
    (output / "RUN_RECEIPT.json").write_text(json.dumps(result, indent=2))
    shutil.rmtree(output / ".work")
    print(json.dumps(result), flush=True)

if __name__ == "__main__":
    main()
