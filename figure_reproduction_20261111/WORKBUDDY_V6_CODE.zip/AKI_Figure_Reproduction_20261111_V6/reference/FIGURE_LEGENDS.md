# Figure legends

## Figure 1. Selected-workflow discrimination, paired comparisons, and event coverage

A, AUROCs of the two selected workflows in four matched comparisons. Labels identify model families and eligible operations/events. B, Corresponding additional-information-minus-baseline AUROC differences. C, Empirical step curves for nine- and 27-input preoperative review. D, Captured-event counts at 20% capacity and paired capture differences on separate axes. Geographic and temporal preoperative lists contain 232 and 337 records. The preoperative comparisons include 1,159/72 and 1,683/66 operations/events, and paired-stage comparisons include 1,158/72 and 1,011/36. Whiskers are the saved 95% intervals from 2,000 hospital-stratified patient-group bootstrap samples.

## Figure 2. Acquisition costs, review budgets, and captured events

A-D, Geographic and temporal nine-to-27 and 27-to-38 comparisons across the complete acquisition-cost and review-budget grid. A shared diverging scale represents additional-path-minus-baseline captured events per 1,000 operations. The near-white midpoint denotes zero. Hatched gray cells represent unaffordable acquisition. Numbers identify selected exact cells, and dots or asterisks identify pointwise paired 95% intervals excluding zero. Open triangles mark positive 20% equal-capture allowances. The hypothetical acquisition cost is paid for every eligible record. Intervals reuse 2,000 hospital-stratified patient-group samples.

## Figure 3. Equal-capture resources and cost-weighted event coverage

A and B, Signed acquisition allowance in review equivalents per 1,000 operations for geographic and temporal evaluation. Right-hand columns give saved estimates and 95% intervals. C, Baseline review-list sizes and shortest additional-information lists achieving the same event capture at a 20% baseline budget. Gray and magenta endpoints identify baseline and additional-information review. D, Mean capture differences under five analyst-specified cost laws. The matrix displays point estimates, with paired intervals retained in the supplementary tables. All intervals reuse 2,000 hospital-stratified patient-group samples. Unaffordable acquisition reverts to baseline review before spending.

## Figure 4. Information representation and clinical review in INSPIRE

A, Released preoperative coded-history matches among 6,043 operations. Absence of a released match does not establish clinical absence. B, Coded-nine-minus-six-input RF differences on separate AUROC, average-precision, and Brier-decrease scales. Brier differences and their interval endpoints are reversed and multiplied by 1,000 for display. Positive values favor coded-nine. Whiskers show saved paired 95% patient-group bootstrap intervals. C, Empirical target-ranked step curves for 253 recorded SCr events. Color identifies evaluation, and line style identifies input configuration. D, Target-20% and transferred source-sensitivity-80% operating points. Labels give reviewed records and captured events.

## Figure 5. MIMIC transport, review workload, and measurement conditions

A, Qualification of 1,231 anatomical candidates to 759 patients with 59 recorded SCr events. B, Raw and source-calibrated Brier scores with saved bootstrap 95% intervals. The gray diamond denotes the observed-prevalence constant without an interval. C, Target-20%, transferred source-20%, and source-sensitivity-80% operating points for each frozen source system. Labels give reviewed patients and captured events. D, Known-event loss after five measurement-thinning rules. Blue identifies all 759 patients/59 events, and red identifies the geographic low-risk subset of 258/11. Whiskers are Wilson 95% intervals, including zero-loss cells. Right columns give lost/known events and measurement removal. These comparisons reuse recorded measurements.

## eFigure 1. Cohorts, information stages and evaluation architecture

**A** Source-record attrition and eligible preoperative/paired cohorts. **B** Geographic and temporal training/evaluation counts. **C** Required inputs at each information stage. **D** Separate public six-input representation. The main cohort comprises 3,710 records/3,693 patient groups/205 AKI events; the paired cohort comprises 2,428/2,411/138. Geographic development uses centres 1/2/4 and evaluation centres 3/5. Temporal evaluation starts on 1 January 2022, with three earlier cross-period records excluded by the patient-group rule. Evaluation overlap is 273 records/272 groups. POD1 and public SCr endpoints define separate populations. Counts represent operative records and recorded events. Source data are provided with the figure manifest. After excluding one record aged younger than 18 years, 4,013 screened source records remained; the 303 renal-information exclusions included one record with unrecorded age.

## eFigure 2. Capture-loss bounds across reference margins

**A** Nine-input capture loss L=C27−C9 per 1,000 operative records at 20% primary and 10% supporting review capacity. Bars are the original paired two-sided 95% bootstrap confidence intervals from 2,000 hospital-stratified patient-group samples. Geographic evaluation contains 1,159 records/72 events; temporal evaluation 1,683/66. **B** Every reference δ from zero to ten in steps of 0.5. Filled/open squares denote U<δ/U≥δ, where U is the original interval's 97.5th-percentile upper endpoint. Black ticks show the exact endpoint. Both rows are the logical intersection of contextual criteria. At 20% review, δ=5 meets the criterion temporally; δ=7 meets it in both lines and is the first joint value on this grid. The continuous joint boundary is δ>6.914433880726012. Reference values belong to a post hoc sensitivity analysis; no clinical margin was independently adopted. All 84 contextual and 42 joint rows are retained in the source data.

## eFigure 3. ALT omission and changes in information increments

**A,B** ALT-omission upgrade-minus-base capture increments relative to matched-control increments, at 10%/20% review. All four contexts are retained. Points show paired difference-in-differences estimates; bars show bootstrap 95% confidence intervals. Original stage models and omission results remain unchanged. ALT indicates alanine aminotransferase. Evaluation counts are in eTable 2; the resampling procedure is specified in eMethods.

## eFigure 4. All constrained information-allocation scenarios

**a–d** All four contexts with 25%/50% information-upgrade budgets and 10%/20% review. Points show selective capture minus mean random-allocation capture per 1,000. Ranges transform the central 95% distribution across 2,000 fixed-size random allocations, conditional on fitted systems/records; they describe allocation variability. Circles/squares distinguish upgrade budgets. Acquisition upgrades nine→27 preoperative inputs or 27→38 paired inputs. Comparisons retain source-calibration behavior, including the geographic paired 50% random comparator's negative Platt slope (−0.276651).

## eFigure 5. Target-local probability updates

**A** Original, offset-MAP and logistic-MAP Brier scores for ten primary routes and two public source routes. **B** Update-minus-original differences. Circles denote original scores, open squares offset and triangles logistic updates. Lower values indicate lower prediction error. Bars are bootstrap 95% confidence intervals. Target-local updating uses outcomes from other patient-group-separated target folds; update maps and adaptation thresholds are refitted within resampling. Public routes share 6,043 target records.

## eFigure 6. Event capture and review capacity

**A,B** Complete retrospective capture–review curves for nine- and 27-input primary preoperative systems in geographic (1,159 operative records/72 events; LR) and temporal (1,683/66; voting) evaluation. Solid lines and filled circles denote nine inputs; dashed lines and open squares denote 27 inputs. Points mark the original 10% and 20% capacities; curves use every integer list size. **C** Paired capture increments for 20% minus 10% capacity, expressed per 1,000 evaluation records. Points/bars are estimates and percentile 95% confidence intervals from 2,000 hospital-stratified patient-group bootstrap samples, seed 20261017. The additional list contained 116 geographic or 168 temporal records. Curves summarize ranked retrospective selections; panel-c intervals condition on the fixed systems. Scenario-based work and event-effect quantities are presented in eFigure 12.

## eFigure 7. Public ranking and threshold-defined review workload

**A** AUROC of two separately developed six-input RF models in the same 6,043 INSPIRE records/253 SCr events. **B** Capture at target 20% ranking (1,209 selected for review; 121/124 events captured). **C,D** Review fraction and sensitivity under transferred source 10%-capacity, 20%-capacity and 80%-sensitivity thresholds, alongside target 20% ranking. Slate circles denote the geographic-source model and orange squares the temporal-source model. Bars are bootstrap 95% confidence intervals. The temporal source-sensitivity threshold selects all 6,043 records and captures all 253 events. Additional frozen coded-nine workflows are presented in Figure 4.

## eFigure 8. Recorded surgery-to-qualifying-SCr interval coverage

The displayed workflows are the two primary common-six RF systems. **A** Target-20%-ranking fractions with recorded intervals ≥12/24/48 hours. **B** Rule-specific ≥24-hour coverage. Slate circles/orange squares denote geographic/temporal source models. All 253 SCr events form the denominator, including unselected events. Bars are bootstrap 95% confidence intervals. Intervals run from surgery start to first qualifying recorded SCr; biological onset, alert delivery and result-release times are unavailable.

## eFigure 9. POD1 updating in the conditional SCr cohort

POD1 denotes postoperative day 1. **A,B** Changes in AUROC/Brier for prespecified LR comparisons: POD1 minus preoperative inputs in all records, and POD1 minus end-of-operation inputs in matched records. The eligible cohort contains 2,947 records/39 subsequent SCr events; evaluation counts accompany each contrast. Updates add POD1 SCr and its baseline ratio. Bars are bootstrap 95% confidence intervals. The principal original comparison is all-POD1 versus all-preoperative LR Brier.

## eFigure 10. Conditional prediction and review-list stability

**A** Overlap with the original top-20% list. **B** Classification changes at the fixed source-sensitivity threshold. Points/bars are means/central 2.5th–97.5th percentile ranges over 200 conditional development patient-group refits per route (2,000 total). Inputs, imputation family, hyperparameters and composition remain fixed. Groups are resampled without hospital stratification. Ranges describe conditional training variability. The finite computational probes completed without failure.

## eFigure 11. Medical-language-model discrimination and average precision

A/B show AUROC and C/D average precision, with geographic evaluation left and temporal evaluation right. Each matrix contains all 12 model/stage/adaptation conditions in that evaluation, covering 24 total. Rows are BioMedLM, Llama 3 and MedGemma; columns are preoperative before/after and operation-end before/after adaptation. Cell values are frozen source-calibrated point estimates, with common color limits within each metric; point estimates are also reported in eTable 9, and paired contrasts and intervals remain in the aggregate files. Brier scores are in eFigure 24.

## eFigure 12. Observed capture and assumption-based clinical-use trade-offs

**A** Nine-input preoperative capture at 10%/20% review; annotations give captured/missed counts. **B,C** Hours and additional tests per 1,000 under fixed five/ten/fifteen-minute review assumptions paired with 0%/50%/100% additional testing. Slate circles and orange squares denote geographic/temporal evaluation, offset for visibility. **D** Hypothetical events averted at uptake=75% under assumed relative risk reductions (RRR) of −10%, zero and 20%. Negative values denote additional events under the harmful-effect assumption. Evaluation counts are 1,159/72 and 1,683/66. Panel a uses observed capture and saved bootstrap confidence intervals. Panels b–d propagate sampling uncertainty conditional on unmeasured workload/effect assumptions. These are preoperative-use scenarios. Full grids retain 250 operating rules, 2,250 workload rows and 2,325 hypothetical-effect rows.

## eFigure 13. Calibration of the ten primary routes

**a–d** Geographic preoperative, temporal preoperative, geographic paired and temporal paired evaluation. Points connect observed proportions and mean predictions in ten frozen score bins; the identity line indicates agreement. Preoperative panels include compact/full/selected routes; paired panels show selected preoperative/end-of-operation systems. Counts are 1,159/72, 1,683/66, 1,158/72 and 1,011/36 records/events. These are decile point estimates. Every bin's records/events are supplied in the source data.

## eFigure 14. Six-, nine- and 27-input source-cohort LR comparisons

**A** AUROC differences and **B** captured-event differences at 20% review for nine minus six inputs (circles) and 27 minus six inputs (open squares). Slate and orange denote geographic and temporal evaluation. Source-calibrated LR workflows were compared on the same respective 1,159/72 and 1,683/66 record/event populations. Bars are original paired 95% percentile intervals from 2,000 hospital-stratified patient-group samples, seed 20261017. Input-specific source-selected imputation and hyperparameters were retained. All raw/calibrated AUROC, AP, Brier, observed-to-expected and calibration-diagnostic views are supplied in eTable 11 in Supplement 1. The source-cohort LR bridge is separate from the public six-input RF evaluation.

## eFigure 15. End-of-operation gains and consistency across comparisons

**A,B** Paired preoperative and end-of-operation AUROC and Brier score. **C,D** End-of-operation-minus-preoperative capture at 10% and 20% capacity, including available same-family comparisons and temporal non-overlap evaluation. Geographic evaluation contains 1,158 records/72 events and selects 232 records at 20%; temporal evaluation contains 1,011/36 and selects 203. The non-overlap sample contains 738 records/29 events. Filled squares denote complete systems, open circles same-family comparisons, and crosses non-overlap evaluation. Bars show 95% intervals from 2,000 hospital-stratified patient-group bootstrap samples. Complete-system contrasts include selected-family, development, and calibration differences. Absolute operating counts appear in eTable 4 in Supplement 1. AUROC indicates area under the receiver operating characteristic curve; LR, logistic regression.

## eFigure 16. Information routing at equal total resource budgets

Panels A and B show geographic and temporal nine-to-27-input comparisons; panels C and D show geographic and temporal 27-to-38-input comparisons. Records/events are 1,159/72, 1,683/66, 1,158/72, and 1,011/36, respectively. Points and bars show capture differences per 1,000 records and 95% paired patient-group percentile intervals relative to expanded baseline review at the same total budget. The budget comprises ceil(0.20N) reviews plus acquisition for ceil(0.25N) records at 0.1 review equivalents per acquisition. Models and source-defined rules remain fixed; acquisition and review are rerouted within each of 2,000 samples. Full-acquisition and no-acquisition comparators use that same total budget. These are exploratory fixed-system comparisons.

## eFigure 17. Observed low-risk events and monitoring dependence

A, Recorded events within low-risk groups defined by each model's frozen source sensitivity-80% threshold. Labels give events and operation records. Bars show 95% patient-group bootstrap intervals for nonzero-event groups; the zero-event group of nine distinct patients uses a Wilson interval. B, Retrospective deletion of MIMIC SCr measurements against the unchanged calendar-ratio endpoint. Slate denotes all 759 patients/59 known events; orange denotes the geographic six-input low-risk group of 258 patients/11 events. Symbols identify the five deletion schedules. Vertical bars show 95% Wilson intervals for the proportion of known events lost. An empirical zero loss retains uncertainty, and unobserved events are unavailable for a monitoring-safety assessment.

## eFigure 18. Potential final review demand indexed to study-cohort surgery dates

A and B show geographic and temporal evaluation, respectively. Points and bars show mean potential final reviews per active study surgery day and 95% seven-day-block bootstrap intervals; squares and ticks show the 95th percentile and maximum. Requests use the existing source-defined individual acquisition policy and its frozen development-capacity-20% review threshold, without daily reranking. Counts are indexed to the actual surgery dates in the eligible study cohort, with one final-policy review request per selected operation. Calendar-day summaries, acquisition-time scenarios, and conditional repeated-stage requests remain in the aggregate tables. Actual action arrival, completion, shift clocks, and whole-hospital service volume were unavailable.



## eFigure 19. Input requirements and nine-input review coverage

A, Nine routine core fields and additional fields required by the 27-input system, shown as parallel counts. B, Complete retrospective capture–review curves for the frozen nine-input systems, on the 1,159/72 geographic and 1,683/66 temporal operation/event populations. Curves use observed outcomes; no smoothing or intervention effect is inferred.

## eFigure 20. Cost-weighted event-capture choice shares

A and B, Nine-to-27-input and 27-to-38-input probability mass under all five analyst-specified cost laws, shown as annotated matrices. Rows identify geographic or temporal evaluation and cost law; columns are more/equal/fewer captured events and acquisition infeasibility. Cells use a common 0%–100% scale and the complete cost distribution. These are conditional assigned-scenario shares, not probabilities of patient benefit. Laws: 1 = ratio_uniform_030; 2 = ratio_low_030; 3 = ratio_middle_030; 4 = ratio_high_030; 5 = ratio_wide_tail_100.

## eFigure 21. Expected event-capture shortfalls under assigned costs

A and B show geographic and temporal expected capture shortfalls per 1,000 records for baseline and additional-information choices relative to the better feasible path at each cost. Rows cover nine-to-27 and 27-to-38 inputs under all five cost laws; colors share a common scale. Values are frozen aggregate point estimates using the pre-spending fallback rule. Cost-law numbering is defined in eFigure 20.

## eFigure 22. INSPIRE review curves and released history matches

A, Complete target-ranked capture–review curves for all four source-calibrated six-/coded-nine-input workflows on 6,043 records/253 SCr events. B, Released preoperative coded-history matches versus no released match, shown as parallel counts. No released match is not proof of clinical absence; target rankings use retrospective outcomes only to summarize coverage.

## eFigure 23. MIMIC input availability and calibration slopes

A, Observed versus missing preoperative laboratory values in 759 patients. Missing albumin, urea nitrogen and hemoglobin counts are 465, 33 and 40. B, Source-calibrated target calibration slopes with pointwise percentile 95% intervals from the frozen 2,000 patient-bootstrap samples; the dashed reference is 1. Target calibration coefficients are diagnostic and do not update model risks.

## eFigure 24. Medical-language-model probability error

A and B show Brier score matrices for geographic and temporal evaluations, covering the same 24 source-calibrated conditions as eFigure 11. Rows are BioMedLM, Llama 3 and MedGemma; columns are preoperative before/after and operation-end before/after adaptation. Both panels share a Brier color scale. Lower Brier values indicate less probability error; full precision, intervals and comparisons remain in the aggregate files.


## eFigure 25. Input contributions to the selected clinical workflows

A and B, Geographic and temporal nine-input preoperative workflows. C and D, Geographic and temporal 38-input operation-end workflows. Bars show mean absolute SHAP contributions to source-calibrated probability, multiplied by 100 to express percentage points, using the saved whole-pipeline permutation explanations. The nine-input panels show every input. The 38-input panels show the nine highest contributions, ranked within each workflow, with ties resolved by field name. All panels share the same horizontal scale. Each reference sample contains 128 development patient groups, comprising 128 operations in A and 129 in B–D, with 16 background groups and 64 permutation paths per workflow. Values summarize prediction contributions in the development reference sample. Monte Carlo standard errors describe finite-permutation approximation and are supplied separately in the aggregate files. Complete raw and calibrated contributions for all ten workflows remain in the source tables.


## eFigure 26. Resource-based selection of information workflows

A and C, Workflow with the highest observed event coverage at each pair of acquisition-cost ratios in geographic and temporal evaluation. B and D, Paired interval support for the same cells. Costs are additional effort per eligible operation relative to available nine-input information, divided by one baseline review effort. The total budget equals ceil(0.20N) review equivalents. The nested acquisition grid has 0≤a27≤a38≤0.30 in 0.01 steps, with 496 cells per evaluation. Blank lower triangles lie outside that grid. Slate, purple, and orange identify nine-, 27-, and 38-input workflows, and green identifies equal capture in the observed-coverage panels. In the interval panels, slate identifies nine-input capture above every other affordable workflow with positive lower endpoints of paired pointwise 95% difference intervals. Light gray identifies overlapping intervals. Dark gray identifies cells where only nine-input review is affordable. The dotted budget boundary separates grid coordinates through 0.20 from unaffordable additional acquisition. Populations contain 1,158 operations/72 events and 1,011/36. The three models retain their original development populations and calibrated predictions, and lists are reranked on the common paired-eligible records. Intervals reuse 2,000 original hospital-stratified patient-group samples. eTable 33 defines the selection measure and gives illustrative counts.
