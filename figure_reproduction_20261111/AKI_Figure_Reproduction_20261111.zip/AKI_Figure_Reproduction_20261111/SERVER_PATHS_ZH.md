# 服务器运行位置

代码与Notebook

/home/lei/codex-workspaces/aki-prediction-manuscript/writing_runs/standalone_figure_reproduction_20261111_v1/AKI_Figure_Reproduction_20261111/

图片输出

/home/lei/codex-workspaces/aki-prediction-manuscript/outputs/standalone_figures_20261111/

Python解释器

/home/lei/codex-workspaces/shared-python-envs/envs/aki-figures-py312-cpu-20261111-v1/bin/python

Notebook使用AKI Figures (Python 3.12)内核。服务器Jupyter进程通过AKI_FIGURE_OUTPUT环境变量设置上述独立输出目录。新生成图片由作者自行复制到电脑。

## 浏览器访问

当前电脑已建立SSH本地转发，服务网址为http://127.0.0.1:8896/。登录链接由本次对话提供，认证令牌保存在服务器用户私有配置中。

如果以后本地转发断开，在当前电脑终端运行以下命令并保持终端连接。

    ssh -N -L 127.0.0.1:8896:127.0.0.1:8896 t630

服务器Jupyter服务由本次任务的独立用户服务管理。服务器重启后可运行以下命令启动。

    systemctl --user start aki-figures-jupyter-20261111.service

全部生成图片在前述服务器独立输出目录。可按需要复制main和supplement目录到电脑。代码包同步至PortableSSD独立目录，后续新图由作者自行复制。
