# 全部绘图代码与输入汇总

5幅主图和26幅附图共用run_figures.py。主图与附图的完整可编辑图注位于reference/FIGURE_LEGENDS.md和FIGURE_LEGENDS_ZH.md。表内输入位于data子目录。

| 图号 | 内容 | 绘图代码 | 主要汇总输入 |
|---|---|---|---|
|Figure_1|Figure 1. Selected-workflow discrimination, paired comparisons, and event coverage|code/draw_main_1_5.py|Primary_model_points, Primary_model_intervals, Table_3_stage_and_input_differences, PRIMARY_EQUAL_CAPACITY20, Translation_geography_preop_CAPTURE_REVIEW_CURVE, Translation_temporal_preop_CAPTURE_REVIEW_CURVE|
|Figure_2|Figure 2. Acquisition costs, review capacity, and captured events|code/draw_main_2_3_4.py|RESOURCE_BUDGET_GRID|
|Figure_3|Figure 3. Equal-capture resources and cost-weighted event coverage|code/draw_main_2_3_4.py|BREAK_EVEN_BOUNDARIES, PRIMARY_20_PERCENT_SUMMARY|
|Figure_4|Figure 4. Information representation and clinical review in INSPIRE|code/draw_main_2_3_4.py|Coded9_POINT_ESTIMATES, Coded9_INTERVALS, Coded9_PAIRED_DIFFERENCES_VS_SIX_RF, Coded9_HISTORY_COUNTS, Coded9_SOURCE_THRESHOLD_COVERAGE|
|Figure_5|Figure 5. MIMIC clinical transport, workload, and measurement conditions|code/draw_main_1_5.py|MIMIC_POINT_ESTIMATES, MIMIC_INTERVALS, MIMIC_SOURCE_THRESHOLD_BURDEN, MIMIC_DELETION_SENSITIVITY|
|eFigure_1|eFigure 1. Cohorts, information stages and evaluation architecture|code/draw_supplement_1_18_24.py|F1_partitions, F1_centres|
|eFigure_2|eFigure 2. Capture-loss bounds across reference margins|code/draw_supplement_1_18_24.py|S9_MARGIN_SENSITIVITY, S9_CROSS_CONTEXT_SENSITIVITY, S9_TIPPING_POINT_SUMMARY|
|eFigure_3|eFigure 3. ALT omission and changes in information increments|code/draw_supplement_1_18_24.py|S7_ALT_all_metrics|
|eFigure_4|eFigure 4. All constrained information-allocation scenarios|code/draw_supplement_1_18_24.py|F4_allocation_16_scenarios|
|eFigure_5|eFigure 5. Target-local probability updates|code/draw_supplement_1_18_24.py|S2_calibration_update_points, S2_calibration_update_support|
|eFigure_6|eFigure 6. Event capture and review capacity|code/draw_supplement_1_18_24.py|Translation_geography_preop_CAPTURE_REVIEW_CURVE, Translation_temporal_preop_CAPTURE_REVIEW_CURVE, Translation_geography_preop_INCREMENT_POINTS, Translation_temporal_preop_INCREMENT_POINTS, Translation_geography_preop_INCREMENT_AND_INVERSE_INTERVALS, Translation_temporal_preop_INCREMENT_AND_INVERSE_INTERVALS|
|eFigure_7|eFigure 7. Public ranking and threshold-defined review workload|code/draw_supplement_1_18_24.py|F5_public_model_points, F5_public_model_intervals, F5_public_review_and_capture|
|eFigure_8|eFigure 8. Recorded surgery-to-qualifying-SCr interval coverage|code/draw_supplement_1_18_24.py|S6_recorded_window_points, S6_recorded_window_intervals|
|eFigure_9|eFigure 9. POD1 updating in the conditional SCr cohort|code/draw_supplement_1_18_24.py|S3_POD1_LR_points, S3_POD1_LR_differences|
|eFigure_10|eFigure 10. Conditional prediction and review-list stability|code/draw_supplement_1_18_24.py|S5_conditional_stability|
|eFigure_11|eFigure 11. Medical-language-model discrimination and average precision|code/draw_supplement_1_18_24.py|S4_LLM_all24_calibrated_points.csv|
|eFigure_12|eFigure 12. Observed capture and assumption-based clinical-use trade-offs|code/draw_supplement_1_18_24.py|F4_representative_operating_rules, F4_representative_workload_assumptions, F4_representative_effect_assumptions, Primary_model_intervals|
|eFigure_13|eFigure 13. Calibration of the ten primary routes|code/draw_supplement_1_18_24.py|Calibration_deciles|
|eFigure_14|eFigure 14. Six-, nine- and 27-input source-cohort LR comparisons|code/draw_supplement_1_18_24.py|Translation_geography_BRIDGE_INTERVALS, Translation_temporal_BRIDGE_INTERVALS, Translation_BRIDGE_POINT_ESTIMATES|
|eFigure_15|eFigure 15. End-of-operation gains and consistency across comparisons|code/draw_supplement_1_18_24.py|Primary_model_points, Primary_model_intervals, F3_stage_differences|
|eFigure_16|eFigure 16. Information routing at equal total resource budgets|code/draw_supplement_1_18_24.py|POLICY_PAIRED_DIFFERENCES|
|eFigure_17|eFigure 17. Observed low-risk events and monitoring dependence|code/draw_supplement_1_18_24.py|LOW_RISK_EVENTS, MIMIC_DELETION_SENSITIVITY|
|eFigure_18|eFigure 18. Potential final review demand indexed to study-cohort surgery dates|code/draw_supplement_1_18_24.py|DAILY_SUMMARY|
|eFigure_19|eFigure 19. Input requirements and nine-input review coverage|code/draw_supplement_19_23.py|Primary_model_points, Primary_model_intervals, PRIMARY_EQUAL_CAPACITY20, Translation_geography_preop_CAPTURE_REVIEW_CURVE, Translation_temporal_preop_CAPTURE_REVIEW_CURVE|
|eFigure_20|eFigure 20. Cost-weighted event-capture choice shares|code/draw_supplement_19_23.py|PRIMARY_20_PERCENT_SUMMARY|
|eFigure_21|eFigure 21. Expected event-capture shortfalls under assigned costs|code/draw_supplement_19_23.py|PRIMARY_20_PERCENT_SUMMARY|
|eFigure_22|eFigure 22. INSPIRE review curves and released history matches|code/draw_supplement_19_23.py|Coded9_FULL_CAPTURE_REVIEW_CURVE, Coded9_HISTORY_COUNTS|
|eFigure_23|eFigure 23. MIMIC input availability and calibration slopes|code/draw_supplement_19_23.py|MIMIC_POINT_ESTIMATES, MIMIC_INTERVALS, Observed input counts in draw_supplement_19_23.py|
|eFigure_24|eFigure 24. Medical-language-model probability error|code/draw_supplement_1_18_24.py|S4_LLM_all24_calibrated_points.csv|
|eFigure_25|eFigure 25. Input contributions to the selected clinical workflows|code/draw_supplement_25.py|FOUR_WORKFLOW_SHAP|
|eFigure_26|eFigure 26. Resource-based selection of information workflows|code/draw_supplement_26.py|STRATEGY_SELECTION_GRID|
