
from pathlib import Path
import argparse, collections, hashlib, json, re
import numpy as np
import pandas as pd
import pymupdf as fitz
ROOT = Path(__file__).resolve().parents[1]
parser = argparse.ArgumentParser()
parser.add_argument("--output", type=Path, default=ROOT / "outputs")
output = parser.parse_args().output.resolve()
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
bindings = json.loads((ROOT / "verification/SOURCE_BINDINGS.json").read_text())
assert all(sha(ROOT / item["path"]) == item["sha256"] for item in bindings["inputs"])
assert len(list((output / "main").glob("Figure_*.pdf"))) == 5
assert len(list((output / "supplement").glob("eFigure_*.pdf"))) == 26
assert len(list((output / "supplement/pages").glob("*.pdf"))) == 41
original = json.loads((ROOT / "reference/MAIN_NUMERIC_ARTISTS.json").read_text())
current = []
for name in ["COMPOSITE_MAIN_FIGURES.json", "TARGETED_FIGURE_BINDINGS.json"]:
    current += json.loads((output / "review" / name).read_text())["figures"]
before = {(item["figure"], panel): value for item in original for panel, value in item["numeric_artist_sha256"].items()}
after = {(item["figure"], panel): value for item in current for panel, value in item["numeric_artist_sha256"].items()}
retained = [key for key in before if key != ("Figure_1", "A")]
assert len(retained) == 19 and all(before[key] == after[key] for key in retained)
points = pd.read_csv(ROOT / "data/aggregate_data/source_data/Primary_model_points.csv")
intervals = pd.read_csv(ROOT / "data/aggregate_data/source_data/Primary_model_intervals.csv")
ledger = json.loads((output / "review/TARGETED_FIGURE_BINDINGS.json").read_text())["ledger"]
bars = [item for item in ledger if item["figure"] == 1 and item["panel"] == "A"]
assert len(bars) == 8
for bar in bars:
    context, model = bar["label"].split(":", 1)
    point = points[(points.context == context) & (points.model == model)].iloc[0]
    interval = intervals[(intervals.context == context) & (intervals.model == model) & (intervals.metric == "AUROC")].iloc[0]
    assert np.allclose([bar["value"], bar["lower95"], bar["upper95"]], [point.AUROC, interval.lower95, interval.upper95], atol=1e-14)
old = json.loads((ROOT / "reference/PAGE_AND_PANEL_MANIFEST.json").read_text())
new = json.loads((output / "native/PANEL_MANIFEST.json").read_text())["panels"]
old_map = {(item["figure"], item["panel"]): item["numeric_artist_sha256"] for item in old["panels"] if item.get("numeric_artist_sha256")}
new_map = {(item["figure"], item["panel"]): item["numeric_artist_sha256"] for item in new}
assert len(old_map) == len(new_map) == 65 and old_map == new_map
shap = pd.read_csv(ROOT / "data/shap_threshold_reporting_20261111_v4/FOUR_WORKFLOW_SHAP.csv")
shap_bars = json.loads((output / "review/SHAP_PAGES.json").read_text())["bars"]
assert len(shap_bars) == 36
for bar in shap_bars:
    row = shap[(shap.route == bar["route"]) & (shap.feature == bar["feature"]) & (shap.scale == "calibrated_probability")].iloc[0]
    assert np.isclose(bar["percentage_points"], float(row.mean_absolute_SHAP) * 100, atol=1e-14)
pairs = [(ROOT / f"reference/main/Figure_{i}.pdf", output / f"main/Figure_{i}.pdf") for i in range(2, 6)]
pairs += [(path, output / "supplement/pages" / path.name) for path in sorted((ROOT / "reference/supplement_pages").glob("*.pdf"))]
records = []
for reference, rendered in pairs:
    with fitz.open(reference) as source, fitz.open(rendered) as target:
        assert len(source) == len(target) == 1
        a, b = source[0], target[0]
        assert np.allclose(list(a.rect), list(b.rect), atol=.01)
        first = a.get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
        second = b.get_pixmap(matrix=fitz.Matrix(1, 1), alpha=False)
        assert (first.width, first.height, first.n) == (second.width, second.height, second.n)
        pixel_equal = first.samples == second.samples
        text_equal = re.sub(r"\s+", " ", a.get_text()).strip() == re.sub(r"\s+", " ", b.get_text()).strip()
        if reference.stem == "eFigure_8_page_01":
            removed = collections.Counter(a.get_text().splitlines()) - collections.Counter(b.get_text().splitlines())
            added = collections.Counter(b.get_text().splitlines()) - collections.Counter(a.get_text().splitlines())
            assert removed == {"All recorded SCr events covered (%)": 1} and not added
        else:
            assert pixel_equal and text_equal, (reference.stem, pixel_equal, text_equal)
        records.append(dict(page=reference.stem,exact_pixels=pixel_equal,exact_text=text_equal))
result = dict(status="PASS_CURRENT_PORTABLE_FIGURE_REPRODUCTION",
    main_figures=5,supplement_figures=26,supplement_native_pages=41,
    input_hashes_matched=len(bindings["inputs"]),retained_main_panel_numeric_artists=19,
    revised_Figure1A_bars_source_matched=8,original_supplement_panel_numeric_artists=65,
    SHAP_bars_source_matched=36,unchanged_pages_pixel_identical=sum(item["exact_pixels"] for item in records),
    presentation_changes=["Figure1A replaced by eight source-matched AUROCs in four matched comparisons",
                          "eFigure8B duplicate continuous-outcome ylabel omitted on categorical-rule axis"],
    page_comparisons=records)
(ROOT / "verification/FINAL_REPRODUCTION_ACCEPTANCE.json").write_text(json.dumps(result,indent=2))
print(json.dumps({key:value for key,value in result.items() if key != "page_comparisons"}))
