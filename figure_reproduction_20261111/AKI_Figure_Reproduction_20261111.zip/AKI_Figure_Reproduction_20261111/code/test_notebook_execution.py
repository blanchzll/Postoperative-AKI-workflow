
from pathlib import Path
import os,json,time
import nbformat
from nbclient import NotebookClient
root=Path(__file__).resolve().parents[1]
os.chdir(root)

os.environ.setdefault("AKI_FIGURE_OUTPUT",str(root/"outputs"))
notebook=nbformat.read(root/"notebooks/01_Reproduce_All_Figures.ipynb",as_version=4)
started=time.time()
client=NotebookClient(notebook,timeout=1800,kernel_name="aki-figures-20261111",resources={"metadata":{"path":str(root/"notebooks")}})
client.execute()
nbformat.write(notebook,root/"verification/01_EXECUTED.ipynb")
result=dict(status="PASS_NOTEBOOK_RUN_ALL",code_cells=sum(x.cell_type=="code" for x in notebook.cells),seconds=time.time()-started,kernel="aki-figures-20261111",output=os.environ["AKI_FIGURE_OUTPUT"],owned_kernel_shutdown=True)
(root/"verification/NOTEBOOK_EXECUTION.json").write_text(json.dumps(result,indent=2))
print(json.dumps(result))
